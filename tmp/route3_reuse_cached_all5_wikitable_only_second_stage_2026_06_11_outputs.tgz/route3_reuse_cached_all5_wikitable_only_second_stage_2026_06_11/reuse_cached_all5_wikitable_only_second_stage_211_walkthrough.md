# Route 3 Streaming Wikipedia Page-ID Walkthrough - 2026-06-11

## Stats

- Run group ID: `route3_reuse_cached_all5_wikitable_only_second_stage_2026_06_11`
- Run segment ID: `reuse_cached_all5_wikitable_only_second_stage_211`
- Artifact manifest: `/home/chenyue/Wikidata_Framework_aws/outputs/run_manifests/route3_reuse_cached_all5_wikitable_only_second_stage_2026_06_11.json`
- Mode: `page_id_stream`
- Page source: `table-search`
- Table-search queries: `insource:"wikitable"`
- Attempted page IDs: 188
- Unique attempted page IDs: 188
- Stream state reset at run start: yes
- Accepted QAs: 17
- Rejected QAs/pages: 322
- Transient rerun attempts during run: 0
- Wall-clock runtime: 734.4633s
- DuckDuckGo top K: 5
- Generated search queries per QA: 2
- DuckDuckGo parallel queries: 3
- DuckDuckGo ddgs primary path: `enabled`, backend `auto`, attempts 2
- DuckDuckGo global cooldown: `enabled`, threshold 3, 60.0s to 300.0s
- Minimum Route 3 table score: 0.0
- Route 3 reasoning_type constraint: `single_fact`
- Route 3 table filter modes: `no_external_links_tables, no_horizontal_companion_tables, no_picture_heavy_tables, no_incomplete_tables, not_number_dominant, no_social_science_research`
- Route 3 table source types: `wikitable`
- Route 3 prose-leakage scoring: `enabled`
- Route 3 LLM table choice: `disabled`
- Stream page workers: 4
- Wikipedia concurrency limit: 4
- Wikipedia 429 backoff: 30.0s base, 300.0s max, 120.0s recovery
- DuckDuckGo service concurrency limit: 4
- OpenRouter generation/rewrite concurrency limit: 10
- Second-stage concurrency limit: 10
- Page-id bounds: 1 to 80000000
- Stream state: `outputs/recipe_segments/route3_reuse_cached_all5_wikitable_only_second_stage_2026_06_11/reuse_cached_all5_wikitable_only_second_stage_211_state.json`
- Accepted output: `outputs/recipe_segments/route3_reuse_cached_all5_wikitable_only_second_stage_2026_06_11/reuse_cached_all5_wikitable_only_second_stage_211_accepted.jsonl`
- Rejected output: `outputs/recipe_segments/route3_reuse_cached_all5_wikitable_only_second_stage_2026_06_11/reuse_cached_all5_wikitable_only_second_stage_211_rejected.jsonl`
- Domain policy: `domain_and_subdomain_optional_for_page_id_streaming`
- Rerun pool after run: `empty`

### Survival By Layer

| Layer | Entered | Failed | Survived | Layer survival | Cumulative survival |
| --- | ---: | ---: | ---: | ---: | ---: |
| Page-id reservation | 188 | 0 | 188 | 100.0% | 100.0% |
| Unresolved or returned to rerun pool | 188 | 0 | 188 | 100.0% | 100.0% |
| Page extraction, table grading, and QA generation | 188 | 202 | 0 | 0.0% | 0.0% |
| Rewrite and surface validation | 0 | 28 | 0 | 0.0% | 0.0% |
| DuckDuckGo long-tail filtering | 0 | 41 | 0 | 0.0% | 0.0% |
| Second-stage model grading | 0 | 17 | 0 | 0.0% | 0.0% |
| Shared route-aware validation | 0 | 34 | 0 | 0.0% | 0.0% |
| Deduplication | 0 | 0 | 0 | 0.0% | 0.0% |
| Other rejection | 0 | 0 | 0 | 0.0% | 0.0% |

### Failure Reasons

| Stage | Reason | Count |
| --- | --- | ---: |
| `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | 58 |
| `search_longtail` | `search_longtail_verifier_rejected` | 41 |
| `route_generation` | `wikipedia_infobox_table_filter_rejected:not_number_dominant` | 38 |
| `shared_validation` | `shared_validation_failed:answer_in_evidence` | 34 |
| `route_generation` | `wikipedia_infobox_no_tables` | 30 |
| `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded` | 17 |
| `route_generation` | `wikipedia_infobox_answer_type_not_allowed:answer_type_not_allowed:Number; allowed=Number` | 6 |
| `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any person's name.` | 5 |
| `rewrite_surface` | `rewrite_guard_rejected:answer_leakage` | 4 |
| `rewrite_surface` | `rule_based_answer_type_gate_rejected:place_question_category_whitelist` | 4 |
| `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any place name or geographic entity.` | 4 |
| `route_generation` | `wikipedia_infobox_table_filter_rejected:no_picture_heavy_tables` | 4 |
| `route_generation` | `wikipedia_infobox_table_filter_rejected:too_few_rows:row_count=2;min_rows=3` | 4 |
| `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_self_containment_forbidden_phrase:listed` | 3 |
| `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_self_containment_forbidden_phrase:table` | 3 |
| `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any date or year values.` | 3 |
| `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any date, year, or month information.` | 3 |
| `route_generation` | `wikipedia_infobox_table_filter_rejected:no_external_links_tables:external_links_section` | 3 |
| `rewrite_surface` | `rewrite_guard_rejected:cutoff_year_exceeded` | 2 |
| `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_answer_scope_ambiguous_phrase:type` | 2 |
| `route_generation` | `wikipedia_infobox_live_table_scope:live_table_scope:nearby_intro:current` | 2 |
| `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any person's name or information about a person.` | 2 |
| `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any person's names.` | 2 |
| `route_generation` | `wikipedia_infobox_table_filter_rejected:no_incomplete_tables` | 2 |
| `rewrite_surface` | `answer_too_popular:Japan` | 1 |
| `rewrite_surface` | `answer_too_popular:People's Republic of China` | 1 |
| `rewrite_surface` | `answer_too_popular:United Kingdom` | 1 |
| `rewrite_surface` | `rewrite_guard_rejected:forbidden_temporal_phrase` | 1 |
| `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_answer_scope_ambiguous_phrase:meaning` | 1 |
| `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_award_year_without_month` | 1 |
| `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_self_containment_forbidden_phrase:example` | 1 |
| `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_self_containment_forbidden_phrase:in_the_table` | 1 |
| `rewrite_surface` | `rule_based_answer_type_gate_rejected:date_standard_or_normalizable_format` | 1 |
| `rewrite_surface` | `rule_based_answer_type_gate_rejected:person_common_words_minus_common_names` | 1 |
| `route_generation` | `wikipedia_infobox_live_table_scope:live_table_scope:nearby_intro:present` | 1 |
| `route_generation` | `wikipedia_infobox_live_table_scope:live_table_scope:section_heading:current` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is present in the table; all entries are tone names, contours, or example characters.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No place name or geographic entity is present in the table; all entries relate to linguistic tones.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:The table contains no dates or temporal values.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any date or temporal information.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any date or year information.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any date or year values; it only lists competitions and statistics.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any date values.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any date, year, or month data.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any date, year, or month information to support a date-type question.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any numeric values suitable for a number answer.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any numeric values.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any person's name as a single factual answer.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any person's name as a sponsor or related entity.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any person's name as an answer; it only lists awards and years.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any person's name as an answer; it only lists competitions and statistics.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any person's name or individual person data.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any person's name; it only lists states and years.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any person's name; only cities, countries, regions, and dates are listed.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any person's name; only club names and other attributes are listed.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any person's name; only place names and administrative units are listed.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any person's name; only ranks and countries are listed.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any person's name; only team names and venues are listed.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any person's name; only words and their origins are listed.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any place name as an answer; it only lists competition names and stats.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any place name or geographic entity as a single factual answer.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any place name or geographic entity data.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any place name or geographic entity; it only lists words and their etymologies.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any place names or geographic entities other than the region Alsace–Lorraine itself, which is the subject, so no suitable place answer can be formed.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any place or geographic entity data.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any place or geographic entity information suitable for a place-type question.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any place or geographic entity information.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:The table does not provide any specific date, month, or year information related to awards or events.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:The table lists sponsors only, no place names are present.` | 1 |
| `route_generation` | `wikipedia_infobox_table_filter_rejected:too_few_rows:row_count=1;min_rows=3` | 1 |

### Answer Type Stats

| Scope | Answer type | Accepted | Rejected | Total | Accepted rate |
| --- | --- | ---: | ---: | ---: | ---: |
| Current Run Records | `Date` | 2 | 20 | 22 | 9.1% |
| Current Run Records | `Number` | 4 | 28 | 32 | 12.5% |
| Current Run Records | `Other` | 7 | 27 | 34 | 20.6% |
| Current Run Records | `Person` | 3 | 19 | 22 | 13.6% |
| Current Run Records | `Place` | 1 | 26 | 27 | 3.7% |
| Current Run Records | `unknown` | 0 | 202 | 202 | 0.0% |

### Reasoning Type Stats

| Scope | Reasoning type | Accepted | Rejected | Total | Accepted rate |
| --- | --- | ---: | ---: | ---: | ---: |
| Current Run Records | `single_fact` | 17 | 322 | 339 | 5.0% |

### Rerun Pool After Run

Rerun pool is empty.


### Phase Timings

Timing nesting: `wall_clock_seconds` is the whole run. `total_generation_seconds` contains page fetch/paragraph/table parse/LLM QA generation for one page. `total_processing_seconds` contains rewrite, number margin, DuckDuckGo search, second-stage grading when enabled, shared validation, and dedup checks for one generated candidate. `candidate_processing_seconds` is an alias of `total_processing_seconds`. Child phase totals are useful for bottlenecks, but they should not be added to parent totals.

| Pipeline order | Phase | Parent/child | Additive? | Meaning |
| ---: | --- | --- | --- | --- |
| 0 | `wall_clock_seconds` | run total | No | Elapsed time for the whole streaming command. |
| 1 | `page_fetch_seconds` | child of total_generation_seconds | Yes, within generation only | MediaWiki action=parse fetch for one page. |
| 2 | `first_paragraph_extract_seconds` | child of total_generation_seconds | Yes, within generation only | Local extraction of first paragraph from parse HTML. |
| 3 | `first_paragraph_fetch_seconds` | optional child of total_generation_seconds | Yes, within generation only | REST summary fallback when explicitly enabled and parse HTML lacks a paragraph. |
| 4 | `table_parse_seconds` | child of total_generation_seconds | Yes, within generation only | Local table/prose parsing and table ranking inputs. |
| 5 | `llm_question_generation_seconds` | child of total_generation_seconds | Yes, within generation only | Small-model Route 3 QA generation call. |
| 6 | `total_generation_seconds` | parent | No | Overall Route 3 generation time for one page. |
| 7 | `rewrite_seconds` | child of total_processing_seconds | Yes, within processing only | Shared rewrite call when enabled. |
| 8 | `number_reference_margin_seconds` | child of total_processing_seconds | Yes, within processing only | Numeric reference margin setup for Number answers. |
| 9 | `duckduckgo_search_seconds` | child of total_processing_seconds | Yes, within processing only | DuckDuckGo long-tail queries and leakage scoring. |
| 10 | `second_stage_grading_seconds` | optional child of total_processing_seconds | Yes, within processing only | Model-panel answerability grading when enabled. |
| 11 | `total_processing_seconds` | parent | No | Shared rewrite, filtering, grading, validation, and dedup processing for one candidate. |
| 12 | `candidate_processing_seconds` | alias | No | Alias of total_processing_seconds for compatibility. |

#### Current Run Phase Timings

| Phase | Count | Total seconds | Average seconds | Max seconds |
| --- | ---: | ---: | ---: | ---: |
| `candidate_processing_seconds` | 339 | 2297.5469 | 6.7774 | 67.0000 |
| `duckduckgo_search_seconds` | 75 | 2077.7263 | 27.7030 | 60.7234 |
| `first_paragraph_extract_seconds` | 195 | 10.6575 | 0.0547 | 0.1735 |
| `llm_question_generation_seconds` | 195 | 1457.1638 | 7.4726 | 12.4447 |
| `number_reference_margin_seconds` | 109 | 0.0003 | 0.0000 | 0.0002 |
| `page_fetch_seconds` | 339 | 0.0000 | 0.0000 | 0.0000 |
| `pageview_prefilter_seconds` | 339 | 0.0018 | 0.0000 | 0.0001 |
| `rewrite_seconds` | 137 | 0.0000 | 0.0000 | 0.0000 |
| `second_stage_grading_seconds` | 34 | 219.1893 | 6.4467 | 17.9728 |
| `table_parse_seconds` | 339 | 38.8295 | 0.1145 | 0.7009 |
| `total_generation_seconds` | 339 | 1887.1898 | 5.5669 | 16.7443 |
| `total_processing_seconds` | 339 | 2297.5469 | 6.7774 | 67.0000 |

## Accepted Candidates

| Page ID | Question | Answer | Source |
| ---: | --- | --- | --- |
| 628232 | In which competition did Park Ji-sung make 13 appearances without scoring any goals? | AFC Asian Cup | https://en.wikipedia.org/wiki/Park_Ji-sung |
| 219424 | Which country uses the NATO code OR-4 for the rank equivalent to Corporal in English? | Estonia | https://en.wikipedia.org/wiki/Sergeant |
| 524482 | What is the name of the award for which The Sopranos was nominated and won multiple times between 2000 and 2008? | Screen Actors Guild Award | https://en.wikipedia.org/wiki/Tony_Sirico |
| 368989 | Who is the author of the study that lists the Proto-Austronesian reflexes in Northwest Formosan languages? | Wolff | https://en.wikipedia.org/wiki/Formosan_languages |
| 188497 | What is the name of the ridge on the femur where the Adductor longus muscle inserts? | medial ridge of linea aspera | https://en.wikipedia.org/wiki/Femur |
| 2186423 | What was the peak position of Hallelujah on the US Rock Digital Songs chart between 2007 and 2010? | 11 | https://en.wikipedia.org/wiki/Hallelujah_(Leonard_Cohen_song) |
| 235916 | What role did Jada Pinkett Smith play in the 2022 episode titled 'Legacy' of The Equalizer? | Jessie "The Worm" Cook | https://en.wikipedia.org/wiki/Jada_Pinkett_Smith |
| 67211 | What is the condensed electron configuration symbol for the subshell containing 10 electrons in the 3d orbital? | 3d 10 4s 2 4p 6 | https://en.wikipedia.org/wiki/Electron_configuration |
| 604350 | Which broadcaster operates the New York City studio responsible for UN, New York, and Canada coverage? | WDR | https://en.wikipedia.org/wiki/ARD_(broadcaster) |
| 951393 | What is the term for the form of filial respect that involves using honorific language? | Linguistic respect | https://en.wikipedia.org/wiki/Filial_piety |
| 10149834 | Who is the Japanese voice actor for the character Ponyo in the eighth film Miyazaki directed for Studio Ghibli? | Yuuri Nara | https://en.wikipedia.org/wiki/Ponyo |
| 2924002 | How many categories are there in the DJ Awards for international DJs? | 11 | https://en.wikipedia.org/wiki/Electronic_dance_music |
| 84952 | In what year did Marvelous Marvin Hagler appear in the television show 227 as himself? | 1988 | https://en.wikipedia.org/wiki/Marvelous_Marvin_Hagler |
| 615800 | How many league appearances did Cafu make for Palmeiras in the 1996 Série A season? | 22 | https://en.wikipedia.org/wiki/Cafu |
| 277011 | What year is the scheduled Broadway run of Harry Potter and the Cursed Child featuring Tom Felton as Draco Malfoy? | 2025 | https://en.wikipedia.org/wiki/Tom_Felton |
| 812281 | What does a gold color designation signify about a player's Hall of Fame membership in the main international basketball competition for senior men's European national teams? | Member of both the FIBA Hall of Fame and the Naismith Memorial Basketball Hall of Fame | https://en.wikipedia.org/wiki/EuroBasket |
| 228600 | What is the global ranking number of the Agricultural Sciences program at Washington State University? | 34 | https://en.wikipedia.org/wiki/Washington_State_University |

## Second-Stage Filtering Responses

These are the small-model QA responses used by the second-stage filter: `openai/gpt-4.1-mini` and `google/gemini-3-flash-preview`.

| Page ID | Question | Reference answer | openai/gpt-4.1-mini | google/gemini-3-flash-preview |
| ---: | --- | --- | --- | --- |
| 628232 | In which competition did Park Ji-sung make 13 appearances without scoring any goals? | AFC Asian Cup | INCORRECT; predicted_answer: Park Ji-sung made 13 appearances without scoring any goals in the UEFA Champions League. | INCORRECT; predicted_answer: Park Ji-sung made 13 appearances without scoring a goal in the **FIFA World Cup** (across the 2002, 2006, and 2010 tournaments). |
| 219424 | Which country uses the NATO code OR-4 for the rank equivalent to Corporal in English? | Estonia | INCORRECT; predicted_answer: The country that uses the NATO code OR-4 for the rank equivalent to Corporal in English is Germany. In the German military, the rank corresponding to OR-4 is "Unteroffizier," which is equivalent to Corporal. | INCORRECT; predicted_answer: The NATO code **OR-4** is used for the rank of **Corporal** (or its equivalent) by the **United Kingdom**, **United States**, **Canada**, and **Australia**, among many other NATO and partner nations. |
| 524482 | What is the name of the award for which The Sopranos was nominated and won multiple times between 2000 and 2008? | Screen Actors Guild Award | INCORRECT; predicted_answer: The Sopranos was nominated for and won multiple Emmy Awards between 2000 and 2008. | INCORRECT; predicted_answer: The Sopranos won multiple **Primetime Emmy Awards**, including Outstanding Drama Series. |
| 368989 | Who is the author of the study that lists the Proto-Austronesian reflexes in Northwest Formosan languages? | Wolff | INCORRECT; predicted_answer: The author of the study that lists the Proto-Austronesian reflexes in Northwest Formosan languages is Robert Blust. | INCORRECT; predicted_answer: The author of the study is **Laurent Sagart**. The specific work is titled *"The Higher Phylogeny of Austronesian and the Position of Tai-Kadai"* (2004), which provides a detailed analysis of Proto-Austronesian reflexes in the Northwest Formosan languages (Saisiyat, Pazeh, and Kulon-Utu). |
| 188497 | What is the name of the ridge on the femur where the Adductor longus muscle inserts? | medial ridge of linea aspera | INCORRECT; predicted_answer: The Adductor longus muscle inserts on the **linea aspera** of the femur. | INCORRECT; predicted_answer: The **linea aspera** (specifically the middle third of the medial lip). |
| 2186423 | What was the peak position of Hallelujah on the US Rock Digital Songs chart between 2007 and 2010? | 11 (acceptable range: anything between 10 and 12) | INCORRECT; predicted_answer: The peak position of "Hallelujah" on the US Rock Digital Songs chart between 2007 and 2010 was number 2. | INCORRECT; predicted_answer: Jeff Buckley's version of "Hallelujah" peaked at **#1** on the US Rock Digital Songs chart in March 2008. |
| 235916 | What role did Jada Pinkett Smith play in the 2022 episode titled 'Legacy' of The Equalizer? | Jessie "The Worm" Cook | INCORRECT; predicted_answer: Jada Pinkett Smith played the role of Robyn McCall in the 2022 episode titled "Legacy" of The Equalizer. | INCORRECT; predicted_answer: Jada Pinkett Smith played **Jessie Cook**, a world-class thief and former colleague of Robyn McCall. |
| 67211 | What is the condensed electron configuration symbol for the subshell containing 10 electrons in the 3d orbital? | 3d 10 4s 2 4p 6 | INCORRECT; predicted_answer: The condensed electron configuration symbol for the subshell containing 10 electrons in the 3d orbital is **3d¹⁰**. | INCORRECT; predicted_answer: The condensed electron configuration symbol for that subshell is **3d¹⁰**. |
| 604350 | Which broadcaster operates the New York City studio responsible for UN, New York, and Canada coverage? | WDR | INCORRECT; predicted_answer: The broadcaster CBC operates the New York City studio responsible for UN, New York, and Canada coverage. | INCORRECT; predicted_answer: **Al Jazeera** operates the New York City studio (located at 1500 Broadway) responsible for its UN, New York, and Canada coverage. |
| 951393 | What is the term for the form of filial respect that involves using honorific language? | Linguistic respect | INCORRECT; predicted_answer: The term is **"language of filial piety"** or more specifically, **"honorific language"** used to express filial respect. In many cultures, especially in East Asia, using honorifics when speaking to or about one's parents is a key aspect of filial respect. | INCORRECT; predicted_answer: The term is **honorifics** (or **honorific speech**). In specific cultural contexts, such as East Asia, it is often referred to as **filial piety** (*xiao* in Chinese, *hyo* in Korean, *kō* in Japanese) expressed through **linguistic etiquette**. |
| 10149834 | Who is the Japanese voice actor for the character Ponyo in the eighth film Miyazaki directed for Studio Ghibli? | Yuuri Nara | INCORRECT; predicted_answer: The Japanese voice actor for the character Ponyo in Hayao Miyazaki's eighth film for Studio Ghibli, *Ponyo* (2008), is Yuria Nara. | INCORRECT; predicted_answer: The Japanese voice actor for Ponyo is **Yuria Nara**. |
| 2924002 | How many categories are there in the DJ Awards for international DJs? | 11 (acceptable range: anything between 10 and 12) | INCORRECT; predicted_answer: There are 9 categories in the DJ Awards for international DJs. | INCORRECT; predicted_answer: There are typically **between 10 and 12** categories specifically for international DJs, though the exact number varies by year.  In the most recent 2024 edition, there are **11** main DJ categories:  1.  **House** 2.  **Tech House** 3.  **Techno** 4.  **Progressive House** 5.  **Trance** 6.  **Afro** 7.  **Organic House** 8.  **Drum & Bass** 9.  **The Ritual** 1 |
| 84952 | In what year did Marvelous Marvin Hagler appear in the television show 227 as himself? | 1988 | INCORRECT; predicted_answer: Marvelous Marvin Hagler appeared as himself in the television show 227 in the year 1987. | INCORRECT; predicted_answer: Marvelous Marvin Hagler appeared as himself in the television show *227* in **1986** (Season 1, Episode 19, titled "The Fight"). |
| 615800 | How many league appearances did Cafu make for Palmeiras in the 1996 Série A season? | 22 (acceptable range: anything between 21 and 23) | INCORRECT; predicted_answer: Cafu made 19 league appearances for Palmeiras in the 1996 Série A season. | INCORRECT; predicted_answer: Cafu made **16** league appearances for Palmeiras during the 1996 Série A season. |
| 277011 | What year is the scheduled Broadway run of Harry Potter and the Cursed Child featuring Tom Felton as Draco Malfoy? | 2025 | INCORRECT; predicted_answer: The scheduled Broadway run of Harry Potter and the Cursed Child featuring Tom Felton as Draco Malfoy is in 2024. | INCORRECT; predicted_answer: There is no scheduled Broadway run of *Harry Potter and the Cursed Child* featuring Tom Felton. While Felton played Draco Malfoy in the film series, the role in the stage production is played by stage actors, and Felton has not been cast in the play. |
| 812281 | What does a gold color designation signify about a player's Hall of Fame membership in the main international basketball competition for senior men's European national teams? | Member of both the FIBA Hall of Fame and the Naismith Memorial Basketball Hall of Fame | INCORRECT; predicted_answer: A gold color designation signifies that the player is an inducted member of the FIBA Hall of Fame. | INCORRECT; predicted_answer: In the FIBA Hall of Fame, a gold color designation signifies that the individual was inducted as a **Player**. |
| 228600 | What is the global ranking number of the Agricultural Sciences program at Washington State University? | 34 (acceptable range: anything between 33 and 35) | INCORRECT; predicted_answer: The Agricultural Sciences program at Washington State University is ranked #51 globally. | INCORRECT; predicted_answer: Washington State University’s Agricultural Sciences program is ranked **#18** in the world according to the 2024-2025 U.S. News & World Report Best Global Universities rankings. |
| 9119 | Distinguished Service Medal (U.S. Army) |  | not run | not run |
| 231031 | University of Western Australia |  | not run | not run |
| 10477 | Eos |  | not run | not run |
| 257453 | Butte, Montana |  | not run | not run |
| 963152 | Spaniards |  | not run | not run |
| 173652 | Hemorrhoid |  | not run | not run |
| 76165 | Pontiac (automobile) |  | not run | not run |
| 9316 | England |  | not run | not run |
| 70298 | Midwest League |  | not run | not run |
| 255999 | Who wrote the lyrics for the song "Stairway to Heaven"? | Robert Plant | not run | not run |
| 255999 | Which country’s singles chart did "Stairway to Heaven" peak at position 5 in 2007–10? | Norway | not run | not run |
| 255999 | What was the peak position of "Stairway to Heaven" on the UK Singles Chart between 2007 and 2010? | 37 | not run | not run |
| 255999 | On what month, day, and year was "Stairway to Heaven" released? | November 8, 1971 | not run | not run |
| 255999 | What record label released the song "Stairway to Heaven"? | Atlantic Records | not run | not run |
| 1674887 | EBSCO Information Services |  | not run | not run |
| 24218875 | Deadline Hollywood |  | not run | not run |
| 498538 | University of New Hampshire |  | not run | not run |
| 372315 | Moscow Oblast |  | not run | not run |
| 37284 | Brain tumor |  | not run | not run |
| 37284 | Brain tumor |  | not run | not run |
| 37284 | How many types of primary brain tumors originating from astrocytes are listed for children in the table? | 1 | not run | not run |
| 37284 | Brain tumor |  | not run | not run |
| 37284 | What is the name of the primary brain tumor originating from neurons in children? | Medulloblastoma | CORRECT; predicted_answer: The primary brain tumor originating from neurons in children is called a **medulloblastoma**. | not run |
| 29125601 | Flemish people |  | not run | not run |
| 972904 | Vibe (magazine) |  | not run | not run |
| 49188979 | Normandy (administrative region) |  | not run | not run |
| 32611 | Vietnam War |  | not run | not run |
| 628232 | Park Ji-sung |  | not run | not run |
| 628232 | Park Ji-sung |  | not run | not run |
| 628232 | How many goals did Park Ji-sung score in FIFA World Cup qualification matches? | 6 | not run | not run |
| 628232 | Park Ji-sung |  | not run | not run |
| 4836072 | My Fair Lady (film) |  | not run | not run |
| 453433 | Scallion |  | not run | not run |
| 309294 | Albany, Western Australia |  | not run | not run |
| 82075 | Santa Cruz County, California |  | not run | not run |
| 50762105 | Emphysema |  | not run | not run |
| 22948 | Poseidon |  | not run | not run |
| 3968 | Bodhisattva |  | not run | not run |
| 8196151 | List of states of Mexico |  | not run | not run |
| 200152 | Mombasa |  | not run | not run |
| 219424 | Sergeant |  | not run | not run |
| 8318491 | Southeastern Anatolia region |  | not run | not run |
| 306966 | Kataeb Party |  | not run | not run |
| 35972636 | ORMO |  | not run | not run |
| 206997 | Who was the Imperial Governor of Alsace–Lorraine starting in 1885? | Chlodwig zu Hohenlohe-Schillingsfürst | INCORRECT; predicted_answer: The Imperial Governor of Alsace–Lorraine starting in 1885 was Count Gustav von Goßler. | CORRECT; predicted_answer: **Chlodwig, Prince of Hohenlohe-Schillingsfürst**, served as the Imperial Governor (*Reichsstatthalter*) of Alsace-Lorraine starting in 1885. |
| 206997 | Alsace–Lorraine |  | not run | not run |
| 206997 | How many years did Hermann zu Hohenlohe-Langenburg serve as Imperial Governor of Alsace–Lorraine? | 13 | not run | not run |
| 206997 | What year did Karl von Wedel begin his term as Imperial Governor of Alsace–Lorraine? | 1907 | INCORRECT; predicted_answer: Karl von Wedel began his term as Imperial Governor of Alsace–Lorraine in 1914. | CORRECT; predicted_answer: Karl von Wedel began his term as Imperial Governor (Statthalter) of Alsace–Lorraine in **1907**. |
| 206997 | What official title was held by Eduard von Moeller in Alsace–Lorraine from 1871 to 1879? | Oberpräsident | not run | not run |
| 31740 | University of Michigan |  | not run | not run |
| 588981 | Provinces of Bulgaria |  | not run | not run |
| 588981 | Which city was the only district included in the Sofia oblast between 1987 and 1998? | Sofia City | not run | not run |
| 588981 | How many former districts comprised the Razgrad oblast between 1987 and 1998? | 4 | not run | not run |
| 588981 | In what year were the 28 districts of Bulgaria transformed into 9 large provinces called oblasts? | 1987 | not run | not run |
| 588981 | What is the Bulgarian term for the first-level administrative subdivisions of Bulgaria since 1999? | области | not run | not run |
| 4248 | Bowls |  | not run | not run |
| 135276 | Jackson, Tennessee |  | not run | not run |
| 180174 | Niagara Falls, Ontario |  | not run | not run |
| 180174 | What is the name of the venue where the Niagara Falls Canucks play their home games? | Gale Centre | not run | not run |
| 180174 | How many championships has the Niagara Falls Canucks ice hockey team won? | 2 | not run | not run |
| 180174 | In what year was the Niagara United soccer club established? | 2010 | INCORRECT; predicted_answer: The Niagara United soccer club was established in 2011. | CORRECT; predicted_answer: Niagara United was established in **2010**. |
| 180174 | What sport does the Niagara United club play? | Soccer | not run | not run |
| 36624 | Embryo |  | not run | not run |
| 62633 | Les Invalides |  | not run | not run |
| 21355232 | List of national parks of the United States |  | not run | not run |
| 21355232 | Which U.S. state has the highest number of total national parks? | California | not run | not run |
| 21355232 | How many exclusive national parks are located in Alaska? | 8 | not run | not run |
| 21355232 | List of national parks of the United States |  | not run | not run |
| 21355232 | What is the total number of national parks in the state of Utah? | 5 | not run | not run |
| 55440889 | Pixel 2 |  | not run | not run |
| 68481047 | Fall of Kabul (2021) |  | not run | not run |
| 24516 | Who was the ancient Greek historian responsible for the creation of the Polybius square cipher? | Polybius | not run | not run |
| 24516 | Which ancient civilization's alphabet was originally used by Polybius to implement his cipher square? | Greece | not run | not run |
| 24516 | How many rows are there in the Polybius square cipher table? | 5 | not run | not run |
| 24516 | In what century BC did Polybius live? | 2nd century BC | not run | not run |
| 24516 | What letter pair is combined into a single cell in the Polybius square cipher table? | I/J | not run | not run |
| 10522749 | International Music Score Library Project |  | not run | not run |
| 5816 | Cenozoic |  | not run | not run |
| 524482 | Tony Sirico |  | not run | not run |
| 524482 | Tony Sirico |  | not run | not run |
| 524482 | How many times was The Sopranos nominated for the Screen Actors Guild Award for Outstanding Performance by an Ensemble in a Drama Series between 2000 and 2008? | 6 | not run | not run |
| 524482 | In what year did The Sopranos win the Screen Actors Guild Award for Outstanding Performance by an Ensemble in a Drama Series for the first time? | 2000 | not run | not run |
| 13169 | Gneiss |  | not run | not run |
| 20608 | Messier object |  | not run | not run |
| 269408 | Colonial Brazil |  | not run | not run |
| 413714 | Padma Bhushan |  | not run | not run |
| 6920895 | PDC World Darts Championship |  | not run | not run |
| 45367389 | Greater London |  | not run | not run |
| 157774 | Permafrost |  | not run | not run |
| 741851 | Rough Trade Records |  | not run | not run |
| 2500 | Anus |  | not run | not run |
| 500004 | On-Line Encyclopedia of Integer Sequences |  | not run | not run |
| 29781 | The Texas Chain Saw Massacre |  | not run | not run |
| 288514 | Pixie |  | not run | not run |
| 240432 | Provinces of Argentina |  | not run | not run |
| 205058 | Who was the Emperor of Japan during the Heisei era? | Akihito | not run | not run |
| 205058 | What country did the Heisei era take place in? | Japan | not run | not run |
| 205058 | What is the Heisei year number corresponding to the Gregorian year 2000? | 12 | not run | not run |
| 205058 | What month, day, and year did the Heisei era begin? | January 8, 1989 | not run | not run |
| 205058 | What is the Roman numeral representation of Heisei year 25? | XXV | INCORRECT; predicted_answer: Heisei year 25 corresponds to the year 2013 in the Gregorian calendar. The Roman numeral for 2013 is **MMXIII**. | CORRECT; predicted_answer: The Roman numeral representation of Heisei year 25 (2013) is **XXV**. |
| 62149 | Custard |  | not run | not run |
| 295691 | Collège de France |  | not run | not run |
| 188497 | Femur |  | not run | not run |
| 188497 | What is the name of the bone located in the thigh region between the hip and the knee? | femur | not run | not run |
| 188497 | How many muscles listed have their insertion attachment on the greater trochanter of the femur? | 5 | not run | not run |
| 188497 | Femur |  | not run | not run |
| 2186423 | Who originally wrote the song Hallelujah? | Leonard Cohen | not run | not run |
| 2186423 | Which country's official singles chart listed Hallelujah at position 97 between 2007 and 2010? | United Kingdom | not run | not run |
| 2856052 | Haenyeo |  | not run | not run |
| 30450289 | Regional units of Greece |  | not run | not run |
| 287299 | Sarcoidosis |  | not run | not run |
| 292259 | Deutsche Welle |  | not run | not run |
| 380167 | Achilles tendon |  | not run | not run |
| 457055 | Comune |  | not run | not run |
| 83934 | Norwegian resistance movement |  | not run | not run |
| 186191 | T-72 |  | not run | not run |
| 55417368 | 2016 Australian census |  | not run | not run |
| 637543 | Grand Duchy of Finland |  | not run | not run |
| 15355864 | 2015 Pan American Games |  | not run | not run |
| 15355864 | 2015 Pan American Games |  | not run | not run |
| 15355864 | 2015 Pan American Games |  | not run | not run |
| 15355864 | 2015 Pan American Games |  | not run | not run |
| 15355864 | What company was the Lead Partner sponsor of the 2015 Pan American Games? | Chevrolet Canada | not run | not run |
| 306853 | Jyutping |  | not run | not run |
| 306853 | Jyutping |  | not run | not run |
| 306853 | What is the tone number assigned to the Cantonese tone with a contour of ˧˥? | 2 | not run | not run |
| 306853 | Jyutping |  | not run | not run |
| 306853 | What is the Jyutping romanization for the Cantonese character example representing the high level tone (陰平)? | fan1 | not run | not run |
| 87627 | Amur Oblast |  | not run | not run |
| 89514 | New London, Connecticut |  | not run | not run |
| 235916 | Who played the role of Christina Hawthorne in the television series that aired from 2009 to 2011? | Jada Pinkett Smith | not run | not run |
| 235916 | Jada Pinkett Smith |  | not run | not run |
| 235916 | How many episodes did Jada Pinkett Smith appear in as Lena James in the television series A Different World? | 46 | not run | not run |
| 235916 | In what year did Jada Pinkett Smith first appear in the television series True Colors? | 1990 | not run | not run |
| 67127 | Carl Lewis |  | not run | not run |
| 143117 | Gujarati language |  | not run | not run |
| 143117 | Gujarati language |  | not run | not run |
| 143117 | What is the number of native speakers of the Gujarati language in millions as of 2011? | 55.5 | not run | not run |
| 143117 | What year marks the approximate period of Old Gujarati from which modern Gujarati descended? | 1100 | not run | not run |
| 143117 | What is the Old Indo-Aryan word for 'tiger' that is the source of the Gujarati word 'vāgh'? | vyāghrá | CORRECT; predicted_answer: The Old Indo-Aryan word for 'tiger' that is the source of the Gujarati word **vāgh** is **vyāghra**. | not run |
| 67211 | Electron configuration |  | not run | not run |
| 67211 | Electron configuration |  | not run | not run |
| 67211 | How many electrons are in the 4f subshell according to the condensed electron configuration table? | 14 | not run | not run |
| 67211 | Electron configuration |  | not run | not run |
| 4236415 | Ashvins |  | not run | not run |
| 1050340 | Election Day (United States) |  | not run | not run |
| 26211 | Racketeer Influenced and Corrupt Organizations Act |  | not run | not run |
| 81890 | Fife |  | not run | not run |
| 32133 | Urethra |  | not run | not run |
| 6392374 | Sea captain |  | not run | not run |
| 697535 | AllMusic |  | not run | not run |
| 1290366 | Amir Khan (boxer) |  | not run | not run |
| 1290366 | Amir Khan (boxer) |  | not run | not run |
| 1290366 | How many total professional boxing fights did Amir Khan have in his career? | 40 | not run | not run |
| 1290366 | Amir Khan (boxer) |  | not run | not run |
| 1290366 | How many of Amir Khan's professional boxing wins were by knockout? | 21 | CORRECT; predicted_answer: Amir Khan has 34 professional boxing wins, of which 21 were by knockout. | not run |
| 66958 | Who is the issuing authority of the official currency of the People's Republic of China? | People's Bank of China | not run | not run |
| 66958 | What country uses the renminbi as its official currency? | People's Republic of China | not run | not run |
| 66958 | What is the fractional value of one fen in terms of one yuan in the renminbi currency system? | 0.01 | not run | not run |
| 66958 | As of what month and year is the renminbi the world's fifth-most-traded currency? | April 2025 | not run | not run |
| 66958 | What is the literal English translation of the formal currency name 'renminbi'? | people's currency | not run | not run |
| 8971303 | Chivas USA |  | not run | not run |
| 226734 | States of Nigeria |  | not run | not run |
| 226734 | What is the name of the state created in the South-Eastern region of Nigeria in 1996? | Ebonyi | CORRECT; predicted_answer: The state created in the South-Eastern region of Nigeria in 1996 is Ebonyi State. | not run |
| 226734 | How many states were created in the Western region of Nigeria in 1987? | 2 | not run | not run |
| 226734 | In what year was the state of Akwa Ibom created in Nigeria? | 1987 | not run | not run |
| 226734 | What is the name of the region that included the state of Bendel before it was split into Delta and Edo? | Mid-Western | not run | not run |
| 2839 | Angular momentum |  | not run | not run |
| 2043650 | Uncut (magazine) |  | not run | not run |
| 458762 | Convair B-58 Hustler |  | not run | not run |
| 190884 | Khalid Sheikh Mohammed |  | not run | not run |
| 910914 | Young Artist Award |  | not run | not run |
| 64300 | Bart Simpson |  | not run | not run |
| 618770 | Who played the role of Hedda Gabler in the 1981 Yale Repertory Theatre production? | Dianne Wiest | not run | not run |
| 618770 | At which theatre was the 1982 production of Othello featuring Dianne Wiest as Desdemona performed? | Winter Garden Theatre | not run | not run |
| 618770 | In what year was the play 'Les Liaisons Dangereuses' performed at the Williamstown Theatre Festival with Dianne Wiest? | 1988 | not run | not run |
| 618770 | What year did Dianne Wiest perform in the play 'Scene Partners' at the Vineyard Theatre? | 2023 | not run | not run |
| 618770 | What role did Dianne Wiest play in the 2003 production of Salome at the Ethel Barrymore Theatre? | Herodias | not run | not run |
| 46989 | Grand Canyon |  | not run | not run |
| 60382764 | Reiwa era |  | not run | not run |
| 22707 | Oolong |  | not run | not run |
| 22093 | National Basketball Association |  | not run | not run |
| 64384 | Pieter Bruegel the Elder |  | not run | not run |
| 10209822 | Edward the Elder |  | not run | not run |
| 7632 | Cerebrospinal fluid |  | not run | not run |
| 22450 | Open-wheel car |  | not run | not run |
| 521893 | Voiced bilabial plosive |  | not run | not run |
| 56636 | Colombo |  | not run | not run |
| 56636 | What city in Russia is a twin town of Colombo? | Saint Petersburg | not run | not run |
| 56636 | Since what year has Colombo been twinned with the city of Biratnagar in Nepal? | 1874 | not run | not run |
| 56636 | In what year did Colombo establish a twin town relationship with Shanghai, China? | 2003 | INCORRECT; predicted_answer: Colombo established a twin town relationship with Shanghai, China, in the year 1985. | CORRECT; predicted_answer: Colombo established a twin town relationship with Shanghai in **2003**. |
| 56636 | What is the name of the region where the twin town Malé of Colombo is located? | Kaafu Atoll | INCORRECT; predicted_answer: The twin town Malé of Colombo is located in the region of the Maldives. | CORRECT; predicted_answer: The twin town of Colombo is **Malé**, which is located in the **Kaafu Atoll** (also known as the Malé Atoll) in the Republic of Maldives. |
| 246305 | Livorno |  | not run | not run |
| 479512 | Better Business Bureau |  | not run | not run |
| 171623 | Training Day |  | not run | not run |
| 31388 | Treaty of Brest-Litovsk |  | not run | not run |
| 5489 | Chile |  | not run | not run |
| 72760 | Square kilometre |  | not run | not run |
| 1003268 | Which person is colloquially associated with the stage of the English language known as Early Modern English? | William Shakespeare | not run | not run |
| 1003268 | What geographic region is primarily associated with the Early Modern English language stage? | England | not run | not run |
| 1003268 | How many types of consonant manners of articulation are listed in the Early Modern English consonants table? | 6 | not run | not run |
| 1003268 | What century marks the beginning of the Early Modern English period? | 15 | not run | not run |
| 1003268 | What is the phonetic symbol for the postalveolar fricative consonant in Early Modern English? | ʃ | CORRECT; predicted_answer: The phonetic symbol for the postalveolar fricative consonant in Early Modern English is /ʃ/. | not run |
| 5070109 | Spanish Armada |  | not run | not run |
| 57708 | Topeka, Kansas |  | not run | not run |
| 57708 | What city is the location of the television stations KTWU, WIBW-TV, and KSNT? | Topeka | not run | not run |
| 57708 | What is the digital channel number for the NBC network station licensed to Topeka? | 27 | not run | not run |
| 57708 | Topeka, Kansas |  | not run | not run |
| 57708 | What is the callsign of the FOX network television station licensed to Topeka? | KTMJ-CD | CORRECT; predicted_answer: The callsign of the FOX network television station licensed to Topeka is KTMJ-CD. | not run |
| 17416221 | South Africa |  | not run | not run |
| 30125638 | Cubic metre |  | not run | not run |
| 63503 | Duluth, Minnesota |  | not run | not run |
| 404204 | November Uprising |  | not run | not run |
| 74011 | Who won the Academy Award for Best Actor for the film High Noon? | Gary Cooper | not run | not run |
| 74011 | High Noon |  | not run | not run |
| 74011 | How many Academy Awards did the film High Noon win? | 4 | not run | not run |
| 74011 | High Noon |  | not run | not run |
| 74011 | What song won the Academy Award for Best Song for the film High Noon? | The Ballad of High Noon | not run | not run |
| 56617 | Bangui |  | not run | not run |
| 129295 | Fatal Attraction |  | not run | not run |
| 10893 | Fencing |  | not run | not run |
| 40176 | Joseph Priestley |  | not run | not run |
| 40158 | Berchtesgaden |  | not run | not run |
| 951393 | Who is the multi-cultural researcher that added eight more forms of elder respect to the traditional five in Confucian texts? | Kyu-taik Sung | not run | not run |
| 951393 | What type of place is associated with spatial respect in filial piety, where graves are built respectfully? | graves | not run | not run |
| 951393 | How many additional forms of elder respect did Kyu-taik Sung add to the traditional five forms in Confucian texts? | 8 | not run | not run |
| 951393 | Filial piety |  | not run | not run |
| 313647 | Mpumalanga |  | not run | not run |
| 415156 | XXX (2002 film) |  | not run | not run |
| 152333 | Provinces of Belgium |  | not run | not run |
| 880255 | Alex Karras |  | not run | not run |
| 2507138 | First Austrian Republic |  | not run | not run |
| 204971 | Historic counties of England |  | not run | not run |
| 187544 | Hermann Weyl |  | not run | not run |
| 2924002 | Who was the winner of the Best Dance/Electronic Music Album Grammy Award in 2025? | FKA twigs | not run | not run |
| 2924002 | In which city is the DJ Awards ceremony held annually? | Ibiza | not run | not run |
| 60058274 | Licorice Pizza |  | not run | not run |
| 84952 | Who appeared as himself in the 1986 episode of Saturday Night Live? | Marvelous Marvin Hagler | not run | not run |
| 84952 | In which television show did Marvelous Marvin Hagler appear as a guest in 1985 that is named after a morning news program? | Good Morning America | not run | not run |
| 84952 | How many episodes of The Tonight Show Starring Johnny Carson featured Marvelous Marvin Hagler as a guest? | 4 | not run | not run |
| 82050 | Royal Norwegian Navy |  | not run | not run |
| 105908 | Ford Mustang |  | not run | not run |
| 176871 | Convair F-106 Delta Dart |  | not run | not run |
| 8429 | Density |  | not run | not run |
| 534617 | Who was the artist that painted the original Care Bears in 1981? | Elena Kucharik | not run | not run |
| 534617 | In what type of location did the Care Bears first appear as greeting cards in the 1980s? | Greeting cards | not run | not run |
| 534617 | How many feature films were released during the 1982 launch of the Care Bears franchise? | 3 | not run | not run |
| 534617 | What year did the Care Bears Movie II: A New Generation first appear? | 1986 | not run | not run |
| 534617 | What is the name of the 2019 Care Bears franchise iteration that introduced new world-building and adventure-focused storytelling? | Unlock the Magic | not run | not run |
| 5643 | Channel Islands |  | not run | not run |
| 2310937 | 2000 NFL season |  | not run | not run |
| 109566 | Winter Park, Florida |  | not run | not run |
| 83115 | 1968 Summer Olympics |  | not run | not run |
| 615800 | Who scored 3 goals in the 1994 Série A season for São Paulo? | Cafu | not run | not run |
| 615800 | In which city did Cafu play club football during the 1997–98 Serie A season? | Rome | not run | not run |
| 329529 | Harvard Medical School |  | not run | not run |
| 57951 | Provinces of the Netherlands |  | not run | not run |
| 57951 | What city was the capital of the Department of the Rhine during the Batavian Republic? | Arnhem | INCORRECT; predicted_answer: The capital of the Department of the Rhine during the Batavian Republic was Mannheim. | CORRECT; predicted_answer: **Arnhem** was the capital of the Department of the Rhine (*Departement van de Rijn*) during the Batavian Republic. |
| 57951 | How many departments were created in the Netherlands during the Batavian Republic reorganization from 1798 to 1801? | 8 | not run | not run |
| 57951 | In what year did the Batavian Republic reorganize the Netherlands into new departments? | 1798 | not run | not run |
| 57951 | What was the Dutch name of the department with its capital at Alkmaar during the Batavian Republic? | Departement van Texel | CORRECT; predicted_answer: The Dutch name of the department with its capital at Alkmaar during the Batavian Republic was **Departement van Texel**. | not run |
| 54232 | Reinforced concrete |  | not run | not run |
| 3351466 | Capezio |  | not run | not run |
| 277011 | Who played the role of Sam in the 2022 West End production of 2:22 A Ghost Story? | Tom Felton | not run | not run |
| 277011 | At which theatre was the 2022 West End production of 2:22 A Ghost Story performed? | Criterion Theatre | not run | not run |
| 277011 | In what year did Tom Felton perform in the West End production of 2:22 A Ghost Story? | 2022 | not run | not run |
| 1582694 | Wisden Cricketers' Almanack |  | not run | not run |
| 182283 | Miles per hour |  | not run | not run |
| 28901997 | Critics' Choice Awards |  | not run | not run |
| 601094 | Korma |  | not run | not run |
| 901117 | Ujjain |  | not run | not run |
| 901117 | What is the name of the railway zone that operates the Ujjain city railway stations? | Western Railway | not run | not run |
| 901117 | How many total platforms does Ujjain Junction railway station have? | 8 | not run | not run |
| 901117 | Ujjain |  | not run | not run |
| 901117 | What is the station code for the Vikramnagar railway station in Ujjain? | VRG | not run | not run |
| 248339 | Brandon, Manitoba |  | not run | not run |
| 41853326 | Inter Miami CF |  | not run | not run |
| 41853326 | Inter Miami CF |  | not run | not run |
| 41853326 | What number season did Inter Miami first have Royal Caribbean as their shirt sponsor? | 2024 | not run | not run |
| 41853326 | In what year did Inter Miami start having Lowe's as their sleeve sponsor? | 2026 | not run | not run |
| 41853326 | What company was the sleeve sponsor for Inter Miami in the 2022 season? | Xmanna | not run | not run |
| 812281 | Which player has won the MVP award twice in the main international basketball competition for senior men's European national teams? | Krešimir Ćosić | not run | not run |
| 812281 | EuroBasket |  | not run | not run |
| 812281 | How many times was Nikos Galis the Top Scorer in the main international basketball competition for senior men's European national teams? | 4 | not run | not run |
| 812281 | EuroBasket |  | not run | not run |
| 610522 | MobyGames |  | not run | not run |
| 81572 | Bristol Blenheim |  | not run | not run |
| 134987 | Rapid City, South Dakota |  | not run | not run |
| 42229472 | Glottolog |  | not run | not run |
| 14610495 | 2 Girls 1 Cup |  | not run | not run |
| 142549 | Peritonitis |  | not run | not run |
| 1048946 | Chamorro people |  | not run | not run |
| 199445 | Who is the English football player with 120 international appearances and 53 goals? | Wayne Rooney | not run | not run |
| 199445 | Which country did Wayne Rooney represent in international football matches from 2003 to 2018? | England | not run | not run |
| 199445 | How many international goals did Wayne Rooney score for England in 2014? | 8 | not run | not run |
| 199445 | In what year did Wayne Rooney make 11 international appearances for England and score 6 goals? | 2004 | CORRECT; predicted_answer: Wayne Rooney made 11 international appearances for England and scored 6 goals in the year 2004. | not run |
| 199445 | What is the total number of international appearances Wayne Rooney made for England? | 120 | not run | not run |
| 422038 | Vigo |  | not run | not run |
| 312038 | Kṣitigarbha |  | not run | not run |
| 33643148 | Jam band |  | not run | not run |
| 540034 | Amyloidosis |  | not run | not run |
| 4595410 | 1970 United States census |  | not run | not run |
| 524850 | Voiced palatal approximant |  | not run | not run |
| 524850 | In which country is the word meaning 'wedding' that features a voiced palatal approximant used? | Turkey | not run | not run |
| 524850 | Voiced palatal approximant |  | not run | not run |
| 524850 | Voiced palatal approximant |  | not run | not run |
| 524850 | What is the IPA symbol used to represent the lenited allophone of /ɡ/ before front vowels in Spanish as shown in the table? | ɣ | not run | not run |
| 33134 | World music |  | not run | not run |
| 19746798 | Here Technologies |  | not run | not run |
| 650522 | Sickle |  | not run | not run |
| 228600 | Washington State University |  | not run | not run |
| 228600 | Washington State University |  | not run | not run |
| 8083 | Who did Dr. Dre voice in the 2005 video game 50 Cent: Bulletproof? | Grizz | not run | not run |
| 8083 | In which video game did Dr. Dre appear as himself in 2020? | Grand Theft Auto Online: The Cayo Perico Heist | not run | not run |
| 8083 | What year was the video game released in which Dr. Dre voiced the character Grizz? | 2005 | not run | not run |
| 8083 | What year was the video game Grand Theft Auto Online: The Contract, featuring Dr. Dre as himself, released? | 2021 | not run | not run |
| 8083 | What role did Dr. Dre play in the 2021 video game Grand Theft Auto Online: The Contract? | Himself | INCORRECT; predicted_answer: In the 2021 video game Grand Theft Auto Online: The Contract, Dr. Dre played the role of himself, acting as a key character who helps the player recover stolen music tracks and navigate the music industry within the game's storyline. | CORRECT; predicted_answer: In *Grand Theft Auto Online: The Contract*, Dr. Dre plays **himself** as the central protagonist of the expansion's story.  His role involves hiring the player’s agency to track down and recover his stolen smartphone, which contains unreleased music. In addition to appearing in motion-captured cutscenes, Dr. Dre premiered six new, exclusive songs within the game. |
| 404595 | NCAA Division I Football Championship |  | not run | not run |
| 404595 | What city hosted the NCAA Division I Football Championship games during the 1989 to 1991 seasons? | Statesboro | not run | not run |
| 404595 | How many title games did the Marshall Thundering Herd participate in during the 1992 to 1996 seasons? | 4 | not run | not run |
| 404595 | In what year was the NCAA Division I Football Championship game held at Hughes Stadium in Sacramento, California? | 1980 | INCORRECT; predicted_answer: The NCAA Division I Football Championship game was held at Hughes Stadium in Sacramento, California, in 1992. | CORRECT; predicted_answer: The NCAA Division I Football Championship game (then known as the Division I-AA Championship) was held at Hughes Stadium in **1980**. |
| 404595 | What is the name of the stadium that hosted the NCAA Division I Football Championship games from 2013 to 2025? | Toyota Stadium | not run | not run |


## Rejected And Rerun Decisions

| Page ID | Stage | Exact reason | Page/question |
| ---: | --- | --- | --- |
| 9119 | `route_generation` | `wikipedia_infobox_no_tables` | Distinguished Service Medal (U.S. Army) |
| 231031 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | University of Western Australia |
| 10477 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | Eos |
| 257453 | `route_generation` | `wikipedia_infobox_table_filter_rejected:not_number_dominant:comma_number_count=29` | Butte, Montana |
| 963152 | `route_generation` | `wikipedia_infobox_table_filter_rejected:no_incomplete_tables:citation needed` | Spaniards |
| 173652 | `route_generation` | `wikipedia_infobox_table_filter_rejected:no_picture_heavy_tables:wikitable_image_cell_count=8` | Hemorrhoid |
| 76165 | `route_generation` | `wikipedia_infobox_table_filter_rejected:not_number_dominant:comma_number_count=9` | Pontiac (automobile) |
| 9316 | `route_generation` | `wikipedia_infobox_table_filter_rejected:not_number_dominant:comma_number_count=3` | England |
| 70298 | `route_generation` | `wikipedia_infobox_live_table_scope:live_table_scope:section_heading:current` | Midwest League |
| 255999 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | Who wrote the lyrics for the song "Stairway to Heaven"? |
| 255999 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | Which country’s singles chart did "Stairway to Heaven" peak at position 5 in 2007–10? |
| 255999 | `search_longtail` | `search_longtail_verifier_rejected:keyword_queries:hit_rate_exceeded` | What was the peak position of "Stairway to Heaven" on the UK Singles Chart between 2007 and 2010? |
| 255999 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | On what month, day, and year was "Stairway to Heaven" released? |
| 255999 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | What record label released the song "Stairway to Heaven"? |
| 1674887 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | EBSCO Information Services |
| 24218875 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | Deadline Hollywood |
| 498538 | `route_generation` | `wikipedia_infobox_table_filter_rejected:not_number_dominant:comma_number_count=2` | University of New Hampshire |
| 372315 | `route_generation` | `wikipedia_infobox_table_filter_rejected:not_number_dominant:comma_number_count=12` | Moscow Oblast |
| 37284 | `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any person's name.` | Brain tumor |
| 37284 | `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any place name or geographic entity.` | Brain tumor |
| 37284 | `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_self_containment_forbidden_phrase:listed` | How many types of primary brain tumors originating from astrocytes are listed for children in the table? |
| 37284 | `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any date, year, or month information.` | Brain tumor |
| 37284 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What is the name of the primary brain tumor originating from neurons in children? |
| 29125601 | `route_generation` | `wikipedia_infobox_no_tables` | Flemish people |
| 972904 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | Vibe (magazine) |
| 49188979 | `route_generation` | `wikipedia_infobox_table_filter_rejected:not_number_dominant:decimal_number_count=9` | Normandy (administrative region) |
| 32611 | `route_generation` | `wikipedia_infobox_table_filter_rejected:too_few_rows:row_count=2;min_rows=3` | Vietnam War |
| 628232 | `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any person's name as an answer; it only lists competitions and statistics.` | Park Ji-sung |
| 628232 | `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any place name as an answer; it only lists competition names and stats.` | Park Ji-sung |
| 628232 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | How many goals did Park Ji-sung score in FIFA World Cup qualification matches? |
| 628232 | `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any date or year values; it only lists competitions and statistics.` | Park Ji-sung |
| 4836072 | `route_generation` | `wikipedia_infobox_table_filter_rejected:no_incomplete_tables:clarification needed` | My Fair Lady (film) |
| 453433 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | Scallion |
| 309294 | `route_generation` | `wikipedia_infobox_table_filter_rejected:not_number_dominant:decimal_number_count=27` | Albany, Western Australia |
| 82075 | `route_generation` | `wikipedia_infobox_table_filter_rejected:not_number_dominant:comma_number_count=90` | Santa Cruz County, California |
| 50762105 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | Emphysema |
| 22948 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | Poseidon |
| 3968 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | Bodhisattva |
| 8196151 | `route_generation` | `wikipedia_infobox_no_tables` | List of states of Mexico |
| 200152 | `route_generation` | `wikipedia_infobox_table_filter_rejected:not_number_dominant:unit_marker=cm` | Mombasa |
| 219424 | `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any person's name; only ranks and countries are listed.` | Sergeant |
| 8318491 | `route_generation` | `wikipedia_infobox_no_tables` | Southeastern Anatolia region |
| 306966 | `route_generation` | `wikipedia_infobox_table_filter_rejected:not_number_dominant:decimal_number_count=3` | Kataeb Party |
| 35972636 | `route_generation` | `wikipedia_infobox_no_tables` | ORMO |
| 206997 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | Who was the Imperial Governor of Alsace–Lorraine starting in 1885? |
| 206997 | `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any place names or geographic entities other than the region Alsace–Lorraine itself, which is the subject, so no suitable place answer can be formed.` | Alsace–Lorraine |
| 206997 | `route_generation` | `wikipedia_infobox_answer_type_not_allowed:answer_type_not_allowed:Number; allowed=Number` | How many years did Hermann zu Hohenlohe-Langenburg serve as Imperial Governor of Alsace–Lorraine? |
| 206997 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What year did Karl von Wedel begin his term as Imperial Governor of Alsace–Lorraine? |
| 206997 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | What official title was held by Eduard von Moeller in Alsace–Lorraine from 1871 to 1879? |
| 31740 | `route_generation` | `wikipedia_infobox_table_filter_rejected:not_number_dominant:comma_number_count=7` | University of Michigan |
| 588981 | `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any person's name.` | Provinces of Bulgaria |
| 588981 | `search_longtail` | `search_longtail_verifier_rejected:keyword_query_1:answer_in_title` | Which city was the only district included in the Sofia oblast between 1987 and 1998? |
| 588981 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | How many former districts comprised the Razgrad oblast between 1987 and 1998? |
| 588981 | `search_longtail` | `search_longtail_verifier_rejected:keyword_queries:hit_rate_exceeded` | In what year were the 28 districts of Bulgaria transformed into 9 large provinces called oblasts? |
| 588981 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | What is the Bulgarian term for the first-level administrative subdivisions of Bulgaria since 1999? |
| 4248 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | Bowls |
| 135276 | `route_generation` | `wikipedia_infobox_table_filter_rejected:not_number_dominant:comma_number_count=6` | Jackson, Tennessee |
| 180174 | `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any person's name; only club names and other attributes are listed.` | Niagara Falls, Ontario |
| 180174 | `search_longtail` | `search_longtail_verifier_rejected:keyword_query_2:answer_in_title` | What is the name of the venue where the Niagara Falls Canucks play their home games? |
| 180174 | `search_longtail` | `search_longtail_verifier_rejected:keyword_queries:hit_rate_exceeded` | How many championships has the Niagara Falls Canucks ice hockey team won? |
| 180174 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | In what year was the Niagara United soccer club established? |
| 180174 | `search_longtail` | `search_longtail_verifier_rejected:full_question:answer_in_title` | What sport does the Niagara United club play? |
| 36624 | `route_generation` | `wikipedia_infobox_table_filter_rejected:too_few_rows:row_count=1;min_rows=3` | Embryo |
| 62633 | `route_generation` | `wikipedia_infobox_no_tables` | Les Invalides |
| 21355232 | `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any person's name or information about a person.` | List of national parks of the United States |
| 21355232 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | Which U.S. state has the highest number of total national parks? |
| 21355232 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | How many exclusive national parks are located in Alaska? |
| 21355232 | `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any date, year, or month information.` | List of national parks of the United States |
| 21355232 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | What is the total number of national parks in the state of Utah? |
| 55440889 | `route_generation` | `wikipedia_infobox_table_filter_rejected:not_number_dominant:unit_marker=g` | Pixel 2 |
| 68481047 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | Fall of Kabul (2021) |
| 24516 | `rewrite_surface` | `rewrite_guard_rejected:answer_leakage` | Who was the ancient Greek historian responsible for the creation of the Polybius square cipher? |
| 24516 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | Which ancient civilization's alphabet was originally used by Polybius to implement his cipher square? |
| 24516 | `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_self_containment_forbidden_phrase:table` | How many rows are there in the Polybius square cipher table? |
| 24516 | `rewrite_surface` | `rule_based_answer_type_gate_rejected:date_standard_or_normalizable_format` | In what century BC did Polybius live? |
| 24516 | `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_self_containment_forbidden_phrase:table` | What letter pair is combined into a single cell in the Polybius square cipher table? |
| 10522749 | `route_generation` | `wikipedia_infobox_no_tables` | International Music Score Library Project |
| 5816 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | Cenozoic |
| 524482 | `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any person's name as an answer; it only lists awards and years.` | Tony Sirico |
| 524482 | `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any place name or geographic entity.` | Tony Sirico |
| 524482 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | How many times was The Sopranos nominated for the Screen Actors Guild Award for Outstanding Performance by an Ensemble in a Drama Series between 2000 and 2008? |
| 524482 | `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_award_year_without_month` | In what year did The Sopranos win the Screen Actors Guild Award for Outstanding Performance by an Ensemble in a Drama Series for the first time? |
| 13169 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | Gneiss |
| 20608 | `route_generation` | `wikipedia_infobox_no_tables` | Messier object |
| 269408 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | Colonial Brazil |
| 413714 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | Padma Bhushan |
| 6920895 | `route_generation` | `wikipedia_infobox_table_filter_rejected:not_number_dominant:word_marker=million` | PDC World Darts Championship |
| 45367389 | `route_generation` | `wikipedia_infobox_live_table_scope:live_table_scope:nearby_intro:current` | Greater London |
| 157774 | `route_generation` | `wikipedia_infobox_table_filter_rejected:not_number_dominant:unit_marker=ft,m` | Permafrost |
| 741851 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | Rough Trade Records |
| 2500 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | Anus |
| 500004 | `route_generation` | `wikipedia_infobox_table_filter_rejected:not_number_dominant:out_of_allowed_no_comma_range_count=1` | On-Line Encyclopedia of Integer Sequences |
| 29781 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | The Texas Chain Saw Massacre |
| 288514 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | Pixie |
| 240432 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | Provinces of Argentina |
| 205058 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | Who was the Emperor of Japan during the Heisei era? |
| 205058 | `rewrite_surface` | `answer_too_popular:Japan` | What country did the Heisei era take place in? |
| 205058 | `route_generation` | `wikipedia_infobox_answer_type_not_allowed:answer_type_not_allowed:Number; allowed=Number` | What is the Heisei year number corresponding to the Gregorian year 2000? |
| 205058 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | What month, day, and year did the Heisei era begin? |
| 205058 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What is the Roman numeral representation of Heisei year 25? |
| 62149 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | Custard |
| 295691 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | Collège de France |
| 188497 | `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any person's names.` | Femur |
| 188497 | `rewrite_surface` | `rule_based_answer_type_gate_rejected:place_question_category_whitelist` | What is the name of the bone located in the thigh region between the hip and the knee? |
| 188497 | `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_self_containment_forbidden_phrase:listed` | How many muscles listed have their insertion attachment on the greater trochanter of the femur? |
| 188497 | `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any date or temporal information.` | Femur |
| 2186423 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | Who originally wrote the song Hallelujah? |
| 2186423 | `rewrite_surface` | `answer_too_popular:United Kingdom` | Which country's official singles chart listed Hallelujah at position 97 between 2007 and 2010? |
| 2856052 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | Haenyeo |
| 30450289 | `route_generation` | `wikipedia_infobox_no_tables` | Regional units of Greece |
| 287299 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | Sarcoidosis |
| 292259 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | Deutsche Welle |
| 380167 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | Achilles tendon |
| 457055 | `route_generation` | `wikipedia_infobox_table_filter_rejected:not_number_dominant:comma_number_count=60` | Comune |
| 83934 | `route_generation` | `wikipedia_infobox_no_tables` | Norwegian resistance movement |
| 186191 | `route_generation` | `wikipedia_infobox_table_filter_rejected:not_number_dominant:unit_marker=m` | T-72 |
| 55417368 | `route_generation` | `wikipedia_infobox_table_filter_rejected:no_picture_heavy_tables:wikitable_image_cell_count=34` | 2016 Australian census |
| 637543 | `route_generation` | `wikipedia_infobox_no_tables` | Grand Duchy of Finland |
| 15355864 | `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any person's name as a sponsor or related entity.` | 2015 Pan American Games |
| 15355864 | `route_generation` | `wikipedia_infobox_llm_discarded:The table lists sponsors only, no place names are present.` | 2015 Pan American Games |
| 15355864 | `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any numeric values.` | 2015 Pan American Games |
| 15355864 | `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any date values.` | 2015 Pan American Games |
| 15355864 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | What company was the Lead Partner sponsor of the 2015 Pan American Games? |
| 306853 | `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is present in the table; all entries are tone names, contours, or example characters.` | Jyutping |
| 306853 | `route_generation` | `wikipedia_infobox_llm_discarded:No place name or geographic entity is present in the table; all entries relate to linguistic tones.` | Jyutping |
| 306853 | `search_longtail` | `search_longtail_verifier_rejected:keyword_queries:hit_rate_exceeded` | What is the tone number assigned to the Cantonese tone with a contour of ˧˥? |
| 306853 | `route_generation` | `wikipedia_infobox_llm_discarded:The table contains no dates or temporal values.` | Jyutping |
| 306853 | `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_self_containment_forbidden_phrase:example` | What is the Jyutping romanization for the Cantonese character example representing the high level tone (陰平)? |
| 87627 | `route_generation` | `wikipedia_infobox_table_filter_rejected:not_number_dominant:comma_number_count=8` | Amur Oblast |
| 89514 | `route_generation` | `wikipedia_infobox_table_filter_rejected:not_number_dominant:unit_marker=cm` | New London, Connecticut |
| 235916 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | Who played the role of Christina Hawthorne in the television series that aired from 2009 to 2011? |
| 235916 | `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any place or geographic entity information suitable for a place-type question.` | Jada Pinkett Smith |
| 235916 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | How many episodes did Jada Pinkett Smith appear in as Lena James in the television series A Different World? |
| 235916 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | In what year did Jada Pinkett Smith first appear in the television series True Colors? |
| 67127 | `route_generation` | `wikipedia_infobox_table_filter_rejected:no_external_links_tables:external_links_section` | Carl Lewis |
| 143117 | `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any person's name; only words and their origins are listed.` | Gujarati language |
| 143117 | `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any place name or geographic entity; it only lists words and their etymologies.` | Gujarati language |
| 143117 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | What is the number of native speakers of the Gujarati language in millions as of 2011? |
| 143117 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | What year marks the approximate period of Old Gujarati from which modern Gujarati descended? |
| 143117 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What is the Old Indo-Aryan word for 'tiger' that is the source of the Gujarati word 'vāgh'? |
| 67211 | `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any person's name or information about a person.` | Electron configuration |
| 67211 | `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any place name or geographic entity.` | Electron configuration |
| 67211 | `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_self_containment_forbidden_phrase:table` | How many electrons are in the 4f subshell according to the condensed electron configuration table? |
| 67211 | `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any date, year, or month information.` | Electron configuration |
| 4236415 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | Ashvins |
| 1050340 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | Election Day (United States) |
| 26211 | `route_generation` | `wikipedia_infobox_no_tables` | Racketeer Influenced and Corrupt Organizations Act |
| 81890 | `route_generation` | `wikipedia_infobox_table_filter_rejected:not_number_dominant:comma_number_count=37` | Fife |
| 32133 | `route_generation` | `wikipedia_infobox_table_filter_rejected:not_number_dominant:unit_marker=cm` | Urethra |
| 6392374 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | Sea captain |
| 697535 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | AllMusic |
| 1290366 | `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any person's name.` | Amir Khan (boxer) |
| 1290366 | `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any place name or geographic entity.` | Amir Khan (boxer) |
| 1290366 | `search_longtail` | `search_longtail_verifier_rejected:keyword_query_1:answer_in_title` | How many total professional boxing fights did Amir Khan have in his career? |
| 1290366 | `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any date or year values.` | Amir Khan (boxer) |
| 1290366 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | How many of Amir Khan's professional boxing wins were by knockout? |
| 66958 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | Who is the issuing authority of the official currency of the People's Republic of China? |
| 66958 | `rewrite_surface` | `answer_too_popular:People's Republic of China` | What country uses the renminbi as its official currency? |
| 66958 | `rewrite_surface` | `rewrite_guard_rejected:answer_leakage` | What is the fractional value of one fen in terms of one yuan in the renminbi currency system? |
| 66958 | `rewrite_surface` | `rewrite_guard_rejected:forbidden_temporal_phrase` | As of what month and year is the renminbi the world's fifth-most-traded currency? |
| 66958 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | What is the literal English translation of the formal currency name 'renminbi'? |
| 8971303 | `route_generation` | `wikipedia_infobox_table_filter_rejected:no_picture_heavy_tables:wikitable_image_cell_count=5` | Chivas USA |
| 226734 | `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any person's name; it only lists states and years.` | States of Nigeria |
| 226734 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What is the name of the state created in the South-Eastern region of Nigeria in 1996? |
| 226734 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | How many states were created in the Western region of Nigeria in 1987? |
| 226734 | `search_longtail` | `search_longtail_verifier_rejected:keyword_queries:hit_rate_exceeded` | In what year was the state of Akwa Ibom created in Nigeria? |
| 226734 | `search_longtail` | `search_longtail_verifier_rejected:keyword_queries:hit_rate_exceeded` | What is the name of the region that included the state of Bendel before it was split into Delta and Edo? |
| 2839 | `route_generation` | `wikipedia_infobox_table_filter_rejected:no_picture_heavy_tables:wikitable_image_cell_count=8` | Angular momentum |
| 2043650 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | Uncut (magazine) |
| 458762 | `route_generation` | `wikipedia_infobox_no_tables` | Convair B-58 Hustler |
| 190884 | `route_generation` | `wikipedia_infobox_no_tables` | Khalid Sheikh Mohammed |
| 910914 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | Young Artist Award |
| 64300 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | Bart Simpson |
| 618770 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | Who played the role of Hedda Gabler in the 1981 Yale Repertory Theatre production? |
| 618770 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | At which theatre was the 1982 production of Othello featuring Dianne Wiest as Desdemona performed? |
| 618770 | `route_generation` | `wikipedia_infobox_answer_type_not_allowed:answer_type_not_allowed:Number; allowed=Number` | In what year was the play 'Les Liaisons Dangereuses' performed at the Williamstown Theatre Festival with Dianne Wiest? |
| 618770 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | What year did Dianne Wiest perform in the play 'Scene Partners' at the Vineyard Theatre? |
| 618770 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | What role did Dianne Wiest play in the 2003 production of Salome at the Ethel Barrymore Theatre? |
| 46989 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | Grand Canyon |
| 60382764 | `route_generation` | `wikipedia_infobox_table_filter_rejected:too_few_rows:row_count=2;min_rows=3` | Reiwa era |
| 22707 | `route_generation` | `wikipedia_infobox_no_tables` | Oolong |
| 22093 | `route_generation` | `wikipedia_infobox_table_filter_rejected:not_number_dominant:alpha_character_rate=0.4308` | National Basketball Association |
| 64384 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | Pieter Bruegel the Elder |
| 10209822 | `route_generation` | `wikipedia_infobox_table_filter_rejected:no_external_links_tables:external_links_section` | Edward the Elder |
| 7632 | `route_generation` | `wikipedia_infobox_table_filter_rejected:not_number_dominant:unit_marker=mg` | Cerebrospinal fluid |
| 22450 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | Open-wheel car |
| 521893 | `route_generation` | `wikipedia_infobox_table_filter_rejected:no_external_links_tables:external_links_section` | Voiced bilabial plosive |
| 56636 | `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any person's name; only cities, countries, regions, and dates are listed.` | Colombo |
| 56636 | `rewrite_surface` | `rewrite_guard_rejected:answer_leakage` | What city in Russia is a twin town of Colombo? |
| 56636 | `route_generation` | `wikipedia_infobox_answer_type_not_allowed:answer_type_not_allowed:Number; allowed=Number` | Since what year has Colombo been twinned with the city of Biratnagar in Nepal? |
| 56636 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | In what year did Colombo establish a twin town relationship with Shanghai, China? |
| 56636 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What is the name of the region where the twin town Malé of Colombo is located? |
| 246305 | `route_generation` | `wikipedia_infobox_table_filter_rejected:not_number_dominant:decimal_number_count=142` | Livorno |
| 479512 | `route_generation` | `wikipedia_infobox_no_tables` | Better Business Bureau |
| 171623 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | Training Day |
| 31388 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | Treaty of Brest-Litovsk |
| 5489 | `route_generation` | `wikipedia_infobox_table_filter_rejected:not_number_dominant:unit_marker=km` | Chile |
| 72760 | `route_generation` | `wikipedia_infobox_no_tables` | Square kilometre |
| 1003268 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | Which person is colloquially associated with the stage of the English language known as Early Modern English? |
| 1003268 | `rewrite_surface` | `rewrite_guard_rejected:answer_leakage` | What geographic region is primarily associated with the Early Modern English language stage? |
| 1003268 | `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_self_containment_forbidden_phrase:listed` | How many types of consonant manners of articulation are listed in the Early Modern English consonants table? |
| 1003268 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | What century marks the beginning of the Early Modern English period? |
| 1003268 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What is the phonetic symbol for the postalveolar fricative consonant in Early Modern English? |
| 5070109 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | Spanish Armada |
| 57708 | `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any person's names.` | Topeka, Kansas |
| 57708 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | What city is the location of the television stations KTWU, WIBW-TV, and KSNT? |
| 57708 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | What is the digital channel number for the NBC network station licensed to Topeka? |
| 57708 | `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any date or year values.` | Topeka, Kansas |
| 57708 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What is the callsign of the FOX network television station licensed to Topeka? |
| 17416221 | `route_generation` | `wikipedia_infobox_table_filter_rejected:not_number_dominant:unit_marker=km` | South Africa |
| 30125638 | `route_generation` | `wikipedia_infobox_no_tables` | Cubic metre |
| 63503 | `route_generation` | `wikipedia_infobox_live_table_scope:live_table_scope:nearby_intro:current` | Duluth, Minnesota |
| 404204 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | November Uprising |
| 74011 | `search_longtail` | `search_longtail_verifier_rejected:keyword_queries:hit_rate_exceeded` | Who won the Academy Award for Best Actor for the film High Noon? |
| 74011 | `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any place or geographic entity information.` | High Noon |
| 74011 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | How many Academy Awards did the film High Noon win? |
| 74011 | `route_generation` | `wikipedia_infobox_llm_discarded:The table does not provide any specific date, month, or year information related to awards or events.` | High Noon |
| 74011 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | What song won the Academy Award for Best Song for the film High Noon? |
| 56617 | `route_generation` | `wikipedia_infobox_table_filter_rejected:not_number_dominant:comma_number_count=2` | Bangui |
| 129295 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | Fatal Attraction |
| 10893 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | Fencing |
| 40176 | `route_generation` | `wikipedia_infobox_no_tables` | Joseph Priestley |
| 40158 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | Berchtesgaden |
| 951393 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | Who is the multi-cultural researcher that added eight more forms of elder respect to the traditional five in Confucian texts? |
| 951393 | `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_answer_scope_ambiguous_phrase:type` | What type of place is associated with spatial respect in filial piety, where graves are built respectfully? |
| 951393 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | How many additional forms of elder respect did Kyu-taik Sung add to the traditional five forms in Confucian texts? |
| 951393 | `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any date, year, or month information to support a date-type question.` | Filial piety |
| 313647 | `route_generation` | `wikipedia_infobox_no_tables` | Mpumalanga |
| 415156 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | XXX (2002 film) |
| 152333 | `route_generation` | `wikipedia_infobox_live_table_scope:live_table_scope:nearby_intro:present` | Provinces of Belgium |
| 880255 | `route_generation` | `wikipedia_infobox_table_filter_rejected:too_few_rows:row_count=2;min_rows=3` | Alex Karras |
| 2507138 | `route_generation` | `wikipedia_infobox_no_tables` | First Austrian Republic |
| 204971 | `route_generation` | `wikipedia_infobox_no_tables` | Historic counties of England |
| 187544 | `route_generation` | `wikipedia_infobox_no_tables` | Hermann Weyl |
| 2924002 | `rewrite_surface` | `rewrite_guard_rejected:cutoff_year_exceeded` | Who was the winner of the Best Dance/Electronic Music Album Grammy Award in 2025? |
| 2924002 | `search_longtail` | `search_longtail_verifier_rejected:full_question:answer_in_title` | In which city is the DJ Awards ceremony held annually? |
| 60058274 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | Licorice Pizza |
| 84952 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | Who appeared as himself in the 1986 episode of Saturday Night Live? |
| 84952 | `rewrite_surface` | `rule_based_answer_type_gate_rejected:place_question_category_whitelist` | In which television show did Marvelous Marvin Hagler appear as a guest in 1985 that is named after a morning news program? |
| 84952 | `search_longtail` | `search_longtail_verifier_rejected:keyword_queries:hit_rate_exceeded` | How many episodes of The Tonight Show Starring Johnny Carson featured Marvelous Marvin Hagler as a guest? |
| 82050 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | Royal Norwegian Navy |
| 105908 | `route_generation` | `wikipedia_infobox_table_filter_rejected:not_number_dominant:comma_number_count=10` | Ford Mustang |
| 176871 | `route_generation` | `wikipedia_infobox_no_tables` | Convair F-106 Delta Dart |
| 8429 | `route_generation` | `wikipedia_infobox_table_filter_rejected:not_number_dominant:unit_marker=kg` | Density |
| 534617 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | Who was the artist that painted the original Care Bears in 1981? |
| 534617 | `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_answer_scope_ambiguous_phrase:type` | In what type of location did the Care Bears first appear as greeting cards in the 1980s? |
| 534617 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | How many feature films were released during the 1982 launch of the Care Bears franchise? |
| 534617 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | What year did the Care Bears Movie II: A New Generation first appear? |
| 534617 | `search_longtail` | `search_longtail_verifier_rejected:full_question:answer_in_title` | What is the name of the 2019 Care Bears franchise iteration that introduced new world-building and adventure-focused storytelling? |
| 5643 | `route_generation` | `wikipedia_infobox_table_filter_rejected:not_number_dominant:unit_marker=acres,km,mi` | Channel Islands |
| 2310937 | `route_generation` | `wikipedia_infobox_table_filter_rejected:not_number_dominant:unit_marker=yards` | 2000 NFL season |
| 109566 | `route_generation` | `wikipedia_infobox_table_filter_rejected:not_number_dominant:comma_number_count=10` | Winter Park, Florida |
| 83115 | `route_generation` | `wikipedia_infobox_table_filter_rejected:too_few_rows:row_count=2;min_rows=3` | 1968 Summer Olympics |
| 615800 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | Who scored 3 goals in the 1994 Série A season for São Paulo? |
| 615800 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | In which city did Cafu play club football during the 1997–98 Serie A season? |
| 329529 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | Harvard Medical School |
| 57951 | `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any person's name; only place names and administrative units are listed.` | Provinces of the Netherlands |
| 57951 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What city was the capital of the Department of the Rhine during the Batavian Republic? |
| 57951 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | How many departments were created in the Netherlands during the Batavian Republic reorganization from 1798 to 1801? |
| 57951 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | In what year did the Batavian Republic reorganize the Netherlands into new departments? |
| 57951 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What was the Dutch name of the department with its capital at Alkmaar during the Batavian Republic? |
| 54232 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | Reinforced concrete |
| 3351466 | `route_generation` | `wikipedia_infobox_no_tables` | Capezio |
| 277011 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | Who played the role of Sam in the 2022 West End production of 2:22 A Ghost Story? |
| 277011 | `search_longtail` | `search_longtail_verifier_rejected:keyword_query_2:answer_in_title` | At which theatre was the 2022 West End production of 2:22 A Ghost Story performed? |
| 277011 | `route_generation` | `wikipedia_infobox_answer_type_not_allowed:answer_type_not_allowed:Number; allowed=Number` | In what year did Tom Felton perform in the West End production of 2:22 A Ghost Story? |
| 1582694 | `route_generation` | `wikipedia_infobox_table_filter_rejected:not_number_dominant:decimal_number_count=1` | Wisden Cricketers' Almanack |
| 182283 | `route_generation` | `wikipedia_infobox_table_filter_rejected:not_number_dominant:unit_marker=ft,km,mi,mph,m` | Miles per hour |
| 28901997 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | Critics' Choice Awards |
| 601094 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | Korma |
| 901117 | `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any person's name.` | Ujjain |
| 901117 | `rewrite_surface` | `rule_based_answer_type_gate_rejected:place_question_category_whitelist` | What is the name of the railway zone that operates the Ujjain city railway stations? |
| 901117 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | How many total platforms does Ujjain Junction railway station have? |
| 901117 | `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any date or year information.` | Ujjain |
| 901117 | `search_longtail` | `search_longtail_verifier_rejected:full_question:answer_in_title` | What is the station code for the Vikramnagar railway station in Ujjain? |
| 248339 | `route_generation` | `wikipedia_infobox_table_filter_rejected:not_number_dominant:comma_number_count=30` | Brandon, Manitoba |
| 41853326 | `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any person's name as a single factual answer.` | Inter Miami CF |
| 41853326 | `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any place name or geographic entity as a single factual answer.` | Inter Miami CF |
| 41853326 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | What number season did Inter Miami first have Royal Caribbean as their shirt sponsor? |
| 41853326 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | In what year did Inter Miami start having Lowe's as their sleeve sponsor? |
| 41853326 | `search_longtail` | `search_longtail_verifier_rejected:full_question:answer_in_title` | What company was the sleeve sponsor for Inter Miami in the 2022 season? |
| 812281 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | Which player has won the MVP award twice in the main international basketball competition for senior men's European national teams? |
| 812281 | `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any place or geographic entity data.` | EuroBasket |
| 812281 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | How many times was Nikos Galis the Top Scorer in the main international basketball competition for senior men's European national teams? |
| 812281 | `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any date, year, or month data.` | EuroBasket |
| 610522 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | MobyGames |
| 81572 | `route_generation` | `wikipedia_infobox_no_tables` | Bristol Blenheim |
| 134987 | `route_generation` | `wikipedia_infobox_table_filter_rejected:not_number_dominant:comma_number_count=6` | Rapid City, South Dakota |
| 42229472 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | Glottolog |
| 14610495 | `route_generation` | `wikipedia_infobox_no_tables` | 2 Girls 1 Cup |
| 142549 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | Peritonitis |
| 1048946 | `route_generation` | `wikipedia_infobox_no_tables` | Chamorro people |
| 199445 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | Who is the English football player with 120 international appearances and 53 goals? |
| 199445 | `search_longtail` | `search_longtail_verifier_rejected:keyword_query_1:answer_in_title` | Which country did Wayne Rooney represent in international football matches from 2003 to 2018? |
| 199445 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | How many international goals did Wayne Rooney score for England in 2014? |
| 199445 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | In what year did Wayne Rooney make 11 international appearances for England and score 6 goals? |
| 199445 | `search_longtail` | `search_longtail_verifier_rejected:keyword_queries:hit_rate_exceeded` | What is the total number of international appearances Wayne Rooney made for England? |
| 422038 | `route_generation` | `wikipedia_infobox_table_filter_rejected:not_number_dominant:unit_marker=ft,metres,millimetres,m` | Vigo |
| 312038 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | Kṣitigarbha |
| 33643148 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | Jam band |
| 540034 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | Amyloidosis |
| 4595410 | `route_generation` | `wikipedia_infobox_no_tables` | 1970 United States census |
| 524850 | `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any person's name.` | Voiced palatal approximant |
| 524850 | `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_answer_scope_ambiguous_phrase:meaning` | In which country is the word meaning 'wedding' that features a voiced palatal approximant used? |
| 524850 | `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any numeric values suitable for a number answer.` | Voiced palatal approximant |
| 524850 | `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any date or year values.` | Voiced palatal approximant |
| 524850 | `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_self_containment_forbidden_phrase:in_the_table` | What is the IPA symbol used to represent the lenited allophone of /ɡ/ before front vowels in Spanish as shown in the table? |
| 33134 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | World music |
| 19746798 | `route_generation` | `wikipedia_infobox_no_tables` | Here Technologies |
| 650522 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=wikitable;available=infobox` | Sickle |
| 228600 | `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any person's name or individual person data.` | Washington State University |
| 228600 | `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any place name or geographic entity data.` | Washington State University |
| 8083 | `rewrite_surface` | `rule_based_answer_type_gate_rejected:person_common_words_minus_common_names` | Who did Dr. Dre voice in the 2005 video game 50 Cent: Bulletproof? |
| 8083 | `rewrite_surface` | `rule_based_answer_type_gate_rejected:place_question_category_whitelist` | In which video game did Dr. Dre appear as himself in 2020? |
| 8083 | `route_generation` | `wikipedia_infobox_answer_type_not_allowed:answer_type_not_allowed:Number; allowed=Number` | What year was the video game released in which Dr. Dre voiced the character Grizz? |
| 8083 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | What year was the video game Grand Theft Auto Online: The Contract, featuring Dr. Dre as himself, released? |
| 8083 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What role did Dr. Dre play in the 2021 video game Grand Theft Auto Online: The Contract? |
| 404595 | `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any person's name; only team names and venues are listed.` | NCAA Division I Football Championship |
| 404595 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | What city hosted the NCAA Division I Football Championship games during the 1989 to 1991 seasons? |
| 404595 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | How many title games did the Marshall Thundering Herd participate in during the 1992 to 1996 seasons? |
| 404595 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | In what year was the NCAA Division I Football Championship game held at Hughes Stadium in Sacramento, California? |
| 404595 | `rewrite_surface` | `rewrite_guard_rejected:cutoff_year_exceeded` | What is the name of the stadium that hosted the NCAA Division I Football Championship games from 2013 to 2025? |


