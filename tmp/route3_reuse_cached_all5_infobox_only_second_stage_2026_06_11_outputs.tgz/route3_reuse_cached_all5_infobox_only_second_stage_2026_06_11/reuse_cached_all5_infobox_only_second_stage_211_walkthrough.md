# Route 3 Streaming Wikipedia Page-ID Walkthrough - 2026-06-11

## Stats

- Run group ID: `route3_reuse_cached_all5_infobox_only_second_stage_2026_06_11`
- Run segment ID: `reuse_cached_all5_infobox_only_second_stage_211`
- Artifact manifest: `/home/chenyue/Wikidata_Framework_aws/outputs/run_manifests/route3_reuse_cached_all5_infobox_only_second_stage_2026_06_11.json`
- Mode: `page_id_stream`
- Page source: `table-search`
- Table-search queries: `insource:"wikitable"`
- Attempted page IDs: 188
- Unique attempted page IDs: 188
- Stream state reset at run start: yes
- Accepted QAs: 30
- Rejected QAs/pages: 522
- Transient rerun attempts during run: 0
- Wall-clock runtime: 1158.0612s
- DuckDuckGo top K: 5
- Generated search queries per QA: 2
- DuckDuckGo parallel queries: 3
- DuckDuckGo ddgs primary path: `enabled`, backend `auto`, attempts 2
- DuckDuckGo global cooldown: `enabled`, threshold 3, 60.0s to 300.0s
- Minimum Route 3 table score: 0.0
- Route 3 reasoning_type constraint: `single_fact`
- Route 3 table filter modes: `no_external_links_tables, no_horizontal_companion_tables, no_picture_heavy_tables, no_incomplete_tables, not_number_dominant, no_social_science_research`
- Route 3 table source types: `infobox`
- Route 3 prose-leakage scoring: `enabled`
- Route 3 LLM table choice: `disabled`
- Stream page workers: 4
- Wikipedia concurrency limit: 4
- Wikipedia 429 backoff: 30.0s base, 300.0s max, 120.0s recovery
- DuckDuckGo service concurrency limit: 4
- OpenRouter generation/rewrite concurrency limit: 10
- Second-stage concurrency limit: 10
- Page-id bounds: 1 to 80000000
- Stream state: `outputs/recipe_segments/route3_reuse_cached_all5_infobox_only_second_stage_2026_06_11/reuse_cached_all5_infobox_only_second_stage_211_state.json`
- Accepted output: `outputs/recipe_segments/route3_reuse_cached_all5_infobox_only_second_stage_2026_06_11/reuse_cached_all5_infobox_only_second_stage_211_accepted.jsonl`
- Rejected output: `outputs/recipe_segments/route3_reuse_cached_all5_infobox_only_second_stage_2026_06_11/reuse_cached_all5_infobox_only_second_stage_211_rejected.jsonl`
- Domain policy: `domain_and_subdomain_optional_for_page_id_streaming`
- Rerun pool after run: `empty`

### Survival By Layer

| Layer | Entered | Failed | Survived | Layer survival | Cumulative survival |
| --- | ---: | ---: | ---: | ---: | ---: |
| Page-id reservation | 188 | 0 | 188 | 100.0% | 100.0% |
| Unresolved or returned to rerun pool | 188 | 0 | 188 | 100.0% | 100.0% |
| Page extraction, table grading, and QA generation | 188 | 209 | 0 | 0.0% | 0.0% |
| Rewrite and surface validation | 0 | 96 | 0 | 0.0% | 0.0% |
| DuckDuckGo long-tail filtering | 0 | 132 | 0 | 0.0% | 0.0% |
| Second-stage model grading | 0 | 66 | 0 | 0.0% | 0.0% |
| Shared route-aware validation | 0 | 19 | 0 | 0.0% | 0.0% |
| Deduplication | 0 | 0 | 0 | 0.0% | 0.0% |
| Other rejection | 0 | 0 | 0 | 0.0% | 0.0% |

### Failure Reasons

| Stage | Reason | Count |
| --- | --- | ---: |
| `search_longtail` | `search_longtail_verifier_rejected` | 132 |
| `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded` | 66 |
| `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=infobox;available=wikitable` | 46 |
| `route_generation` | `wikipedia_infobox_no_tables` | 30 |
| `route_generation` | `wikipedia_infobox_answer_type_not_allowed:answer_type_not_allowed:Number; allowed=Number` | 25 |
| `shared_validation` | `shared_validation_failed:answer_in_evidence` | 19 |
| `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_self_containment_forbidden_phrase:infobox` | 16 |
| `rewrite_surface` | `answer_too_popular:United States` | 13 |
| `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_self_containment_forbidden_phrase:listed` | 12 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is present in the infobox to form a valid question.` | 12 |
| `rewrite_surface` | `rewrite_guard_rejected:answer_leakage` | 8 |
| `rewrite_surface` | `rule_based_answer_type_gate_rejected:person_common_words_minus_common_names` | 8 |
| `rewrite_surface` | `rule_based_answer_type_gate_rejected:place_question_category_whitelist` | 8 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is present in the infobox to form a valid single-answer question.` | 7 |
| `rewrite_surface` | `answer_too_popular:English` | 6 |
| `route_generation` | `wikipedia_infobox_single_fact_list_answer:single_fact_list_answer_not_allowed` | 5 |
| `rewrite_surface` | `answer_too_popular:London` | 4 |
| `rewrite_surface` | `rewrite_guard_rejected:cutoff_year_exceeded` | 4 |
| `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_time_invariance_forbidden_phrase:current` | 4 |
| `rewrite_surface` | `answer_too_popular:New York City` | 3 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No date or year information is present in the infobox to form a valid question.` | 3 |
| `route_generation` | `wikipedia_infobox_table_filter_rejected:infobox_remaining_rows_lt_min:remaining_non_header_rows=1;min=5` | 3 |
| `route_generation` | `wikipedia_infobox_table_filter_rejected:infobox_remaining_rows_lt_min:remaining_non_header_rows=3;min=5` | 3 |
| `route_generation` | `wikipedia_infobox_table_filter_rejected:infobox_remaining_rows_lt_min:remaining_non_header_rows=4;min=5` | 3 |
| `rewrite_surface` | `answer_too_popular:Germany` | 2 |
| `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_award_year_without_month` | 2 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No date or year is present in the infobox to form a valid question.` | 2 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No numeric value is present in the infobox to form a valid question.` | 2 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is provided in the infobox.` | 2 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No place name or geographic entity is present in the infobox to form a valid question.` | 2 |
| `route_generation` | `wikipedia_infobox_llm_discarded:The infobox does not contain any place or geographic entity information.` | 2 |
| `rewrite_surface` | `answer_too_popular:China` | 1 |
| `rewrite_surface` | `answer_too_popular:Europe` | 1 |
| `rewrite_surface` | `answer_too_popular:Japan` | 1 |
| `rewrite_surface` | `answer_too_popular:Paris` | 1 |
| `rewrite_surface` | `rewrite_guard_rejected:forbidden_temporal_phrase` | 1 |
| `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_answer_scope_ambiguous_phrase:meaning` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No date information is available in the infobox.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No date information is present in the infobox or table content to form a valid question.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No date or temporal information is present in the infobox to form a valid question and answer.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No date or temporal information is present in the infobox to form a valid question.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No date or year information is present in the infobox table to form a valid question and answer.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No date or year information is present in the infobox to form a valid single answer question.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No date or year information is present in the infobox.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No date or year information is present in the table to form a valid date question.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No date or year information is present or relevant in the infobox for the subject.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No date or year is present in the infobox table to form a valid question.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No date or year is present in the infobox to form a valid single-answer question.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No date or year value is present in the table to form a valid single-answer question.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No date value available in the infobox to form a valid question.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No date value is present in the infobox suitable for a fixed-date question.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No date value is present in the table to form a valid date question.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No date, year, or month information is present in the infobox to form a valid single-answer question.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No explicit numeric value is provided for lymph nodes count in the infobox.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No full calendar date or month and year information is available in the table.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No full calendar date or month and year is provided in the infobox.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No geographic place or location is present in the infobox to form a valid question.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No numeric strength value is provided in the table.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No numeric strength values are provided in the table.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No numeric value is present in the infobox table to form a valid question.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No numeric value is present in the infobox to form a valid single-answer question.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No numeric value is present in the table to form a valid single-answer question.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is present in the infobox data.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is present in the infobox table to form a valid question and answer.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is present in the infobox table to form a valid question.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is present in the infobox table to form a valid single-answer question.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is present in the infobox table to form a valid single-fact question.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is present in the infobox to form a valid question and answer.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is present in the infobox to form a valid single answer question.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is present in the infobox.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is present or relevant in the infobox for the subject.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is provided in the infobox to form a valid single-answer question.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is provided in the infobox; only entities and locations are listed.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is provided in the infobox; only organizations and event names are listed.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is provided in the infobox; only team names and locations are listed.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is provided in the table to form a valid single-answer question.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No place name or geographic entity is present in the infobox to form a valid single-answer question.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No place or geographic entity is present in the infobox to form a valid question.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No place or geographic entity is present in the infobox.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No place or geographic entity is present or relevant in the infobox for the subject.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No specific date, month, or year is provided in the infobox to form a valid question.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No specific date, year, or month is present in the infobox to form a valid question.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No specific date, year, or month is provided in the infobox to form a valid question.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No specific person names are provided in the table content.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No specific person names are provided in the table under commanders and leaders.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No specific person names are provided in the table.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:No specific place names or countries are provided in the table.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:The infobox does not contain any numeric values suitable for a number-type question.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:The infobox does not contain any place or geographic entity related to the Ashvins.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:The infobox does not contain any specific date, month, or year information suitable for a date-type question.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:The infobox does not provide a full calendar date or month and year for founding, only the year 1976.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:The infobox does not provide a numeric value for team members; only 'Singles or team relay' is given.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:The infobox does not provide any date or year information.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:The infobox does not provide any geographic place name or location on Earth relevant to AllMusic.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:The infobox does not provide any specific date, year, or month related to the Ashvins.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any person's name as a single indisputable answer.` | 1 |
| `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any place name or geographic entity on Earth as a single indisputable answer.` | 1 |
| `route_generation` | `wikipedia_infobox_table_filter_rejected:infobox_remaining_rows_lt_min:remaining_non_header_rows=2;min=5` | 1 |
| `route_generation` | `wikipedia_infobox_table_filter_rejected:infobox_removed_row_rate_gt_max:removed_row_rate=1.0000;max=0.6000;infobox_remaining_rows_lt_min:remaining_non_header_rows=0;min=5` | 1 |

### Answer Type Stats

| Scope | Answer type | Accepted | Rejected | Total | Accepted rate |
| --- | --- | ---: | ---: | ---: | ---: |
| Current Run Records | `Date` | 6 | 51 | 57 | 10.5% |
| Current Run Records | `Number` | 10 | 52 | 62 | 16.1% |
| Current Run Records | `Other` | 10 | 69 | 79 | 12.7% |
| Current Run Records | `Person` | 2 | 59 | 61 | 3.3% |
| Current Run Records | `Place` | 2 | 82 | 84 | 2.4% |
| Current Run Records | `unknown` | 0 | 209 | 209 | 0.0% |

### Reasoning Type Stats

| Scope | Reasoning type | Accepted | Rejected | Total | Accepted rate |
| --- | --- | ---: | ---: | ---: | ---: |
| Current Run Records | `single_fact` | 30 | 522 | 552 | 5.4% |

### Rerun Pool After Run

Rerun pool is empty.


### Phase Timings

Timing nesting: `wall_clock_seconds` is the whole run. `total_generation_seconds` contains page fetch/paragraph/table parse/LLM QA generation for one page. `total_processing_seconds` contains rewrite, number margin, DuckDuckGo search, second-stage grading when enabled, shared validation, and dedup checks for one generated candidate. `candidate_processing_seconds` is an alias of `total_processing_seconds`. Child phase totals are useful for bottlenecks, but they should not be added to parent totals.

| Pipeline order | Phase | Parent/child | Additive? | Meaning |
| ---: | --- | --- | --- | --- |
| 0 | `wall_clock_seconds` | run total | No | Elapsed time for the whole streaming command. |
| 1 | `page_fetch_seconds` | child of total_generation_seconds | Yes, within generation only | MediaWiki action=parse fetch for one page. |
| 2 | `first_paragraph_extract_seconds` | child of total_generation_seconds | Yes, within generation only | Local extraction of first paragraph from parse HTML. |
| 3 | `first_paragraph_fetch_seconds` | optional child of total_generation_seconds | Yes, within generation only | REST summary fallback when explicitly enabled and parse HTML lacks a paragraph. |
| 4 | `table_parse_seconds` | child of total_generation_seconds | Yes, within generation only | Local table/prose parsing and table ranking inputs. |
| 5 | `llm_question_generation_seconds` | child of total_generation_seconds | Yes, within generation only | Small-model Route 3 QA generation call. |
| 6 | `total_generation_seconds` | parent | No | Overall Route 3 generation time for one page. |
| 7 | `rewrite_seconds` | child of total_processing_seconds | Yes, within processing only | Shared rewrite call when enabled. |
| 8 | `number_reference_margin_seconds` | child of total_processing_seconds | Yes, within processing only | Numeric reference margin setup for Number answers. |
| 9 | `duckduckgo_search_seconds` | child of total_processing_seconds | Yes, within processing only | DuckDuckGo long-tail queries and leakage scoring. |
| 10 | `second_stage_grading_seconds` | optional child of total_processing_seconds | Yes, within processing only | Model-panel answerability grading when enabled. |
| 11 | `total_processing_seconds` | parent | No | Shared rewrite, filtering, grading, validation, and dedup processing for one candidate. |
| 12 | `candidate_processing_seconds` | alias | No | Alias of total_processing_seconds for compatibility. |

#### Current Run Phase Timings

| Phase | Count | Total seconds | Average seconds | Max seconds |
| --- | ---: | ---: | ---: | ---: |
| `candidate_processing_seconds` | 552 | 3875.8817 | 7.0215 | 80.2976 |
| `duckduckgo_search_seconds` | 228 | 3413.8820 | 14.9732 | 71.6266 |
| `first_paragraph_extract_seconds` | 465 | 16.0076 | 0.0344 | 0.1394 |
| `llm_question_generation_seconds` | 465 | 3011.6593 | 6.4767 | 14.0022 |
| `number_reference_margin_seconds` | 247 | 0.0000 | 0.0000 | 0.0000 |
| `page_fetch_seconds` | 552 | 0.0000 | 0.0000 | 0.0000 |
| `pageview_prefilter_seconds` | 552 | 0.0007 | 0.0000 | 0.0001 |
| `rewrite_seconds` | 343 | 0.0000 | 0.0000 | 0.0000 |
| `second_stage_grading_seconds` | 96 | 461.2921 | 4.8051 | 12.8264 |
| `table_parse_seconds` | 552 | 48.2040 | 0.0873 | 0.5315 |
| `total_generation_seconds` | 552 | 3197.0212 | 5.7917 | 14.0387 |
| `total_processing_seconds` | 552 | 3875.8817 | 7.0215 | 80.2976 |

## Accepted Candidates

| Page ID | Question | Answer | Source |
| ---: | --- | --- | --- |
| 76165 | Which person was a key figure associated with Pontiac automobile brand? | Frank Hershey | https://en.wikipedia.org/wiki/Pontiac_(automobile) |
| 1674887 | What is the company type of EBSCO Information Services? | Subsidiary of EBSCO Industries | https://en.wikipedia.org/wiki/EBSCO_Information_Services |
| 498538 | How many academic staff did the University of New Hampshire have in 2019? | 997 | https://en.wikipedia.org/wiki/University_of_New_Hampshire |
| 24218875 | What month, day, and year was Deadline Hollywood launched? | September 4, 2009 | https://en.wikipedia.org/wiki/Deadline_Hollywood |
| 628232 | What is the full birth date of Park Ji-sung including month, day, and year? | March 30, 1981 | https://en.wikipedia.org/wiki/Park_Ji-sung |
| 4836072 | What is the running time in minutes of the 1964 film My Fair Lady? | 173 | https://en.wikipedia.org/wiki/My_Fair_Lady_(film) |
| 135276 | In what year was the city of Jackson, Tennessee incorporated? | 1845 | https://en.wikipedia.org/wiki/Jackson,_Tennessee |
| 188497 | What is the name of the bone's superior articulation place in the pelvis? | acetabulum of pelvis | https://en.wikipedia.org/wiki/Femur |
| 288514 | What is the grouping classification of a pixie in British folklore? | Legendary creature Fairy Sprite | https://en.wikipedia.org/wiki/Pixie |
| 240432 | What is the type of government for the provinces of Argentina? | Provincial government | https://en.wikipedia.org/wiki/Provinces_of_Argentina |
| 226734 | What country are the federated states located in? | Federal Republic of Nigeria | https://en.wikipedia.org/wiki/States_of_Nigeria |
| 295691 | How many academic chairs did the Collège de France have in 2016? | 47 | https://en.wikipedia.org/wiki/Collège_de_France |
| 186191 | In what year did the T-72 tank enter service? | 1969 | https://en.wikipedia.org/wiki/T-72 |
| 697535 | What is the type of site that AllMusic is classified as? | Online database for music albums, artists and songs; reviews and biographies | https://en.wikipedia.org/wiki/AllMusic |
| 604350 | What month, day, and year was the ARD broadcaster launched? | June 5, 1950 | https://en.wikipedia.org/wiki/ARD_(broadcaster) |
| 910914 | What organization presents the Young Artist Award? | Young Artist Foundation | https://en.wikipedia.org/wiki/Young_Artist_Award |
| 1003268 | What is the ISO 639-6 code for the stage of the English language from the beginning of the Tudor period to the English Interregnum and Restoration? | emen | https://en.wikipedia.org/wiki/Early_Modern_English |
| 64384 | How old was Pieter Bruegel the Elder when he died? | 39 | https://en.wikipedia.org/wiki/Pieter_Bruegel_the_Elder |
| 31388 | What was the condition status of the Treaty of Brest-Litovsk? | Ratification | https://en.wikipedia.org/wiki/Treaty_of_Brest-Litovsk |
| 129295 | What is the name of the production company behind the film Fatal Attraction? | Jaffe/Lansing Productions | https://en.wikipedia.org/wiki/Fatal_Attraction |
| 40158 | What is the official website URL of the municipality of Berchtesgaden? | www.gemeinde.berchtesgaden.de | https://en.wikipedia.org/wiki/Berchtesgaden |
| 105908 | How many doors does the Ford Mustang's body style include? | 3 | https://en.wikipedia.org/wiki/Ford_Mustang |
| 109566 | On what month, day, and year was Winter Park incorporated as a town? | October 21, 1887 | https://en.wikipedia.org/wiki/Winter_Park,_Florida |
| 615800 | How many total senior club appearances did Cafu make? | 557 | https://en.wikipedia.org/wiki/Cafu |
| 82050 | What is the role of the Royal Norwegian Navy? | Naval warfare | https://en.wikipedia.org/wiki/Royal_Norwegian_Navy |
| 199445 | How many senior club appearances did Wayne Rooney make in total? | 569 | https://en.wikipedia.org/wiki/Wayne_Rooney |
| 228600 | Who is the president of Washington State University? | Elizabeth R. Cantwell | https://en.wikipedia.org/wiki/Washington_State_University |
| 8083 | How many children does Dr. Dre have? | 8 | https://en.wikipedia.org/wiki/Dr._Dre |
| 540034 | At what age range does amyloidosis usually onset in years? | 55 | https://en.wikipedia.org/wiki/Amyloidosis |
| 422038 | What is the motto of the city of Vigo? | "Fiel, Leal, Valerosa e Sempre Benéfica Cidade de Vigo" | https://en.wikipedia.org/wiki/Vigo |

## Second-Stage Filtering Responses

These are the small-model QA responses used by the second-stage filter: `openai/gpt-4.1-mini` and `google/gemini-3-flash-preview`.

| Page ID | Question | Reference answer | openai/gpt-4.1-mini | google/gemini-3-flash-preview |
| ---: | --- | --- | --- | --- |
| 76165 | Which person was a key figure associated with Pontiac automobile brand? | Frank Hershey | INCORRECT; predicted_answer: Edsel Ford was a key figure associated with the Pontiac automobile brand, as Pontiac was a division of General Motors, where Edsel Ford played a significant role in the automotive industry. | INCORRECT; predicted_answer: **Edward Murphy** founded the Oakland Motor Car Company (which became Pontiac), but **Bunkie Knudsen**, **Pete Estes**, and **John DeLorean** are the key figures credited with transforming Pontiac into a high-performance brand in the 1950s and 60s. |
| 1674887 | What is the company type of EBSCO Information Services? | Subsidiary of EBSCO Industries | INCORRECT; predicted_answer: EBSCO Information Services is a private company. | INCORRECT; predicted_answer: EBSCO Information Services is a **private company**. It is a division of EBSCO Industries, Inc., which is one of the largest privately held, family-owned companies in the United States. |
| 498538 | How many academic staff did the University of New Hampshire have in 2019? | 997 (acceptable range: anything between 987 and 1007) | INCORRECT; predicted_answer: The University of New Hampshire had 1,119 academic staff in 2019. | INCORRECT; predicted_answer: In 2019, the University of New Hampshire had approximately **1,130** academic staff members. |
| 24218875 | What month, day, and year was Deadline Hollywood launched? | September 4, 2009 | INCORRECT; predicted_answer: Deadline Hollywood was launched on February 1, 2006. | INCORRECT; predicted_answer: Deadline Hollywood was launched on **March 7, 2006**. |
| 628232 | What is the full birth date of Park Ji-sung including month, day, and year? | March 30, 1981 | INCORRECT; predicted_answer: Park Ji-sung was born on February 25, 1981. | INCORRECT; predicted_answer: Park Ji-sung was born on **February 25, 1981**. |
| 4836072 | What is the running time in minutes of the 1964 film My Fair Lady? | 173 (acceptable range: anything between 171 and 175) | INCORRECT; predicted_answer: The running time of the 1964 film *My Fair Lady* is approximately 170 minutes. | INCORRECT; predicted_answer: The running time of the 1964 film *My Fair Lady* is **170 minutes**. |
| 135276 | In what year was the city of Jackson, Tennessee incorporated? | 1845 | INCORRECT; predicted_answer: The city of Jackson, Tennessee was incorporated in the year 1849. | INCORRECT; predicted_answer: Jackson, Tennessee, was incorporated in **1822**. |
| 188497 | What is the name of the bone's superior articulation place in the pelvis? | acetabulum of pelvis | INCORRECT; predicted_answer: The superior articulation place of the pelvis bone is called the **iliac crest**. | INCORRECT; predicted_answer: The superior articulation place of the pelvis (specifically the sacrum) is the **lumbosacral joint**, where the base of the sacrum meets the **fifth lumbar vertebra (L5)**. |
| 288514 | What is the grouping classification of a pixie in British folklore? | Legendary creature Fairy Sprite | INCORRECT; predicted_answer: In British folklore, a pixie is classified as a type of **fairy** or **fae** creature. | INCORRECT; predicted_answer: In British folklore, pixies are classified as **fae** (or **fairies**). Specifically, in the traditions of Devon and Cornwall, they are categorized as **solitary fairies**, distinguishing them from "trooping fairies" who live in large organized societies. |
| 240432 | What is the type of government for the provinces of Argentina? | Provincial government | INCORRECT; predicted_answer: The provinces of Argentina have a federal system of government, each governed by its own provincial government with executive, legislative, and judicial branches. They have a degree of autonomy under the national constitution. | INCORRECT; predicted_answer: The provinces of Argentina have a **representative, republican, and federal** form of government. Each province has its own constitution and operates with three branches: executive (headed by a Governor), legislative (unicameral or bicameral), and judicial. |
| 226734 | What country are the federated states located in? | Federal Republic of Nigeria | INCORRECT; predicted_answer: The Federated States of Micronesia is an independent country located in the western Pacific Ocean. | INCORRECT; predicted_answer: The Federated States of Micronesia is an **independent country** located in the Oceania region of the western Pacific Ocean. |
| 295691 | How many academic chairs did the Collège de France have in 2016? | 47 (acceptable range: anything between 46 and 48) | INCORRECT; predicted_answer: In 2016, the Collège de France had 52 academic chairs. | INCORRECT; predicted_answer: In 2016, the Collège de France had **52** permanent academic chairs. |
| 186191 | In what year did the T-72 tank enter service? | 1969 | INCORRECT; predicted_answer: The T-72 tank entered service in 1973. | INCORRECT; predicted_answer: The T-72 tank entered service with the Soviet Army in **1973**. |
| 697535 | What is the type of site that AllMusic is classified as? | Online database for music albums, artists and songs; reviews and biographies | INCORRECT; predicted_answer: AllMusic is classified as a music database and music review website. | INCORRECT; predicted_answer: AllMusic is classified as an **online music database**. |
| 604350 | What month, day, and year was the ARD broadcaster launched? | June 5, 1950 | INCORRECT; predicted_answer: The ARD broadcaster was launched on June 9, 1950. | INCORRECT; predicted_answer: ARD was founded on **June 9, 1950**. |
| 910914 | What organization presents the Young Artist Award? | Young Artist Foundation | INCORRECT; predicted_answer: The Young Artist Award is presented by the Young Artist Association. | INCORRECT; predicted_answer: The Young Artist Award is presented by the **Young Artist Academy** (formerly known as the Young Artist Association). |
| 1003268 | What is the ISO 639-6 code for the stage of the English language from the beginning of the Tudor period to the English Interregnum and Restoration? | emen | INCORRECT; predicted_answer: The ISO 639-6 code for Early Modern English, the stage of the English language from the beginning of the Tudor period to the English Interregnum and Restoration, is **engm**. | INCORRECT; predicted_answer: The ISO 639-6 code for Early Modern English is **emng**. |
| 64384 | How old was Pieter Bruegel the Elder when he died? | 39 (acceptable range: anything between 38 and 40) | INCORRECT; predicted_answer: Pieter Bruegel the Elder was about 44 years old when he died in 1569 (born around 1525). | INCORRECT; predicted_answer: Pieter Bruegel the Elder was approximately **44 years old** when he died. While his exact birth date is unknown (estimated between 1525 and 1530), he passed away on September 9, 1569. |
| 31388 | What was the condition status of the Treaty of Brest-Litovsk? | Ratification | INCORRECT; predicted_answer: The Treaty of Brest-Litovsk was a peace treaty signed on March 3, 1918, between Soviet Russia and the Central Powers (Germany, Austria-Hungary, Bulgaria, and the Ottoman Empire). Its condition status was that it marked Russia's exit from World War I, resulting in significant territorial losses for Russia. The treaty was effectively nullified later that year when Germany and the Central Powers were defeated in November 1918, and the Treaty of Versailles superseded it. | INCORRECT; predicted_answer: The Treaty of Brest-Litovsk is **null and void**.  Signed on March 3, 1918, between the Central Powers and Soviet Russia, it was formally **annulled** by the Armistice of November 11, 1918, following Germany's defeat in World War I. This status was further solidified by the 1919 Treaty of Versailles, which forced Germany to renounce all territorial gains made under the agreement. |
| 129295 | What is the name of the production company behind the film Fatal Attraction? | Jaffe/Lansing Productions | INCORRECT; predicted_answer: The production company behind the film *Fatal Attraction* is Paramount Pictures. | INCORRECT; predicted_answer: The production company behind the film *Fatal Attraction* is **Paramount Pictures**, in association with **Jaffe/Lansing Productions**. |
| 40158 | What is the official website URL of the municipality of Berchtesgaden? | www.gemeinde.berchtesgaden.de | INCORRECT; predicted_answer: The official website URL of the municipality of Berchtesgaden is https://www.berchtesgaden.de/ | INCORRECT; predicted_answer: The official website URL of the municipality of Berchtesgaden is **https://www.berchtesgaden.de**. |
| 105908 | How many doors does the Ford Mustang's body style include? | 3 (acceptable range: anything between 2 and 4) | INCORRECT; predicted_answer: The Ford Mustang's body style typically includes 2 doors. | INCORRECT; predicted_answer: The Ford Mustang body style includes **two doors**. |
| 109566 | On what month, day, and year was Winter Park incorporated as a town? | October 21, 1887 | INCORRECT; predicted_answer: Winter Park was incorporated as a town on October 12, 1887. | INCORRECT; predicted_answer: Winter Park was incorporated as a town on **October 12, 1887**. |
| 615800 | How many total senior club appearances did Cafu make? | 557 (acceptable range: anything between 551 and 563) | INCORRECT; predicted_answer: Cafu made a total of 581 senior club appearances in his career. | INCORRECT; predicted_answer: Cafu made a total of **431** senior club appearances throughout his career. |
| 82050 | What is the role of the Royal Norwegian Navy? | Naval warfare | INCORRECT; predicted_answer: The role of the Royal Norwegian Navy is to protect Norway's maritime interests, ensure the security of its coastal waters, conduct naval defense operations, support international peacekeeping missions, and contribute to NATO's collective defense. | INCORRECT; predicted_answer: The primary role of the Royal Norwegian Navy is to defend Norway’s sovereignty and protect its national interests at sea. Its core responsibilities include:  *   **Territorial Defense:** Monitoring and patrolling Norway’s extensive coastline and vast maritime areas (which are seven times larger than its land area). *   **Resource Management:** Protecting economic interests, including offshore oil and gas installations and fishing grounds. *   **Coast Guard Operations:** Conducting search and rescue, fishery inspections, environmental monitoring, and law enforcement. *   **NATO Integration:** Contributing to collective allied security through international operations, exercises, and permanent |
| 199445 | How many senior club appearances did Wayne Rooney make in total? | 569 (acceptable range: anything between 563 and 575) | INCORRECT; predicted_answer: Wayne Rooney made a total of 559 senior club appearances. | INCORRECT; predicted_answer: Wayne Rooney made a total of **764** senior club appearances. |
| 228600 | Who is the president of Washington State University? | Elizabeth R. Cantwell | INCORRECT; predicted_answer: The president of Washington State University is Kirk Schulz. | INCORRECT; predicted_answer: The president of Washington State University is **Kirk Schulz**. |
| 8083 | How many children does Dr. Dre have? | 8 (acceptable range: anything between 7 and 9) | INCORRECT; predicted_answer: Dr. Dre has six children. | INCORRECT; predicted_answer: Dr. Dre has **nine** children (six sons and three daughters) with several different partners. |
| 540034 | At what age range does amyloidosis usually onset in years? | 55 (acceptable range: anything between 54 and 56) | INCORRECT; predicted_answer: Amyloidosis usually onset occurs most commonly between the ages of 50 and 70 years. | INCORRECT; predicted_answer: Amyloidosis usually onsets between the ages of **50 and 70**, though it is most commonly diagnosed in individuals in their **60s**. While rare, some hereditary forms can appear as early as the 30s or 40s. |
| 422038 | What is the motto of the city of Vigo? | "Fiel, Leal, Valerosa e Sempre Benéfica Cidade de Vigo" | INCORRECT; predicted_answer: The motto of the city of Vigo is "Praestantia, Ingenium, Hospitalitas." | INCORRECT; predicted_answer: The motto of the city of Vigo is **"Fiel, Leal, Valerosa y Siempre Benemérita Ciudad de Vigo"** (Faithful, Loyal, Valiant and Always Meritorious City of Vigo). |
| 9119 | Distinguished Service Medal (U.S. Army) |  | not run | not run |
| 257453 | Butte, Montana |  | not run | not run |
| 255999 | Stairway to Heaven |  | not run | not run |
| 206997 | Alsace–Lorraine |  | not run | not run |
| 963152 | Spaniards |  | not run | not run |
| 173652 | Hemorrhoid |  | not run | not run |
| 37284 | Which virus is listed as a risk factor for brain tumors? | Epstein–Barr virus | not run | not run |
| 37284 | In which part of the brain can brain metastasis from lung cancer be found as shown in the imaging? | right cerebral hemisphere | not run | not run |
| 37284 | What is the average five-year survival rate percentage for brain tumors in the US? | 33 | not run | not run |
| 37284 | Brain tumor |  | not run | not run |
| 37284 | What is one of the diagnostic methods used to detect brain tumors? | Computed tomography | CORRECT; predicted_answer: One common diagnostic method used to detect brain tumors is magnetic resonance imaging (MRI). | not run |
| 9316 | England |  | not run | not run |
| 10477 | Who is the father of the goddess and personification of the dawn in ancient Greek mythology? | Hyperion | not run | not run |
| 10477 | What is the abode of the goddess and personification of the dawn in ancient Greek mythology? | Sky | not run | not run |
| 10477 | How many siblings does the goddess and personification of the dawn have according to ancient Greek mythology? | 2 | not run | not run |
| 10477 | Eos |  | not run | not run |
| 10477 | What is one of the symbols associated with the goddess and personification of the dawn in ancient Greek mythology? | Saffron | CORRECT; predicted_answer: One of the symbols associated with Eos, the goddess and personification of the dawn in ancient Greek mythology, is the rose. | not run |
| 180174 | Niagara Falls, Ontario |  | not run | not run |
| 231031 | Who is the Chancellor of the University of Western Australia? | Diane Smith-Gander | not run | not run |
| 231031 | In which city is the University of Western Australia located? | Crawley | not run | not run |
| 231031 | How many years ago was the University of Western Australia established? | 115 | not run | not run |
| 231031 | What month, day, and year was the University of Western Australia established? | February 16, 1911 | INCORRECT; predicted_answer: The University of Western Australia was established on March 10, 1911. | CORRECT; predicted_answer: The University of Western Australia was established on **February 16, 1911**. |
| 231031 | What is the motto of the University of Western Australia? | Seek Wisdom | not run | not run |
| 70298 | Midwest League |  | not run | not run |
| 70298 | In which country is the Midwest League based? | United States | not run | not run |
| 70298 | How many teams are in the Midwest League? | 12 | not run | not run |
| 70298 | In what year was the Midwest League founded? | 1947 | not run | not run |
| 70298 | What is the current classification level of the Midwest League as of 2021? | High-A | not run | not run |
| 372315 | Moscow Oblast |  | not run | not run |
| 1674887 | EBSCO Information Services |  | not run | not run |
| 1674887 | What city is the headquarters of EBSCO Information Services located in? | Ipswich | not run | not run |
| 1674887 | In what year was EBSCO Information Services founded? | 1984 | not run | not run |
| 1674887 | EBSCO Information Services |  | not run | not run |
| 29125601 | Flemish people |  | not run | not run |
| 498538 | Who is the president of the University of New Hampshire? | Elizabeth S. Chilton | not run | not run |
| 498538 | What city is the main campus of the University of New Hampshire located in? | Durham | not run | not run |
| 49188979 | Normandy (administrative region) |  | not run | not run |
| 32611 | Vietnam War |  | not run | not run |
| 219424 | Sergeant |  | not run | not run |
| 24218875 | Who is the founder of Deadline Hollywood? | Nikki Finke | not run | not run |
| 24218875 | In which country is the headquarters of Deadline Hollywood located? | United States | not run | not run |
| 24218875 | How many editors are listed for Deadline Hollywood? | 4 | not run | not run |
| 453433 | Scallion |  | not run | not run |
| 309294 | Albany, Western Australia |  | not run | not run |
| 82075 | Santa Cruz County, California |  | not run | not run |
| 972904 | Who is the editor-in-chief of Vibe magazine? | Datwon Thomas | CORRECT; predicted_answer: The editor-in-chief of Vibe magazine is Datwon Thomas. | not run |
| 972904 | In which city is Vibe magazine based? | New York City | not run | not run |
| 972904 | In what year was Vibe magazine founded? | 1993 | not run | not run |
| 972904 | What month and year was Vibe magazine founded? | September 1993 | INCORRECT; predicted_answer: Vibe magazine was founded in June 1993. | CORRECT; predicted_answer: Vibe magazine was founded in **September 1993**. |
| 972904 | What is the primary language of Vibe magazine? | English | not run | not run |
| 628232 | Who is the full name of the South Korean footballer born on March 30, 1981? | Park Ji-sung | not run | not run |
| 628232 | What city is the birthplace of Park Ji-sung? | Seoul | not run | not run |
| 628232 | How many total club domestic league appearances did Park Ji-sung make in his senior career? | 318 (acceptable range: anything between 315 and 321) | INCORRECT; predicted_answer: Park Ji-sung made a total of 273 club domestic league appearances in his senior career. | CORRECT; predicted_answer: Park Ji-sung made a total of **318** club domestic league appearances during his senior career. |
| 50762105 | Emphysema |  | not run | not run |
| 50762105 | Emphysema |  | not run | not run |
| 50762105 | At what minimum age in years does emphysema usually onset? | 40 | not run | not run |
| 50762105 | Emphysema |  | not run | not run |
| 50762105 | What is the primary medical specialty that deals with emphysema? | Pulmonology | CORRECT; predicted_answer: The primary medical specialty that deals with emphysema is Pulmonology. | not run |
| 8196151 | List of states of Mexico |  | not run | not run |
| 4836072 | Who directed the 1964 film My Fair Lady? | George Cukor | not run | not run |
| 4836072 | What country produced the 1964 film My Fair Lady? | United States | not run | not run |
| 21355232 | List of national parks of the United States |  | not run | not run |
| 8318491 | Southeastern Anatolia region |  | not run | not run |
| 306966 | Kataeb Party |  | not run | not run |
| 35972636 | ORMO |  | not run | not run |
| 200152 | Who was the governor of Mombasa County according to the infobox? | Abdulsamad Shariff Nassir | not run | not run |
| 200152 | What county is Mombasa city located in according to the infobox? | Mombasa County | not run | not run |
| 200152 | What is the area code number for Mombasa city as given in the infobox? | 20 | not run | not run |
| 200152 | In what year was Mombasa founded according to the infobox? | 900 | not run | not run |
| 200152 | What is the climate classification of Mombasa city as listed in the infobox? | Aw | not run | not run |
| 588981 | Provinces of Bulgaria |  | not run | not run |
| 22948 | Who is the consort of the protector of seafarers and the guardian of many Hellenic cities and colonies? | Amphitrite | not run | not run |
| 22948 | What is the abode of the god of the sea, storms, earthquakes, and horses? | Mount Olympus; the sea | not run | not run |
| 22948 | How many siblings does the protector of seafarers and the guardian of many Hellenic cities and colonies have? | 5 | not run | not run |
| 22948 | Poseidon |  | not run | not run |
| 22948 | What is one of the symbols associated with the god of the sea, storms, earthquakes, and horses? | Trident | not run | not run |
| 4248 | Bowls |  | not run | not run |
| 3968 | Bodhisattva |  | not run | not run |
| 3968 | Bodhisattva |  | not run | not run |
| 3968 | Bodhisattva |  | not run | not run |
| 3968 | Bodhisattva |  | not run | not run |
| 3968 | What is the Pāli term for bodhisattva as given in the infobox? | बोधिसत्त | not run | not run |
| 524482 | Who is the brother of Tony Sirico? | Robert Sirico | not run | not run |
| 524482 | In which city was Tony Sirico born? | New York City | not run | not run |
| 524482 | How many children did Tony Sirico have? | 2 | not run | not run |
| 524482 | What month, day, and year did Tony Sirico die? | July 8, 2022 | not run | not run |
| 524482 | What was Tony Sirico's occupation? | Actor | not run | not run |
| 36624 | Embryo |  | not run | not run |
| 62633 | Les Invalides |  | not run | not run |
| 368989 | Formosan languages |  | not run | not run |
| 55440889 | Pixel 2 |  | not run | not run |
| 24516 | Who is the ancient Greek historian known for documenting the rise of Rome in the Mediterranean during the third and second centuries BC? | Polybius | not run | not run |
| 24516 | What city was Polybius born in? | Megalopolis | not run | not run |
| 24516 | What year was Polybius born, approximately? | 200 | not run | not run |
| 24516 | What year did Polybius approximately die? | 118 | not run | not run |
| 24516 | What is the notable philosophical idea attributed to Polybius? | Anacyclosis | CORRECT; predicted_answer: The notable philosophical idea attributed to Polybius is the theory of **anacyclosis**, which describes the cyclical nature of political evolution—how governments naturally progress through a cycle of monarchy, tyranny, aristocracy, oligarchy, democracy, and ochlocracy (mob rule), before returning to monarchy. | not run |
| 205058 | Heisei era |  | not run | not run |
| 10522749 | International Music Score Library Project |  | not run | not run |
| 31740 | Who is the president of the oldest institution of higher education in the state of Michigan? | Domenico Grasso | not run | not run |
| 31740 | In which city is the oldest institution of higher education in the state of Michigan located? | Ann Arbor | not run | not run |
| 31740 | In what year was the oldest institution of higher education in the state of Michigan established? | 1817 | not run | not run |
| 31740 | What month, day, and year was the oldest institution of higher education in the state of Michigan established? | August 26, 1817 | CORRECT; predicted_answer: The oldest institution of higher education in Michigan, the University of Michigan, was established on August 26, 1817. | not run |
| 31740 | What is the motto in English of the oldest institution of higher education in the state of Michigan? | Arts, Knowledge, Truth | CORRECT; predicted_answer: The motto in English of the University of Michigan, the oldest institution of higher education in Michigan, is "Arts, Knowledge, Truth." | not run |
| 2186423 | Hallelujah (Leonard Cohen song) |  | not run | not run |
| 13169 | Gneiss |  | not run | not run |
| 20608 | Messier object |  | not run | not run |
| 135276 | Who is the person after whom the city of Jackson, Tennessee was named? | Andrew Jackson | not run | not run |
| 135276 | In which county is the city of Jackson, Tennessee located? | Madison | not run | not run |
| 135276 | What was the population of Jackson, Tennessee according to the 2020 United States census? | 68205 | not run | not run |
| 68481047 | Fall of Kabul (2021) |  | not run | not run |
| 68481047 | What city was the location of the Fall of Kabul in 2021? | Kabul | not run | not run |
| 68481047 | How many wars are referenced in the context of the Fall of Kabul (2021)? | 2 | not run | not run |
| 68481047 | What year did the Fall of Kabul occur? | 2021 | CORRECT; predicted_answer: The Fall of Kabul occurred in 2021. | not run |
| 68481047 | What was the name of the offensive that included the Fall of Kabul in 2021? | 2021 Taliban offensive | not run | not run |
| 188497 | Femur |  | not run | not run |
| 5816 | Cenozoic |  | not run | not run |
| 5816 | What celestial body is associated with the Cenozoic Era? | Earth | not run | not run |
| 5816 | What is the time span in million years of the Cenozoic Era? | 66 | not run | not run |
| 5816 | In what year was the lower GSSP of the Cenozoic Era ratified? | 1991 | INCORRECT; predicted_answer: The lower GSSP of the Cenozoic Era was ratified in 2018. | CORRECT; predicted_answer: The lower GSSP of the Cenozoic Era (marking the Cretaceous–Paleogene boundary) was ratified in **1991**. |
| 5816 | What is the formal chronological unit classification of the Cenozoic? | Era | not run | not run |
| 45367389 | Greater London |  | not run | not run |
| 157774 | Permafrost |  | not run | not run |
| 413714 | Padma Bhushan |  | not run | not run |
| 413714 | Padma Bhushan |  | not run | not run |
| 413714 | How many years ago was the Padma Bhushan award established? | 72 | not run | not run |
| 413714 | What year was the Padma Bhushan award first given? | 1954 | not run | not run |
| 413714 | What is the text written above the lotus flower on the obverse side of the Padma Bhushan medal? | Padma | not run | not run |
| 269408 | Who was the first governor-general of Colonial Brazil? | Tomé de Sousa | not run | not run |
| 269408 | What city was the capital of Colonial Brazil from 1763 to 1815? | Rio de Janeiro | not run | not run |
| 269408 | What was the duration in years of the Colonial Brazil period? | 315 | not run | not run |
| 269408 | On what month, day, and year did the Portuguese arrive in Brazil? | April 22, 1500 | CORRECT; predicted_answer: The Portuguese arrived in Brazil on April 22, 1500. | not run |
| 269408 | What was the official religion of Colonial Brazil? | Catholic | not run | not run |
| 741851 | Who founded Rough Trade Records? | Geoff Travis | not run | not run |
| 741851 | In which city is Rough Trade Records located? | London | not run | not run |
| 741851 | In what year was Rough Trade Records founded? | 1976 | not run | not run |
| 741851 | Rough Trade Records |  | not run | not run |
| 741851 | What is the parent company of Rough Trade Records? | Beggars Group | CORRECT; predicted_answer: The parent company of Rough Trade Records is Beggars Group. | not run |
| 2500 | Anus |  | not run | not run |
| 2500 | What anatomical system does the anus belong to? | Alimentary | not run | not run |
| 2500 | Anus |  | not run | not run |
| 2500 | Anus |  | not run | not run |
| 2500 | What is the Latin term for the external body orifice at the exit end of the digestive tract? | anus | not run | not run |
| 6920895 | Who is the darts commentator honored by the trophy awarded to the winner of the most prestigious tournament organized by the Professional Darts Corporation? | Sid Waddell | not run | not run |
| 6920895 | What city hosts the PDC World Darts Championship at Alexandra Palace since 2008? | London | not run | not run |
| 6920895 | In what year was the PDC World Darts Championship founded? | 1994 | not run | not run |
| 6920895 | In what year did the PDC World Darts Championship first hold its season? | 1994 | CORRECT; predicted_answer: The PDC World Darts Championship first held its season in 1994. | not run |
| 6920895 | What is the tournament format used in the PDC World Darts Championship? | Sets | not run | not run |
| 288514 | Pixie |  | not run | not run |
| 288514 | In which region of the United Kingdom are pixies particularly concentrated according to British folklore? | Cornwall and Devon | not run | not run |
| 288514 | Pixie |  | not run | not run |
| 288514 | Pixie |  | not run | not run |
| 500004 | Who created the On-Line Encyclopedia of Integer Sequences? | Neil Sloane | not run | not run |
| 500004 | On-Line Encyclopedia of Integer Sequences |  | not run | not run |
| 500004 | How many years ago was the On-Line Encyclopedia of Integer Sequences founded? | 62 | not run | not run |
| 500004 | What year was the On-Line Encyclopedia of Integer Sequences launched? | 1996 | INCORRECT; predicted_answer: The On-Line Encyclopedia of Integer Sequences (OEIS) was launched in 1964. | CORRECT; predicted_answer: The On-Line Encyclopedia of Integer Sequences (OEIS) was launched in **1996**. |
| 500004 | Is the On-Line Encyclopedia of Integer Sequences a commercial website? | No | CORRECT; predicted_answer: No, the On-Line Encyclopedia of Integer Sequences (OEIS) is not a commercial website. It is a freely accessible database maintained by a nonprofit organization. | not run |
| 62149 | Custard |  | not run | not run |
| 29781 | Who directed the 1974 film The Texas Chain Saw Massacre? | Tobe Hooper | not run | not run |
| 29781 | What country produced the 1974 film The Texas Chain Saw Massacre? | United States | not run | not run |
| 29781 | What is the running time in minutes of the 1974 film The Texas Chain Saw Massacre? | 83 (acceptable range: anything between 82 and 84) | CORRECT; predicted_answer: The running time of the 1974 film The Texas Chain Saw Massacre is approximately 83 minutes. | not run |
| 29781 | What month, day, and year was The Texas Chain Saw Massacre released? | October 11, 1974 | INCORRECT; predicted_answer: The Texas Chain Saw Massacre was released on October 1, 1974. | CORRECT; predicted_answer: *The Texas Chain Saw Massacre* was released on **October 11, 1974**. |
| 29781 | What is the language of the 1974 film The Texas Chain Saw Massacre? | English | not run | not run |
| 240432 | Provinces of Argentina |  | not run | not run |
| 240432 | What country are the provinces of Argentina located in? | Argentina | not run | not run |
| 240432 | How many provinces are there in Argentina? | 23 | not run | not run |
| 240432 | Provinces of Argentina |  | not run | not run |
| 457055 | Comune |  | not run | not run |
| 226734 | States of Nigeria |  | not run | not run |
| 30450289 | Regional units of Greece |  | not run | not run |
| 295691 | Who was the founder of the Collège de France? | Francis I of France | CORRECT; predicted_answer: The Collège de France was founded by King Francis I of France. | not run |
| 295691 | In which city is the Collège de France located? | Paris | not run | not run |
| 2856052 | Haenyeo |  | not run | not run |
| 2856052 | In which South Korean province do the haenyeo female divers primarily live and work? | Jeju | not run | not run |
| 2856052 | Haenyeo |  | not run | not run |
| 2856052 | Haenyeo |  | not run | not run |
| 2856052 | What is the Hangul script representation of the Korean term for female divers known as haenyeo? | 해녀 | CORRECT; predicted_answer: The Hangul script representation of "haenyeo" is 해녀. | not run |
| 380167 | Achilles tendon |  | not run | not run |
| 380167 | What is the anatomical location of the Achilles tendon in the human body? | Back of the lower leg | not run | not run |
| 380167 | How many muscles attach to the Achilles tendon according to the infobox? | 3 | not run | not run |
| 380167 | Achilles tendon |  | not run | not run |
| 380167 | What is the Latin anatomical term for the Achilles tendon? | tendo calcaneus; tendo Achillis | not run | not run |
| 618770 | Who is the actress born on March 28, 1948, in Kansas City, Missouri? | Dianne Evelyn Wiest | not run | not run |
| 618770 | What city is the birthplace of Dianne Wiest? | Kansas City | not run | not run |
| 618770 | How many children does Dianne Wiest have? | 2 | not run | not run |
| 618770 | What is the full birth date of Dianne Wiest including month, day, and year? | March 28, 1948 | not run | not run |
| 618770 | What university did Dianne Wiest attend? | University of Maryland | not run | not run |
| 83934 | Norwegian resistance movement |  | not run | not run |
| 235916 | Who is the spouse of Jada Pinkett Smith listed in the infobox? | Will Smith | not run | not run |
| 235916 | In which city was Jada Pinkett Smith born according to the infobox? | Baltimore | not run | not run |
| 235916 | How many children does Jada Pinkett Smith have as listed in the infobox? | 1 | not run | not run |
| 235916 | What month, day, and year was Jada Pinkett Smith born according to the infobox? | September 18, 1971 | not run | not run |
| 235916 | What is the name of the production company associated with Jada Pinkett Smith in the infobox? | 100% Womon Productions | not run | not run |
| 55417368 | 2016 Australian census |  | not run | not run |
| 637543 | Grand Duchy of Finland |  | not run | not run |
| 15355864 | 2015 Pan American Games |  | not run | not run |
| 287299 | What is an alternative eponymous name for sarcoidosis derived from the names of three physicians? | Besnier–Boeck–Schaumann disease | INCORRECT; predicted_answer: An alternative eponymous name for sarcoidosis is **Boeck's disease**, named after the Norwegian dermatologist Cæsar Boeck. However, when derived from the names of three physicians, it is called **Boeck-Schaumann disease**, combining Boeck, Jörgen Nilsen Schaumann, and another contributor. | CORRECT; predicted_answer: An alternative eponymous name for sarcoidosis is **Besnier-Boeck-Schaumann disease**. |
| 287299 | What organ is most commonly affected by sarcoidosis as indicated in the infobox? | lungs | not run | not run |
| 287299 | What is the typical age range in years for the usual onset of sarcoidosis? | 20 | not run | not run |
| 287299 | Sarcoidosis |  | not run | not run |
| 287299 | What is one of the primary treatments listed for sarcoidosis in the infobox? | prednisone | not run | not run |
| 87627 | Amur Oblast |  | not run | not run |
| 89514 | New London, Connecticut |  | not run | not run |
| 1290366 | Amir Khan (boxer) |  | not run | not run |
| 306853 | Who developed the Jyutping romanisation system for Cantonese? | Linguistic Society of Hong Kong | not run | not run |
| 306853 | In which city was the Jyutping romanisation system developed? | Hong Kong | not run | not run |
| 306853 | In what year was the Jyutping romanisation system developed? | 1993 | not run | not run |
| 306853 | Jyutping |  | not run | not run |
| 306853 | What is the literal meaning of the name 'Jyutping'? | Yue (i.e. Cantonese) spelling | not run | not run |
| 143117 | Gujarati language |  | not run | not run |
| 67211 | Electron configuration |  | not run | not run |
| 292259 | Who is the Director-General of Deutsche Welle? | Barbara Massing | not run | not run |
| 292259 | In which city is the headquarters of Deutsche Welle located? | Bonn | not run | not run |
| 292259 | How many languages does Deutsche Welle broadcast in? | 32 | not run | not run |
| 292259 | What month, day, and year was Deutsche Welle launched? | May 3, 1953 | CORRECT; predicted_answer: Deutsche Welle was launched on May 3, 1953. | not run |
| 292259 | What is the picture format used by Deutsche Welle for its broadcasts? | 1080i ( HDTV ) | INCORRECT; predicted_answer: Deutsche Welle uses the 16:9 picture format for its broadcasts. | CORRECT; predicted_answer: Deutsche Welle (DW) primarily broadcasts in **16:9** aspect ratio using the **1080i** High Definition (HD) format. |
| 186191 | Who was the designer of the T-72 tank? | Leonid Kartsev; Valeri Venediktov | not run | not run |
| 186191 | What is the place of origin of the T-72 tank? | Soviet Union | CORRECT; predicted_answer: The T-72 tank originated in the Soviet Union. | not run |
| 186191 | How many crew members operate the T-72 tank? | 3 | not run | not run |
| 4236415 | Who is the father of the Ashvins according to their genealogy? | Surya | not run | not run |
| 4236415 | Ashvins |  | not run | not run |
| 4236415 | How many sons are listed as children of the Ashvins? | 2 | not run | not run |
| 4236415 | Ashvins |  | not run | not run |
| 4236415 | What is the Greek equivalent name of the Ashvins? | Dioskuri | CORRECT; predicted_answer: The Greek equivalent of the Ashvins is the Dioscuri. | not run |
| 26211 | Racketeer Influenced and Corrupt Organizations Act |  | not run | not run |
| 81890 | Fife |  | not run | not run |
| 1050340 | Election Day (United States) |  | not run | not run |
| 1050340 | In which country is the annual Election Day observed as the day for general elections of federal, state, and local public officials? | United States | not run | not run |
| 1050340 | How many days after the first Monday in November is Election Day held in the United States? | 1 | not run | not run |
| 1050340 | What is the date of Election Day in the United States in the year 2028? | November 7, 2028 | not run | not run |
| 1050340 | What is the frequency of Election Day occurrences in the United States including off-years? | Biennial (annual if including off-years) | CORRECT; predicted_answer: In the United States, Election Day occurs annually on the Tuesday following the first Monday in November. This means there is an Election Day every year, including off-years (years without major federal elections like presidential or midterm elections). | not run |
| 67127 | What is the full name of the athlete known as Carl Lewis? | Frederick Carlton Lewis | not run | not run |
| 67127 | In which city was Carl Lewis born? | Birmingham | CORRECT; predicted_answer: Carl Lewis was born in Birmingham, Alabama. | not run |
| 67127 | In what year did Carl Lewis retire from professional track and field? | 1997 | not run | not run |
| 67127 | What month, day, and year was Carl Lewis born? | July 1, 1961 | not run | not run |
| 67127 | What is the name of the club Carl Lewis was affiliated with during his athletic career? | Santa Monica Track Club | CORRECT; predicted_answer: Carl Lewis was affiliated with the Santa Monica Track Club during his athletic career. | not run |
| 6392374 | Sea captain |  | not run | not run |
| 6392374 | What is the location where a sea captain primarily operates? | At sea | CORRECT; predicted_answer: A sea captain primarily operates on a ship or vessel at sea. | not run |
| 6392374 | Sea captain |  | not run | not run |
| 6392374 | Sea captain |  | not run | not run |
| 6392374 | What type of license is required for a sea captain according to the infobox? | master's license or extra master's license or commissioned officer | not run | not run |
| 32133 | Urethra |  | not run | not run |
| 32133 | What precursor anatomical structure is the urethra derived from? | Urogenital sinus | not run | not run |
| 32133 | How many arteries supply blood to the urethra according to the infobox? | 3 | not run | not run |
| 32133 | Urethra |  | not run | not run |
| 32133 | What is the Latin anatomical term for the female urethra? | urethra feminina | CORRECT; predicted_answer: The Latin anatomical term for the female urethra is **urethra feminina**. | not run |
| 697535 | Who created the AllMusic online music database? | Michael Erlewine | not run | not run |
| 697535 | AllMusic |  | not run | not run |
| 697535 | How many years ago was the AllMusic website launched? | 35 | not run | not run |
| 697535 | In what year was the AllMusic website launched? | 1991 | not run | not run |
| 604350 | Who is the chairman listed as a key person for ARD broadcaster? | Florian Hager | not run | not run |
| 604350 | In which country is the ARD broadcaster based? | Germany | not run | not run |
| 604350 | How many years ago was the ARD broadcaster launched? | 75 | not run | not run |
| 2839 | Angular momentum |  | not run | not run |
| 66958 | Who is the central bank responsible for issuing the official currency of the People's Republic of China? | People's Bank of China | not run | not run |
| 66958 | Which country uses the official currency known as the Renminbi? | China | not run | not run |
| 66958 | What is the ISO 4217 numeric code for the Renminbi currency? | 156 | not run | not run |
| 66958 | What year was the Renminbi officially introduced? | 1948 | CORRECT; predicted_answer: The Renminbi was officially introduced in 1948. | not run |
| 66958 | What is the basic unit name of the Renminbi currency? | yuán | not run | not run |
| 458762 | Convair B-58 Hustler |  | not run | not run |
| 190884 | Khalid Sheikh Mohammed |  | not run | not run |
| 8971303 | Chivas USA |  | not run | not run |
| 8971303 | What city was the home stadium of Chivas USA located in? | Carson | not run | not run |
| 8971303 | In what year was Chivas USA founded? | 2004 | not run | not run |
| 8971303 | What month, day, and year was Chivas USA dissolved? | October 27, 2014 | not run | not run |
| 8971303 | What is the full official name of the soccer club known as Chivas USA? | Club Deportivo Chivas USA | CORRECT; predicted_answer: The full official name of the soccer club known as Chivas USA was "Club Deportivo Chivas USA." | not run |
| 74011 | Who wrote the screenplay for the 1952 film High Noon? | Carl Foreman | not run | not run |
| 74011 | What country produced the 1952 film High Noon? | United States | not run | not run |
| 74011 | What is the running time in minutes of the 1952 film High Noon? | 85 | not run | not run |
| 74011 | What month, day, and year was the film High Noon released? | July 24, 1952 | not run | not run |
| 74011 | What is the name of the production company behind the 1952 film High Noon? | Stanley Kramer Productions | CORRECT; predicted_answer: The production company behind the 1952 film *High Noon* is Stanley Kramer Productions. | not run |
| 56636 | Colombo |  | not run | not run |
| 2043650 | Who is the editor of Uncut magazine? | Michael Bonner | not run | not run |
| 2043650 | In which city is Uncut magazine based? | London | not run | not run |
| 2043650 | How many issues of Uncut magazine are published per year? | 12 | not run | not run |
| 2043650 | What month and year was the first issue of Uncut magazine published? | May 1997 | not run | not run |
| 2043650 | What is the official website of Uncut magazine? | uncut.co.uk | CORRECT; predicted_answer: The official website of Uncut magazine is https://www.uncut.co.uk/ | not run |
| 910914 | Young Artist Award |  | not run | not run |
| 910914 | In which country is the Young Artist Award presented? | United States | not run | not run |
| 910914 | What is the ordinal number of the current Young Artist Awards ceremony? | 45 | not run | not run |
| 910914 | What month and year was the first Young Artist Award ceremony held? | October 1979 | not run | not run |
| 60382764 | Reiwa era |  | not run | not run |
| 22707 | Oolong |  | not run | not run |
| 1003268 | Which historical figure is associated with the colloquial name of the stage of the English language from the beginning of the Tudor period to the English Interregnum and Restoration? | William Shakespeare | not run | not run |
| 1003268 | Which countries are native regions of the stage of the English language from the beginning of the Tudor period to the English Interregnum and Restoration? | England; Wales; Scotland; Ireland | not run | not run |
| 46989 | Grand Canyon |  | not run | not run |
| 46989 | In which U.S. state is the Grand Canyon located? | Arizona | not run | not run |
| 46989 | What is the length in miles of the Grand Canyon? | 277 | not run | not run |
| 46989 | Grand Canyon |  | not run | not run |
| 46989 | What river carved the Grand Canyon? | Colorado River | not run | not run |
| 64384 | Who is the artist known for the paintings The Hunters in the Snow and The Peasant Wedding? | Pieter Bruegel the Elder | not run | not run |
| 64384 | In which city was Pieter Bruegel the Elder probably born? | Breda | not run | not run |
| 22093 | Who is the commissioner of the National Basketball Association? | Adam Silver | not run | not run |
| 22093 | What city is the headquarters of the National Basketball Association located in? | New York City | not run | not run |
| 22093 | How many teams are in the National Basketball Association? | 30 | not run | not run |
| 22093 | On what month, day, and year was the National Basketball Association founded as the BAA? | June 6, 1946 | CORRECT; predicted_answer: The National Basketball Association (NBA) was founded as the Basketball Association of America (BAA) on June 6, 1946. | not run |
| 22093 | What sport does the National Basketball Association represent? | Basketball | not run | not run |
| 7632 | Cerebrospinal fluid |  | not run | not run |
| 7632 | Cerebrospinal fluid |  | not run | not run |
| 7632 | Cerebrospinal fluid |  | not run | not run |
| 7632 | Cerebrospinal fluid |  | not run | not run |
| 7632 | What is the Latin term for cerebrospinal fluid? | liquor cerebrospinalis | not run | not run |
| 22450 | Who is credited as the inventor of the open-wheel car? | Ray Harroun | not run | not run |
| 22450 | Open-wheel car |  | not run | not run |
| 22450 | How many wheels can an open-wheel car have? | 4 (acceptable range: anything between 3 and 5) | CORRECT; predicted_answer: An open-wheel car typically has 4 wheels. | not run |
| 22450 | Open-wheel car |  | not run | not run |
| 22450 | What is the fuel source used by open-wheel cars? | Gasoline; electric; hydrogen | not run | not run |
| 64300 | Who is the voice actor of Bart Simpson? | Nancy Cartwright | not run | not run |
| 64300 | What is the city where Bart Simpson's home is located? | Springfield | not run | not run |
| 64300 | What grade is Bart Simpson attending at Springfield Elementary School? | 4 | not run | not run |
| 64300 | On what month, day, and year did Bart Simpson first appear on television? | April 19, 1987 | not run | not run |
| 64300 | What is the full name of the character Bart Simpson? | Bartholomew Jo-Jo Simpson | CORRECT; predicted_answer: The full name of the character Bart Simpson is Bartholomew JoJo Simpson. | not run |
| 246305 | Livorno |  | not run | not run |
| 479512 | Better Business Bureau |  | not run | not run |
| 521893 | Voiced bilabial plosive |  | not run | not run |
| 521893 | Voiced bilabial plosive |  | not run | not run |
| 521893 | What is the IPA number assigned to the voiced bilabial plosive? | 102 (acceptable range: anything between 101 and 103) | CORRECT; predicted_answer: The IPA number assigned to the voiced bilabial plosive is 102. | not run |
| 521893 | Voiced bilabial plosive |  | not run | not run |
| 521893 | What is the Unicode hexadecimal code point for the voiced bilabial plosive? | U+0062 | CORRECT; predicted_answer: The Unicode hexadecimal code point for the voiced bilabial plosive (the letter **b** in the International Phonetic Alphabet) is **U+0062**. | not run |
| 171623 | Who directed the 2001 film Training Day? | Antoine Fuqua | not run | not run |
| 171623 | What country produced the film Training Day? | United States | not run | not run |
| 171623 | What is the running time in minutes of the film Training Day? | 122 | not run | not run |
| 171623 | What month, day, and year was Training Day first released at the Venice Film Festival? | September 2, 2001 | not run | not run |
| 171623 | What language is spoken in the film Training Day? | English | not run | not run |
| 5489 | Chile |  | not run | not run |
| 72760 | Square kilometre |  | not run | not run |
| 31388 | Treaty of Brest-Litovsk |  | not run | not run |
| 31388 | What city was the Treaty of Brest-Litovsk signed in? | Brest-Litovsk | not run | not run |
| 31388 | How many languages were used in the Treaty of Brest-Litovsk? | 5 | not run | not run |
| 31388 | On what month, day, and year was the Treaty of Brest-Litovsk signed? | March 3, 1918 | not run | not run |
| 57708 | Who was the mayor of Topeka, Kansas according to the infobox? | Spencer Duncan | not run | not run |
| 57708 | In which county is the city of Topeka, Kansas located? | Shawnee | not run | not run |
| 57708 | What was the population of Topeka, Kansas according to the 2020 census? | 126587 | not run | not run |
| 57708 | In what year was Topeka, Kansas incorporated? | 1857 | not run | not run |
| 57708 | What is the demonym for residents of Topeka, Kansas? | Topekan | CORRECT; predicted_answer: The demonym for residents of Topeka, Kansas is "Topekan." | not run |
| 951393 | Filial piety |  | not run | not run |
| 17416221 | South Africa |  | not run | not run |
| 30125638 | Cubic metre |  | not run | not run |
| 63503 | Duluth, Minnesota |  | not run | not run |
| 10209822 | Who was the father of Edward the Elder? | Alfred the Great | CORRECT; predicted_answer: The father of Edward the Elder was Alfred the Great. | not run |
| 10209822 | In which city was Edward the Elder coronated? | Kingston upon Thames | CORRECT; predicted_answer: Edward the Elder was coronated in Kingston upon Thames. | not run |
| 10209822 | How many spouses did Edward the Elder have? | 3 | not run | not run |
| 10209822 | What month, day, and year did Edward the Elder die? | July 17, 924 | not run | not run |
| 10209822 | What was the name of the house to which Edward the Elder belonged? | Wessex | not run | not run |
| 56617 | Bangui |  | not run | not run |
| 5070109 | Spanish Armada |  | not run | not run |
| 5070109 | What war was the Spanish Armada part of? | Anglo-Spanish War | not run | not run |
| 5070109 | Spanish Armada |  | not run | not run |
| 5070109 | In what year did the Anglo-Spanish War involving the Spanish Armada begin? | 1585 | not run | not run |
| 5070109 | What is the name of the war also associated with the Spanish Armada besides the Anglo-Spanish War? | Eighty Years' War | CORRECT; predicted_answer: The war also associated with the Spanish Armada besides the Anglo-Spanish War is the **Eighty Years' War**. | not run |
| 40176 | Joseph Priestley |  | not run | not run |
| 404204 | November Uprising |  | not run | not run |
| 404204 | November Uprising |  | not run | not run |
| 404204 | November Uprising |  | not run | not run |
| 404204 | What year did the November Uprising take place? | 1830 | not run | not run |
| 404204 | What was the outcome of the November Uprising? | Russian victory | not run | not run |
| 10893 | Fencing |  | not run | not run |
| 10893 | What country or region is fencing practiced worldwide in? | Worldwide | not run | not run |
| 10893 | Fencing |  | not run | not run |
| 10893 | In what year did fencing become part of the Summer Olympic programme? | 1896 | not run | not run |
| 10893 | What is the name of the venue where fencing competitions are held? | Piste | CORRECT; predicted_answer: Fencing competitions are held in a venue called a "piste." | not run |
| 534617 | Who created the original artwork for the Care Bears? | Elena Kucharik | not run | not run |
| 534617 | In which city or location was the group that created the Care Bears based? | Cleveland | not run | not run |
| 534617 | How many theatrical Care Bears films were released according to the infobox? | 3 | not run | not run |
| 534617 | What year were the Care Bears originally created for greeting cards? | 1981 | not run | not run |
| 534617 | What is the name of the company that published the original Care Bears greeting cards? | American Greetings | not run | not run |
| 2924002 | Electronic dance music |  | not run | not run |
| 313647 | Mpumalanga |  | not run | not run |
| 129295 | Who directed the 1987 film Fatal Attraction? | Adrian Lyne | not run | not run |
| 129295 | In which country was the film Fatal Attraction produced? | United States | not run | not run |
| 129295 | What is the running time in minutes of the film Fatal Attraction? | 119 | not run | not run |
| 129295 | What month, day, and year was Fatal Attraction released in the United States? | September 18, 1987 | not run | not run |
| 40158 | Who is the mayor of Berchtesgaden for the term 2020 to 2026? | Franz Rasp | not run | not run |
| 40158 | In which German state is the municipality of Berchtesgaden located? | Bavaria | not run | not run |
| 40158 | What is the vehicle registration code number for Berchtesgaden? | BGL | CORRECT; predicted_answer: The vehicle registration code number for Berchtesgaden is "BGL." | not run |
| 40158 | As of what date is the population data for Berchtesgaden recorded? | December 31, 2024 | not run | not run |
| 152333 | Provinces of Belgium |  | not run | not run |
| 84952 | Who was the boxer known as Marvelous Marvin Hagler at birth? | Marvin Nathaniel Hagler | not run | not run |
| 84952 | In which city was Marvelous Marvin Hagler born? | Newark | not run | not run |
| 84952 | How many total professional fights did Marvelous Marvin Hagler have? | 67 | not run | not run |
| 84952 | What month, day, and year did Marvelous Marvin Hagler die? | March 13, 2021 | CORRECT; predicted_answer: Marvelous Marvin Hagler died on March 13, 2021. | not run |
| 84952 | What was Marvelous Marvin Hagler's boxing stance? | Southpaw | CORRECT; predicted_answer: Marvelous Marvin Hagler's boxing stance was southpaw. | not run |
| 2507138 | First Austrian Republic |  | not run | not run |
| 204971 | Historic counties of England |  | not run | not run |
| 187544 | Hermann Weyl |  | not run | not run |
| 415156 | Who directed the 2002 film XXX? | Rob Cohen | not run | not run |
| 415156 | What country produced the 2002 film XXX? | United States | not run | not run |
| 415156 | What is the running time in minutes of the 2002 film XXX? | 124 | not run | not run |
| 415156 | What month, day, and year was the 2002 film XXX released? | August 9, 2002 | CORRECT; predicted_answer: The 2002 film XXX was released on August 9, 2002. | not run |
| 415156 | What is the language of the 2002 film XXX? | English | not run | not run |
| 10149834 | Who directed the eighth film Miyazaki directed for Studio Ghibli? | Hayao Miyazaki | not run | not run |
| 10149834 | What country produced the eighth film Miyazaki directed for Studio Ghibli? | Japan | not run | not run |
| 10149834 | What is the running time in minutes of the eighth film Miyazaki directed for Studio Ghibli? | 101 (acceptable range: anything between 100 and 102) | CORRECT; predicted_answer: The eighth film Hayao Miyazaki directed for Studio Ghibli is "Ponyo" (2008). Its running time is approximately 101 minutes. | not run |
| 10149834 | What month, day, and year was the eighth film Miyazaki directed for Studio Ghibli released? | July 19, 2008 | CORRECT; predicted_answer: The eighth film Hayao Miyazaki directed for Studio Ghibli, "Ponyo," was released on July 19, 2008. | not run |
| 10149834 | What is the Japanese name of the eighth film Miyazaki directed for Studio Ghibli? | 崖の上のポニョ | not run | not run |
| 105908 | Ford Mustang |  | not run | not run |
| 105908 | In which country is the Ford Mustang manufactured? | United States | not run | not run |
| 57951 | Provinces of the Netherlands |  | not run | not run |
| 57951 | What country are the provinces located in? | the Netherlands | not run | not run |
| 57951 | How many provinces are there in the Netherlands? | 12 | not run | not run |
| 57951 | Provinces of the Netherlands |  | not run | not run |
| 57951 | What is the name of the government body that administers the provinces of the Netherlands? | Provincial executive | CORRECT; predicted_answer: The government body that administers the provinces of the Netherlands is called the **Provincial Executive** (in Dutch, **Gedeputeerde Staten**). | not run |
| 176871 | Convair F-106 Delta Dart |  | not run | not run |
| 8429 | Density |  | not run | not run |
| 60058274 | Who directed the film Licorice Pizza? | Paul Thomas Anderson | not run | not run |
| 60058274 | In which country was the film Licorice Pizza produced? | United States | not run | not run |
| 60058274 | What is the running time in minutes of the film Licorice Pizza? | 133 (acceptable range: anything between 132 and 134) | CORRECT; predicted_answer: The running time of the film *Licorice Pizza* is 133 minutes. | not run |
| 60058274 | What month, day, and year was the film Licorice Pizza released? | November 26, 2021 | CORRECT; predicted_answer: The film Licorice Pizza was released on November 26, 2021. | not run |
| 60058274 | What is the original language of the film Licorice Pizza? | English | not run | not run |
| 880255 | Who won the Outland Trophy in 1957? | Alex Karras | CORRECT; predicted_answer: The Outland Trophy in 1957 was won by Alex Karras. | not run |
| 880255 | In which city was Alex Karras born? | Gary | not run | not run |
| 880255 | What was Alex Karras's overall pick number in the 1958 NFL draft? | 10 | not run | not run |
| 880255 | What month, day, and year was Alex Karras born? | July 15, 1935 | not run | not run |
| 880255 | What position did Alex Karras play in football? | Defensive tackle | not run | not run |
| 5643 | Channel Islands |  | not run | not run |
| 5643 | What is the capital city of the Bailiwick of Guernsey? | Saint Peter Port | not run | not run |
| 5643 | How many inhabited islands are there in the Channel Islands archipelago? | 7 | not run | not run |
| 5643 | Channel Islands |  | not run | not run |
| 5643 | What is the time zone of the Channel Islands during standard time? | Greenwich Mean Time | not run | not run |
| 277011 | Who is the maternal grandfather of Tom Felton? | Nigel Anstey | not run | not run |
| 277011 | In which city was Tom Felton born? | Epsom | not run | not run |
| 277011 | How many years has Tom Felton been active in his career as of the data in the table? | 28 | not run | not run |
| 277011 | What is the month, day, and year of Tom Felton's birth? | September 22, 1987 | not run | not run |
| 277011 | What is the official website URL of Tom Felton? | tomfelton.com | CORRECT; predicted_answer: The official website URL of Tom Felton is https://www.tomfelton.com/ | not run |
| 109566 | Winter Park, Florida |  | not run | not run |
| 109566 | In which county is the city of Winter Park located? | Orange | not run | not run |
| 109566 | What was the population of Winter Park according to the 2020 census? | 29795 | not run | not run |
| 83115 | 1968 Summer Olympics |  | not run | not run |
| 615800 | Who is the full name of the footballer known as Cafu? | Marcos Evangelista de Morais | not run | not run |
| 615800 | What city was Cafu born in? | Itaquaquecetuba | not run | not run |
| 82050 | Who is the Command Master Chief Petty Officer of the Royal Norwegian Navy? | Master Chief Petty Officer Arild Edinsen | INCORRECT; predicted_answer: The Command Master Chief Petty Officer of the Royal Norwegian Navy is Command Master Chief Petty Officer Geir Håvard Husebø. | CORRECT; predicted_answer: The current Command Master Chief Petty Officer of the Royal Norwegian Navy is **Arild Edinsen**. |
| 82050 | What is the location of the headquarters of the Royal Norwegian Navy? | Haakonsvern | not run | not run |
| 82050 | How many vessels did the Royal Norwegian Navy have as of 2008? | 70 | not run | not run |
| 82050 | On what month, day, and year was the Royal Norwegian Navy officially founded? | April 12, 1814 | not run | not run |
| 41853326 | Inter Miami CF |  | not run | not run |
| 54232 | Reinforced concrete |  | not run | not run |
| 3351466 | Capezio |  | not run | not run |
| 901117 | Ujjain |  | not run | not run |
| 1582694 | Who is the founder of Wisden Cricketers' Almanack? | John Wisden | not run | not run |
| 1582694 | In which city is Wisden Cricketers' Almanack based? | London | not run | not run |
| 1582694 | How many years ago was the first issue of Wisden Cricketers' Almanack published? | 162 | not run | not run |
| 1582694 | What year was the first issue of Wisden Cricketers' Almanack published? | 1864 | not run | not run |
| 1582694 | What is the name of the publisher of Wisden Cricketers' Almanack? | Bloomsbury | not run | not run |
| 182283 | Miles per hour |  | not run | not run |
| 199445 | Who was the manager of Derby County from 2020 to 2022? | Wayne Rooney | not run | not run |
| 199445 | What city was Wayne Rooney born in? | Liverpool | not run | not run |
| 2310937 | 2000 NFL season |  | not run | not run |
| 2310937 | What city hosted the Super Bowl XXXV game in the 2000 NFL season? | Tampa | not run | not run |
| 2310937 | How many days did the regular season last in the 2000 NFL season? | 114 | not run | not run |
| 2310937 | What month, day, and year was the Super Bowl XXXV played in the 2000 NFL season? | January 28, 2001 | not run | not run |
| 2310937 | What stadium hosted the Pro Bowl game following the 2000 NFL season? | Aloha Stadium | not run | not run |
| 601094 | Korma |  | not run | not run |
| 601094 | What empire is the place of origin of Korma? | Mughal Empire | not run | not run |
| 601094 | How many main ingredients are listed for Korma in the infobox? | 2 | not run | not run |
| 601094 | Korma |  | not run | not run |
| 601094 | What is the serving temperature of Korma according to the infobox? | Hot | not run | not run |
| 248339 | Brandon, Manitoba |  | not run | not run |
| 28901997 | Critics' Choice Awards |  | not run | not run |
| 28901997 | In which country are the Critics' Choice Awards presented? | United States | not run | not run |
| 28901997 | What number edition is the current Critics' Choice Awards? | 31 | not run | not run |
| 28901997 | In what year was the first Critics' Choice Award given? | 1996 | not run | not run |
| 28901997 | What organization presents the Critics' Choice Awards? | Critics Choice Association | not run | not run |
| 812281 | EuroBasket |  | not run | not run |
| 812281 | What continent hosts the main international basketball competition for the senior men's national teams known as EuroBasket? | Europe | not run | not run |
| 812281 | How many teams participate in the EuroBasket basketball competition? | 24 | not run | not run |
| 812281 | In what year was the EuroBasket basketball competition founded? | 1935 | not run | not run |
| 812281 | What is the name of the organising body of the EuroBasket basketball competition? | FIBA Europe | not run | not run |
| 329529 | Who is the dean of the medical school of Harvard University? | George Q. Daley | not run | not run |
| 329529 | In which city is the medical school of Harvard University located? | Boston | not run | not run |
| 329529 | How many MD students are enrolled at the medical school of Harvard University? | 712 (acceptable range: anything between 705 and 719) | INCORRECT; predicted_answer: Harvard Medical School typically enrolls about 165 MD students per class year, totaling approximately 660 MD students across all four years. | CORRECT; predicted_answer: There are currently **712** MD students enrolled at Harvard Medical School (HMS) for the 2023–2024 academic year. |
| 329529 | On what month, day, and year was the medical school of Harvard University established? | September 19, 1782 | not run | not run |
| 329529 | What type of institution is the medical school of Harvard University classified as? | Private medical school | CORRECT; predicted_answer: The medical school of Harvard University is classified as a private institution. | not run |
| 81572 | Bristol Blenheim |  | not run | not run |
| 134987 | Rapid City, South Dakota |  | not run | not run |
| 14610495 | 2 Girls 1 Cup |  | not run | not run |
| 142549 | Peritonitis |  | not run | not run |
| 142549 | Peritonitis |  | not run | not run |
| 142549 | How many types of peritonitis are listed in the infobox? | 5 | not run | not run |
| 142549 | Peritonitis |  | not run | not run |
| 142549 | What is the usual onset of peritonitis according to the infobox? | Sudden | not run | not run |
| 1048946 | Chamorro people |  | not run | not run |
| 404595 | NCAA Division I Football Championship |  | not run | not run |
| 404595 | What city hosts the NCAA Division I Football Championship starting in 2026? | Nashville | not run | not run |
| 404595 | How many years was the NCAA Division I Football Championship held at Toyota Stadium? | 16 | not run | not run |
| 404595 | In what year did the NCAA Division I Football Championship start being operated under its current name? | 2006 | not run | not run |
| 404595 | What is the name of the stadium hosting the NCAA Division I Football Championship from 2026 onward? | FirstBank Stadium | not run | not run |
| 8083 | Who was Dr. Dre married to in 1996? | Nicole Plotzker | CORRECT; predicted_answer: In 1996, Dr. Dre was married to Nicole Young. | not run |
| 8083 | In which city was Dr. Dre born? | Compton | CORRECT; predicted_answer: Dr. Dre was born in Compton, California. | not run |
| 610522 | Who is one of the founders of MobyGames? | Jim Leonard | not run | not run |
| 610522 | In what language is MobyGames primarily available? | English | not run | not run |
| 610522 | How many years ago was MobyGames launched? | 27 | not run | not run |
| 610522 | What month, day, and year was MobyGames launched? | March 1, 1999 | not run | not run |
| 610522 | What is the commercial status of MobyGames? | Yes | CORRECT; predicted_answer: MobyGames is a commercial website. | not run |
| 33643148 | Jam band |  | not run | not run |
| 42229472 | Who is the producer of the Glottolog database? | Max Planck Institute of Geoanthropology | not run | not run |
| 42229472 | In which country is the producer of Glottolog located? | Germany | not run | not run |
| 42229472 | How many languages does Glottolog support? | 1 | not run | not run |
| 42229472 | Glottolog |  | not run | not run |
| 42229472 | What is the cost to access the Glottolog database? | Free | CORRECT; predicted_answer: Access to the Glottolog database is free of charge. | not run |
| 4595410 | 1970 United States census |  | not run | not run |
| 540034 | Amyloidosis |  | not run | not run |
| 540034 | Amyloidosis |  | not run | not run |
| 33134 | World music |  | not run | not run |
| 33134 | What geographic regions are listed as regional scenes for world music? | North America and Europe Balkans | not run | not run |
| 33134 | World music |  | not run | not run |
| 33134 | World music |  | not run | not run |
| 33134 | What is the derivative form of world music listed in the infobox? | Folktronica | not run | not run |
| 19746798 | Here Technologies |  | not run | not run |
| 650522 | Sickle |  | not run | not run |
| 422038 | Who is the mayor of the municipality of Vigo? | Abel Caballero | CORRECT; predicted_answer: The mayor of the municipality of Vigo is Abel Caballero. | not run |
| 422038 | In which province is the city of Vigo located? | Pontevedra | not run | not run |
| 422038 | How many parishes are there in the municipality of Vigo? | 17 | not run | not run |
| 422038 | Vigo |  | not run | not run |
| 312038 | Who is the bodhisattva primarily revered in East Asian Buddhism known for his vow to instruct all beings in the six worlds? | Kṣitigarbha | not run | not run |
| 312038 | What is the geographic region where Kṣitigarbha is primarily venerated? | East Asia | not run | not run |
| 312038 | How many worlds does Kṣitigarbha vow to instruct all beings in? | 6 | not run | not run |
| 312038 | Kṣitigarbha |  | not run | not run |
| 312038 | What is the Sanskrit name of the bodhisattva known as Earth Store? | क्षितिगर्भ | not run | not run |
| 524850 | Voiced palatal approximant |  | not run | not run |
| 524850 | Voiced palatal approximant |  | not run | not run |
| 524850 | What is the IPA number assigned to the voiced palatal approximant? | 153 (acceptable range: anything between 151 and 155) | INCORRECT; predicted_answer: The IPA number assigned to the voiced palatal approximant is 156. | CORRECT; predicted_answer: The IPA number assigned to the voiced palatal approximant [j] is **153**. |
| 524850 | Voiced palatal approximant |  | not run | not run |
| 524850 | What is the Unicode hexadecimal code point for the voiced palatal approximant? | U+006A | INCORRECT; predicted_answer: The Unicode hexadecimal code point for the voiced palatal approximant (ʝ) is **U+029D**. | CORRECT; predicted_answer: The Unicode hexadecimal code point for the voiced palatal approximant (**j**) is **U+006A**. |


## Rejected And Rerun Decisions

| Page ID | Stage | Exact reason | Page/question |
| ---: | --- | --- | --- |
| 9119 | `route_generation` | `wikipedia_infobox_no_tables` | Distinguished Service Medal (U.S. Army) |
| 257453 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=infobox;available=wikitable` | Butte, Montana |
| 255999 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=infobox;available=wikitable` | Stairway to Heaven |
| 206997 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=infobox;available=wikitable` | Alsace–Lorraine |
| 963152 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=infobox;available=wikitable` | Spaniards |
| 173652 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=infobox;available=wikitable` | Hemorrhoid |
| 37284 | `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_self_containment_forbidden_phrase:listed` | Which virus is listed as a risk factor for brain tumors? |
| 37284 | `rewrite_surface` | `rule_based_answer_type_gate_rejected:place_question_category_whitelist` | In which part of the brain can brain metastasis from lung cancer be found as shown in the imaging? |
| 37284 | `route_generation` | `wikipedia_infobox_answer_type_not_allowed:answer_type_not_allowed:Number; allowed=Number` | What is the average five-year survival rate percentage for brain tumors in the US? |
| 37284 | `route_generation` | `wikipedia_infobox_llm_discarded:No date value is present in the table to form a valid date question.` | Brain tumor |
| 37284 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What is one of the diagnostic methods used to detect brain tumors? |
| 9316 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=infobox;available=wikitable` | England |
| 10477 | `rewrite_surface` | `rule_based_answer_type_gate_rejected:person_common_words_minus_common_names` | Who is the father of the goddess and personification of the dawn in ancient Greek mythology? |
| 10477 | `rewrite_surface` | `rule_based_answer_type_gate_rejected:place_question_category_whitelist` | What is the abode of the goddess and personification of the dawn in ancient Greek mythology? |
| 10477 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | How many siblings does the goddess and personification of the dawn have according to ancient Greek mythology? |
| 10477 | `route_generation` | `wikipedia_infobox_llm_discarded:No date or year information is present in the table to form a valid date question.` | Eos |
| 10477 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What is one of the symbols associated with the goddess and personification of the dawn in ancient Greek mythology? |
| 180174 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=infobox;available=wikitable` | Niagara Falls, Ontario |
| 231031 | `search_longtail` | `search_longtail_verifier_rejected:full_question:answer_in_title` | Who is the Chancellor of the University of Western Australia? |
| 231031 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | In which city is the University of Western Australia located? |
| 231031 | `route_generation` | `wikipedia_infobox_answer_type_not_allowed:answer_type_not_allowed:Number; allowed=Number` | How many years ago was the University of Western Australia established? |
| 231031 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What month, day, and year was the University of Western Australia established? |
| 231031 | `search_longtail` | `search_longtail_verifier_rejected:keyword_queries:hit_rate_exceeded` | What is the motto of the University of Western Australia? |
| 70298 | `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is present in the infobox data.` | Midwest League |
| 70298 | `rewrite_surface` | `answer_too_popular:United States` | In which country is the Midwest League based? |
| 70298 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | How many teams are in the Midwest League? |
| 70298 | `search_longtail` | `search_longtail_verifier_rejected:keyword_queries:hit_rate_exceeded` | In what year was the Midwest League founded? |
| 70298 | `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_time_invariance_forbidden_phrase:current` | What is the current classification level of the Midwest League as of 2021? |
| 372315 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=infobox;available=wikitable` | Moscow Oblast |
| 1674887 | `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is provided in the infobox.` | EBSCO Information Services |
| 1674887 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | What city is the headquarters of EBSCO Information Services located in? |
| 1674887 | `route_generation` | `wikipedia_infobox_answer_type_not_allowed:answer_type_not_allowed:Number; allowed=Number` | In what year was EBSCO Information Services founded? |
| 1674887 | `route_generation` | `wikipedia_infobox_llm_discarded:No full calendar date or month and year is provided in the infobox.` | EBSCO Information Services |
| 29125601 | `route_generation` | `wikipedia_infobox_no_tables` | Flemish people |
| 498538 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | Who is the president of the University of New Hampshire? |
| 498538 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | What city is the main campus of the University of New Hampshire located in? |
| 49188979 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=infobox;available=wikitable` | Normandy (administrative region) |
| 32611 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=infobox;available=wikitable` | Vietnam War |
| 219424 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=infobox;available=wikitable` | Sergeant |
| 24218875 | `search_longtail` | `search_longtail_verifier_rejected:full_question:answer_in_title` | Who is the founder of Deadline Hollywood? |
| 24218875 | `rewrite_surface` | `answer_too_popular:United States` | In which country is the headquarters of Deadline Hollywood located? |
| 24218875 | `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_self_containment_forbidden_phrase:listed` | How many editors are listed for Deadline Hollywood? |
| 453433 | `route_generation` | `wikipedia_infobox_table_filter_rejected:infobox_remaining_rows_lt_min:remaining_non_header_rows=1;min=5` | Scallion |
| 309294 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=infobox;available=wikitable` | Albany, Western Australia |
| 82075 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=infobox;available=wikitable` | Santa Cruz County, California |
| 972904 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | Who is the editor-in-chief of Vibe magazine? |
| 972904 | `rewrite_surface` | `answer_too_popular:New York City` | In which city is Vibe magazine based? |
| 972904 | `route_generation` | `wikipedia_infobox_answer_type_not_allowed:answer_type_not_allowed:Number; allowed=Number` | In what year was Vibe magazine founded? |
| 972904 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What month and year was Vibe magazine founded? |
| 972904 | `rewrite_surface` | `answer_too_popular:English` | What is the primary language of Vibe magazine? |
| 628232 | `search_longtail` | `search_longtail_verifier_rejected:full_question:answer_in_title` | Who is the full name of the South Korean footballer born on March 30, 1981? |
| 628232 | `search_longtail` | `search_longtail_verifier_rejected:keyword_queries:hit_rate_exceeded` | What city is the birthplace of Park Ji-sung? |
| 628232 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | How many total club domestic league appearances did Park Ji-sung make in his senior career? |
| 50762105 | `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is present in the infobox to form a valid question.` | Emphysema |
| 50762105 | `route_generation` | `wikipedia_infobox_llm_discarded:No geographic place or location is present in the infobox to form a valid question.` | Emphysema |
| 50762105 | `route_generation` | `wikipedia_infobox_answer_type_not_allowed:answer_type_not_allowed:Number; allowed=Number` | At what minimum age in years does emphysema usually onset? |
| 50762105 | `route_generation` | `wikipedia_infobox_llm_discarded:No specific date, month, or year is provided in the infobox to form a valid question.` | Emphysema |
| 50762105 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What is the primary medical specialty that deals with emphysema? |
| 8196151 | `route_generation` | `wikipedia_infobox_no_tables` | List of states of Mexico |
| 4836072 | `rewrite_surface` | `rule_based_answer_type_gate_rejected:person_common_words_minus_common_names` | Who directed the 1964 film My Fair Lady? |
| 4836072 | `rewrite_surface` | `answer_too_popular:United States` | What country produced the 1964 film My Fair Lady? |
| 21355232 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=infobox;available=wikitable` | List of national parks of the United States |
| 8318491 | `route_generation` | `wikipedia_infobox_no_tables` | Southeastern Anatolia region |
| 306966 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=infobox;available=wikitable` | Kataeb Party |
| 35972636 | `route_generation` | `wikipedia_infobox_no_tables` | ORMO |
| 200152 | `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_self_containment_forbidden_phrase:infobox` | Who was the governor of Mombasa County according to the infobox? |
| 200152 | `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_self_containment_forbidden_phrase:infobox` | What county is Mombasa city located in according to the infobox? |
| 200152 | `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_self_containment_forbidden_phrase:infobox` | What is the area code number for Mombasa city as given in the infobox? |
| 200152 | `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_self_containment_forbidden_phrase:infobox` | In what year was Mombasa founded according to the infobox? |
| 200152 | `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_self_containment_forbidden_phrase:listed` | What is the climate classification of Mombasa city as listed in the infobox? |
| 588981 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=infobox;available=wikitable` | Provinces of Bulgaria |
| 22948 | `search_longtail` | `search_longtail_verifier_rejected:full_question:answer_in_title` | Who is the consort of the protector of seafarers and the guardian of many Hellenic cities and colonies? |
| 22948 | `route_generation` | `wikipedia_infobox_single_fact_list_answer:single_fact_list_answer_not_allowed` | What is the abode of the god of the sea, storms, earthquakes, and horses? |
| 22948 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | How many siblings does the protector of seafarers and the guardian of many Hellenic cities and colonies have? |
| 22948 | `route_generation` | `wikipedia_infobox_llm_discarded:No date value available in the infobox to form a valid question.` | Poseidon |
| 22948 | `search_longtail` | `search_longtail_verifier_rejected:keyword_queries:hit_rate_exceeded` | What is one of the symbols associated with the god of the sea, storms, earthquakes, and horses? |
| 4248 | `route_generation` | `wikipedia_infobox_table_filter_rejected:infobox_remaining_rows_lt_min:remaining_non_header_rows=4;min=5` | Bowls |
| 3968 | `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is present in the infobox to form a valid single-answer question.` | Bodhisattva |
| 3968 | `route_generation` | `wikipedia_infobox_llm_discarded:No place name or geographic entity is present in the infobox to form a valid single-answer question.` | Bodhisattva |
| 3968 | `route_generation` | `wikipedia_infobox_llm_discarded:No numeric value is present in the infobox to form a valid single-answer question.` | Bodhisattva |
| 3968 | `route_generation` | `wikipedia_infobox_llm_discarded:No date or year is present in the infobox to form a valid single-answer question.` | Bodhisattva |
| 3968 | `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_self_containment_forbidden_phrase:infobox` | What is the Pāli term for bodhisattva as given in the infobox? |
| 524482 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | Who is the brother of Tony Sirico? |
| 524482 | `rewrite_surface` | `answer_too_popular:New York City` | In which city was Tony Sirico born? |
| 524482 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | How many children did Tony Sirico have? |
| 524482 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | What month, day, and year did Tony Sirico die? |
| 524482 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | What was Tony Sirico's occupation? |
| 36624 | `route_generation` | `wikipedia_infobox_table_filter_rejected:infobox_remaining_rows_lt_min:remaining_non_header_rows=1;min=5` | Embryo |
| 62633 | `route_generation` | `wikipedia_infobox_no_tables` | Les Invalides |
| 368989 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=infobox;available=wikitable` | Formosan languages |
| 55440889 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=infobox;available=wikitable` | Pixel 2 |
| 24516 | `rewrite_surface` | `rule_based_answer_type_gate_rejected:person_common_words_minus_common_names` | Who is the ancient Greek historian known for documenting the rise of Rome in the Mediterranean during the third and second centuries BC? |
| 24516 | `search_longtail` | `search_longtail_verifier_rejected:keyword_queries:hit_rate_exceeded` | What city was Polybius born in? |
| 24516 | `route_generation` | `wikipedia_infobox_answer_type_not_allowed:answer_type_not_allowed:Number; allowed=Number` | What year was Polybius born, approximately? |
| 24516 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | What year did Polybius approximately die? |
| 24516 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What is the notable philosophical idea attributed to Polybius? |
| 205058 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=infobox;available=wikitable` | Heisei era |
| 10522749 | `route_generation` | `wikipedia_infobox_no_tables` | International Music Score Library Project |
| 31740 | `search_longtail` | `search_longtail_verifier_rejected:keyword_query_2:answer_in_title` | Who is the president of the oldest institution of higher education in the state of Michigan? |
| 31740 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | In which city is the oldest institution of higher education in the state of Michigan located? |
| 31740 | `route_generation` | `wikipedia_infobox_answer_type_not_allowed:answer_type_not_allowed:Number; allowed=Number` | In what year was the oldest institution of higher education in the state of Michigan established? |
| 31740 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What month, day, and year was the oldest institution of higher education in the state of Michigan established? |
| 31740 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What is the motto in English of the oldest institution of higher education in the state of Michigan? |
| 2186423 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=infobox;available=wikitable` | Hallelujah (Leonard Cohen song) |
| 13169 | `route_generation` | `wikipedia_infobox_table_filter_rejected:infobox_remaining_rows_lt_min:remaining_non_header_rows=1;min=5` | Gneiss |
| 20608 | `route_generation` | `wikipedia_infobox_no_tables` | Messier object |
| 135276 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | Who is the person after whom the city of Jackson, Tennessee was named? |
| 135276 | `search_longtail` | `search_longtail_verifier_rejected:full_question:answer_in_title` | In which county is the city of Jackson, Tennessee located? |
| 135276 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | What was the population of Jackson, Tennessee according to the 2020 United States census? |
| 68481047 | `route_generation` | `wikipedia_infobox_llm_discarded:No specific person names are provided in the table content.` | Fall of Kabul (2021) |
| 68481047 | `rewrite_surface` | `rewrite_guard_rejected:answer_leakage` | What city was the location of the Fall of Kabul in 2021? |
| 68481047 | `search_longtail` | `search_longtail_verifier_rejected:keyword_query_2:answer_in_title` | How many wars are referenced in the context of the Fall of Kabul (2021)? |
| 68481047 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What year did the Fall of Kabul occur? |
| 68481047 | `search_longtail` | `search_longtail_verifier_rejected:keyword_query_1:answer_in_title` | What was the name of the offensive that included the Fall of Kabul in 2021? |
| 188497 | `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is present in the infobox to form a valid question.` | Femur |
| 5816 | `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is present in the infobox to form a valid question.` | Cenozoic |
| 5816 | `rewrite_surface` | `rule_based_answer_type_gate_rejected:place_question_category_whitelist` | What celestial body is associated with the Cenozoic Era? |
| 5816 | `search_longtail` | `search_longtail_verifier_rejected:keyword_queries:hit_rate_exceeded` | What is the time span in million years of the Cenozoic Era? |
| 5816 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | In what year was the lower GSSP of the Cenozoic Era ratified? |
| 5816 | `search_longtail` | `search_longtail_verifier_rejected:full_question:answer_in_title` | What is the formal chronological unit classification of the Cenozoic? |
| 45367389 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=infobox;available=wikitable` | Greater London |
| 157774 | `route_generation` | `wikipedia_infobox_table_filter_rejected:infobox_removed_row_rate_gt_max:removed_row_rate=1.0000;max=0.6000;infobox_remaining_rows_lt_min:remaining_non_header_rows=0;min=5` | Permafrost |
| 413714 | `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any person's name as a single indisputable answer.` | Padma Bhushan |
| 413714 | `route_generation` | `wikipedia_infobox_llm_discarded:The table does not contain any place name or geographic entity on Earth as a single indisputable answer.` | Padma Bhushan |
| 413714 | `route_generation` | `wikipedia_infobox_answer_type_not_allowed:answer_type_not_allowed:Number; allowed=Number` | How many years ago was the Padma Bhushan award established? |
| 413714 | `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_award_year_without_month` | What year was the Padma Bhushan award first given? |
| 413714 | `rewrite_surface` | `rewrite_guard_rejected:answer_leakage` | What is the text written above the lotus flower on the obverse side of the Padma Bhushan medal? |
| 269408 | `search_longtail` | `search_longtail_verifier_rejected:keyword_queries:hit_rate_exceeded` | Who was the first governor-general of Colonial Brazil? |
| 269408 | `rewrite_surface` | `rewrite_guard_rejected:answer_leakage` | What city was the capital of Colonial Brazil from 1763 to 1815? |
| 269408 | `route_generation` | `wikipedia_infobox_answer_type_not_allowed:answer_type_not_allowed:Number; allowed=Number` | What was the duration in years of the Colonial Brazil period? |
| 269408 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | On what month, day, and year did the Portuguese arrive in Brazil? |
| 269408 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | What was the official religion of Colonial Brazil? |
| 741851 | `rewrite_surface` | `rule_based_answer_type_gate_rejected:person_common_words_minus_common_names` | Who founded Rough Trade Records? |
| 741851 | `rewrite_surface` | `answer_too_popular:London` | In which city is Rough Trade Records located? |
| 741851 | `route_generation` | `wikipedia_infobox_answer_type_not_allowed:answer_type_not_allowed:Number; allowed=Number` | In what year was Rough Trade Records founded? |
| 741851 | `route_generation` | `wikipedia_infobox_llm_discarded:The infobox does not provide a full calendar date or month and year for founding, only the year 1976.` | Rough Trade Records |
| 741851 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What is the parent company of Rough Trade Records? |
| 2500 | `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is present in the infobox to form a valid question.` | Anus |
| 2500 | `rewrite_surface` | `rule_based_answer_type_gate_rejected:place_question_category_whitelist` | What anatomical system does the anus belong to? |
| 2500 | `route_generation` | `wikipedia_infobox_llm_discarded:No explicit numeric value is provided for lymph nodes count in the infobox.` | Anus |
| 2500 | `route_generation` | `wikipedia_infobox_llm_discarded:No date or temporal information is present in the infobox to form a valid question.` | Anus |
| 2500 | `search_longtail` | `search_longtail_verifier_rejected:full_question:answer_in_title` | What is the Latin term for the external body orifice at the exit end of the digestive tract? |
| 6920895 | `rewrite_surface` | `rule_based_answer_type_gate_rejected:person_common_words_minus_common_names` | Who is the darts commentator honored by the trophy awarded to the winner of the most prestigious tournament organized by the Professional Darts Corporation? |
| 6920895 | `rewrite_surface` | `answer_too_popular:London` | What city hosts the PDC World Darts Championship at Alexandra Palace since 2008? |
| 6920895 | `route_generation` | `wikipedia_infobox_answer_type_not_allowed:answer_type_not_allowed:Number; allowed=Number` | In what year was the PDC World Darts Championship founded? |
| 6920895 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | In what year did the PDC World Darts Championship first hold its season? |
| 6920895 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | What is the tournament format used in the PDC World Darts Championship? |
| 288514 | `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is present in the infobox to form a valid question.` | Pixie |
| 288514 | `rewrite_surface` | `rule_based_answer_type_gate_rejected:place_question_category_whitelist` | In which region of the United Kingdom are pixies particularly concentrated according to British folklore? |
| 288514 | `route_generation` | `wikipedia_infobox_llm_discarded:No numeric value is present in the infobox to form a valid question.` | Pixie |
| 288514 | `route_generation` | `wikipedia_infobox_llm_discarded:No date or year is present in the infobox to form a valid question.` | Pixie |
| 500004 | `search_longtail` | `search_longtail_verifier_rejected:keyword_queries:hit_rate_exceeded` | Who created the On-Line Encyclopedia of Integer Sequences? |
| 500004 | `route_generation` | `wikipedia_infobox_llm_discarded:The infobox does not contain any place or geographic entity information.` | On-Line Encyclopedia of Integer Sequences |
| 500004 | `route_generation` | `wikipedia_infobox_answer_type_not_allowed:answer_type_not_allowed:Number; allowed=Number` | How many years ago was the On-Line Encyclopedia of Integer Sequences founded? |
| 500004 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What year was the On-Line Encyclopedia of Integer Sequences launched? |
| 500004 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | Is the On-Line Encyclopedia of Integer Sequences a commercial website? |
| 62149 | `route_generation` | `wikipedia_infobox_table_filter_rejected:infobox_remaining_rows_lt_min:remaining_non_header_rows=2;min=5` | Custard |
| 29781 | `search_longtail` | `search_longtail_verifier_rejected:full_question:answer_in_title` | Who directed the 1974 film The Texas Chain Saw Massacre? |
| 29781 | `rewrite_surface` | `answer_too_popular:United States` | What country produced the 1974 film The Texas Chain Saw Massacre? |
| 29781 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What is the running time in minutes of the 1974 film The Texas Chain Saw Massacre? |
| 29781 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What month, day, and year was The Texas Chain Saw Massacre released? |
| 29781 | `rewrite_surface` | `answer_too_popular:English` | What is the language of the 1974 film The Texas Chain Saw Massacre? |
| 240432 | `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is present in the infobox to form a valid question.` | Provinces of Argentina |
| 240432 | `rewrite_surface` | `rewrite_guard_rejected:answer_leakage` | What country are the provinces of Argentina located in? |
| 240432 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | How many provinces are there in Argentina? |
| 240432 | `route_generation` | `wikipedia_infobox_llm_discarded:No date or year information is present in the infobox to form a valid question.` | Provinces of Argentina |
| 457055 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=infobox;available=wikitable` | Comune |
| 226734 | `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is present in the infobox table to form a valid single-fact question.` | States of Nigeria |
| 30450289 | `route_generation` | `wikipedia_infobox_no_tables` | Regional units of Greece |
| 295691 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | Who was the founder of the Collège de France? |
| 295691 | `rewrite_surface` | `answer_too_popular:Paris` | In which city is the Collège de France located? |
| 2856052 | `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is present in the infobox table to form a valid question and answer.` | Haenyeo |
| 2856052 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | In which South Korean province do the haenyeo female divers primarily live and work? |
| 2856052 | `route_generation` | `wikipedia_infobox_llm_discarded:The infobox does not contain any numeric values suitable for a number-type question.` | Haenyeo |
| 2856052 | `route_generation` | `wikipedia_infobox_llm_discarded:No date or year information is present in the infobox table to form a valid question and answer.` | Haenyeo |
| 2856052 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What is the Hangul script representation of the Korean term for female divers known as haenyeo? |
| 380167 | `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is present in the infobox to form a valid question and answer.` | Achilles tendon |
| 380167 | `search_longtail` | `search_longtail_verifier_rejected:keyword_queries:hit_rate_exceeded` | What is the anatomical location of the Achilles tendon in the human body? |
| 380167 | `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_self_containment_forbidden_phrase:infobox` | How many muscles attach to the Achilles tendon according to the infobox? |
| 380167 | `route_generation` | `wikipedia_infobox_llm_discarded:No date or temporal information is present in the infobox to form a valid question and answer.` | Achilles tendon |
| 380167 | `route_generation` | `wikipedia_infobox_single_fact_list_answer:single_fact_list_answer_not_allowed` | What is the Latin anatomical term for the Achilles tendon? |
| 618770 | `search_longtail` | `search_longtail_verifier_rejected:keyword_query_1:answer_in_title` | Who is the actress born on March 28, 1948, in Kansas City, Missouri? |
| 618770 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | What city is the birthplace of Dianne Wiest? |
| 618770 | `search_longtail` | `search_longtail_verifier_rejected:keyword_queries:hit_rate_exceeded` | How many children does Dianne Wiest have? |
| 618770 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | What is the full birth date of Dianne Wiest including month, day, and year? |
| 618770 | `search_longtail` | `search_longtail_verifier_rejected:keyword_queries:hit_rate_exceeded` | What university did Dianne Wiest attend? |
| 83934 | `route_generation` | `wikipedia_infobox_no_tables` | Norwegian resistance movement |
| 235916 | `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_self_containment_forbidden_phrase:listed` | Who is the spouse of Jada Pinkett Smith listed in the infobox? |
| 235916 | `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_self_containment_forbidden_phrase:infobox` | In which city was Jada Pinkett Smith born according to the infobox? |
| 235916 | `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_self_containment_forbidden_phrase:listed` | How many children does Jada Pinkett Smith have as listed in the infobox? |
| 235916 | `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_self_containment_forbidden_phrase:infobox` | What month, day, and year was Jada Pinkett Smith born according to the infobox? |
| 235916 | `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_self_containment_forbidden_phrase:infobox` | What is the name of the production company associated with Jada Pinkett Smith in the infobox? |
| 55417368 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=infobox;available=wikitable` | 2016 Australian census |
| 637543 | `route_generation` | `wikipedia_infobox_no_tables` | Grand Duchy of Finland |
| 15355864 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=infobox;available=wikitable` | 2015 Pan American Games |
| 287299 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What is an alternative eponymous name for sarcoidosis derived from the names of three physicians? |
| 287299 | `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_self_containment_forbidden_phrase:infobox` | What organ is most commonly affected by sarcoidosis as indicated in the infobox? |
| 287299 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | What is the typical age range in years for the usual onset of sarcoidosis? |
| 287299 | `route_generation` | `wikipedia_infobox_llm_discarded:The infobox does not contain any specific date, month, or year information suitable for a date-type question.` | Sarcoidosis |
| 287299 | `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_self_containment_forbidden_phrase:listed` | What is one of the primary treatments listed for sarcoidosis in the infobox? |
| 87627 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=infobox;available=wikitable` | Amur Oblast |
| 89514 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=infobox;available=wikitable` | New London, Connecticut |
| 1290366 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=infobox;available=wikitable` | Amir Khan (boxer) |
| 306853 | `rewrite_surface` | `rule_based_answer_type_gate_rejected:person_common_words_minus_common_names` | Who developed the Jyutping romanisation system for Cantonese? |
| 306853 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | In which city was the Jyutping romanisation system developed? |
| 306853 | `route_generation` | `wikipedia_infobox_answer_type_not_allowed:answer_type_not_allowed:Number; allowed=Number` | In what year was the Jyutping romanisation system developed? |
| 306853 | `route_generation` | `wikipedia_infobox_llm_discarded:No full calendar date or month and year information is available in the table.` | Jyutping |
| 306853 | `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_answer_scope_ambiguous_phrase:meaning` | What is the literal meaning of the name 'Jyutping'? |
| 143117 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=infobox;available=wikitable` | Gujarati language |
| 67211 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=infobox;available=wikitable` | Electron configuration |
| 292259 | `search_longtail` | `search_longtail_verifier_rejected:full_question:answer_in_title` | Who is the Director-General of Deutsche Welle? |
| 292259 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | In which city is the headquarters of Deutsche Welle located? |
| 292259 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | How many languages does Deutsche Welle broadcast in? |
| 292259 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What month, day, and year was Deutsche Welle launched? |
| 292259 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What is the picture format used by Deutsche Welle for its broadcasts? |
| 186191 | `route_generation` | `wikipedia_infobox_single_fact_list_answer:single_fact_list_answer_not_allowed` | Who was the designer of the T-72 tank? |
| 186191 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What is the place of origin of the T-72 tank? |
| 186191 | `search_longtail` | `search_longtail_verifier_rejected:keyword_queries:hit_rate_exceeded` | How many crew members operate the T-72 tank? |
| 4236415 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | Who is the father of the Ashvins according to their genealogy? |
| 4236415 | `route_generation` | `wikipedia_infobox_llm_discarded:The infobox does not contain any place or geographic entity related to the Ashvins.` | Ashvins |
| 4236415 | `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_self_containment_forbidden_phrase:listed` | How many sons are listed as children of the Ashvins? |
| 4236415 | `route_generation` | `wikipedia_infobox_llm_discarded:The infobox does not provide any specific date, year, or month related to the Ashvins.` | Ashvins |
| 4236415 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What is the Greek equivalent name of the Ashvins? |
| 26211 | `route_generation` | `wikipedia_infobox_no_tables` | Racketeer Influenced and Corrupt Organizations Act |
| 81890 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=infobox;available=wikitable` | Fife |
| 1050340 | `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is present in the infobox table to form a valid single-answer question.` | Election Day (United States) |
| 1050340 | `rewrite_surface` | `answer_too_popular:United States` | In which country is the annual Election Day observed as the day for general elections of federal, state, and local public officials? |
| 1050340 | `route_generation` | `wikipedia_infobox_answer_type_not_allowed:answer_type_not_allowed:Number; allowed=Number` | How many days after the first Monday in November is Election Day held in the United States? |
| 1050340 | `rewrite_surface` | `rewrite_guard_rejected:cutoff_year_exceeded` | What is the date of Election Day in the United States in the year 2028? |
| 1050340 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What is the frequency of Election Day occurrences in the United States including off-years? |
| 67127 | `rewrite_surface` | `rewrite_guard_rejected:answer_leakage` | What is the full name of the athlete known as Carl Lewis? |
| 67127 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | In which city was Carl Lewis born? |
| 67127 | `route_generation` | `wikipedia_infobox_answer_type_not_allowed:answer_type_not_allowed:Number; allowed=Number` | In what year did Carl Lewis retire from professional track and field? |
| 67127 | `search_longtail` | `search_longtail_verifier_rejected:full_question:answer_in_title` | What month, day, and year was Carl Lewis born? |
| 67127 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What is the name of the club Carl Lewis was affiliated with during his athletic career? |
| 6392374 | `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is provided in the table to form a valid single-answer question.` | Sea captain |
| 6392374 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What is the location where a sea captain primarily operates? |
| 6392374 | `route_generation` | `wikipedia_infobox_llm_discarded:No numeric value is present in the table to form a valid single-answer question.` | Sea captain |
| 6392374 | `route_generation` | `wikipedia_infobox_llm_discarded:No date or year value is present in the table to form a valid single-answer question.` | Sea captain |
| 6392374 | `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_self_containment_forbidden_phrase:infobox` | What type of license is required for a sea captain according to the infobox? |
| 32133 | `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is present in the infobox to form a valid question.` | Urethra |
| 32133 | `rewrite_surface` | `rule_based_answer_type_gate_rejected:place_question_category_whitelist` | What precursor anatomical structure is the urethra derived from? |
| 32133 | `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_self_containment_forbidden_phrase:infobox` | How many arteries supply blood to the urethra according to the infobox? |
| 32133 | `route_generation` | `wikipedia_infobox_llm_discarded:No date or year information is present in the infobox to form a valid question.` | Urethra |
| 32133 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What is the Latin anatomical term for the female urethra? |
| 697535 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | Who created the AllMusic online music database? |
| 697535 | `route_generation` | `wikipedia_infobox_llm_discarded:The infobox does not provide any geographic place name or location on Earth relevant to AllMusic.` | AllMusic |
| 697535 | `route_generation` | `wikipedia_infobox_answer_type_not_allowed:answer_type_not_allowed:Number; allowed=Number` | How many years ago was the AllMusic website launched? |
| 697535 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | In what year was the AllMusic website launched? |
| 604350 | `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_self_containment_forbidden_phrase:listed` | Who is the chairman listed as a key person for ARD broadcaster? |
| 604350 | `rewrite_surface` | `answer_too_popular:Germany` | In which country is the ARD broadcaster based? |
| 604350 | `route_generation` | `wikipedia_infobox_answer_type_not_allowed:answer_type_not_allowed:Number; allowed=Number` | How many years ago was the ARD broadcaster launched? |
| 2839 | `route_generation` | `wikipedia_infobox_table_filter_rejected:infobox_remaining_rows_lt_min:remaining_non_header_rows=3;min=5` | Angular momentum |
| 66958 | `search_longtail` | `search_longtail_verifier_rejected:keyword_queries:hit_rate_exceeded` | Who is the central bank responsible for issuing the official currency of the People's Republic of China? |
| 66958 | `rewrite_surface` | `answer_too_popular:China` | Which country uses the official currency known as the Renminbi? |
| 66958 | `search_longtail` | `search_longtail_verifier_rejected:keyword_queries:hit_rate_exceeded` | What is the ISO 4217 numeric code for the Renminbi currency? |
| 66958 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What year was the Renminbi officially introduced? |
| 66958 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | What is the basic unit name of the Renminbi currency? |
| 458762 | `route_generation` | `wikipedia_infobox_no_tables` | Convair B-58 Hustler |
| 190884 | `route_generation` | `wikipedia_infobox_no_tables` | Khalid Sheikh Mohammed |
| 8971303 | `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is present in the infobox to form a valid single-answer question.` | Chivas USA |
| 8971303 | `search_longtail` | `search_longtail_verifier_rejected:keyword_queries:hit_rate_exceeded` | What city was the home stadium of Chivas USA located in? |
| 8971303 | `route_generation` | `wikipedia_infobox_answer_type_not_allowed:answer_type_not_allowed:Number; allowed=Number` | In what year was Chivas USA founded? |
| 8971303 | `search_longtail` | `search_longtail_verifier_rejected:keyword_queries:hit_rate_exceeded` | What month, day, and year was Chivas USA dissolved? |
| 8971303 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What is the full official name of the soccer club known as Chivas USA? |
| 74011 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | Who wrote the screenplay for the 1952 film High Noon? |
| 74011 | `rewrite_surface` | `answer_too_popular:United States` | What country produced the 1952 film High Noon? |
| 74011 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | What is the running time in minutes of the 1952 film High Noon? |
| 74011 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | What month, day, and year was the film High Noon released? |
| 74011 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What is the name of the production company behind the 1952 film High Noon? |
| 56636 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=infobox;available=wikitable` | Colombo |
| 2043650 | `search_longtail` | `search_longtail_verifier_rejected:keyword_query_1:answer_in_title` | Who is the editor of Uncut magazine? |
| 2043650 | `rewrite_surface` | `answer_too_popular:London` | In which city is Uncut magazine based? |
| 2043650 | `route_generation` | `wikipedia_infobox_answer_type_not_allowed:answer_type_not_allowed:Number; allowed=Number` | How many issues of Uncut magazine are published per year? |
| 2043650 | `search_longtail` | `search_longtail_verifier_rejected:keyword_queries:hit_rate_exceeded` | What month and year was the first issue of Uncut magazine published? |
| 2043650 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What is the official website of Uncut magazine? |
| 910914 | `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is present in the infobox to form a valid single-answer question.` | Young Artist Award |
| 910914 | `rewrite_surface` | `answer_too_popular:United States` | In which country is the Young Artist Award presented? |
| 910914 | `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_time_invariance_forbidden_phrase:current` | What is the ordinal number of the current Young Artist Awards ceremony? |
| 910914 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | What month and year was the first Young Artist Award ceremony held? |
| 60382764 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=infobox;available=wikitable` | Reiwa era |
| 22707 | `route_generation` | `wikipedia_infobox_no_tables` | Oolong |
| 1003268 | `search_longtail` | `search_longtail_verifier_rejected:keyword_query_1:answer_in_title` | Which historical figure is associated with the colloquial name of the stage of the English language from the beginning of the Tudor period to the English Interregnum and Restoration? |
| 1003268 | `route_generation` | `wikipedia_infobox_single_fact_list_answer:single_fact_list_answer_not_allowed` | Which countries are native regions of the stage of the English language from the beginning of the Tudor period to the English Interregnum and Restoration? |
| 46989 | `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is present in the infobox to form a valid single answer question.` | Grand Canyon |
| 46989 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | In which U.S. state is the Grand Canyon located? |
| 46989 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | What is the length in miles of the Grand Canyon? |
| 46989 | `route_generation` | `wikipedia_infobox_llm_discarded:No date or year information is present in the infobox to form a valid single answer question.` | Grand Canyon |
| 46989 | `search_longtail` | `search_longtail_verifier_rejected:full_question:answer_in_title` | What river carved the Grand Canyon? |
| 64384 | `rewrite_surface` | `rule_based_answer_type_gate_rejected:person_common_words_minus_common_names` | Who is the artist known for the paintings The Hunters in the Snow and The Peasant Wedding? |
| 64384 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | In which city was Pieter Bruegel the Elder probably born? |
| 22093 | `search_longtail` | `search_longtail_verifier_rejected:keyword_query_1:answer_in_title` | Who is the commissioner of the National Basketball Association? |
| 22093 | `rewrite_surface` | `answer_too_popular:New York City` | What city is the headquarters of the National Basketball Association located in? |
| 22093 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | How many teams are in the National Basketball Association? |
| 22093 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | On what month, day, and year was the National Basketball Association founded as the BAA? |
| 22093 | `rewrite_surface` | `rewrite_guard_rejected:answer_leakage` | What sport does the National Basketball Association represent? |
| 7632 | `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is present in the infobox to form a valid question.` | Cerebrospinal fluid |
| 7632 | `route_generation` | `wikipedia_infobox_llm_discarded:No place name or geographic entity is present in the infobox to form a valid question.` | Cerebrospinal fluid |
| 7632 | `route_generation` | `wikipedia_infobox_llm_discarded:No numeric value is present in the infobox to form a valid question.` | Cerebrospinal fluid |
| 7632 | `route_generation` | `wikipedia_infobox_llm_discarded:No date or year is present in the infobox to form a valid question.` | Cerebrospinal fluid |
| 7632 | `search_longtail` | `search_longtail_verifier_rejected:keyword_queries:hit_rate_exceeded` | What is the Latin term for cerebrospinal fluid? |
| 22450 | `search_longtail` | `search_longtail_verifier_rejected:keyword_queries:hit_rate_exceeded` | Who is credited as the inventor of the open-wheel car? |
| 22450 | `route_generation` | `wikipedia_infobox_llm_discarded:The infobox does not contain any place or geographic entity information.` | Open-wheel car |
| 22450 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | How many wheels can an open-wheel car have? |
| 22450 | `route_generation` | `wikipedia_infobox_llm_discarded:The infobox does not provide any date or year information.` | Open-wheel car |
| 22450 | `route_generation` | `wikipedia_infobox_single_fact_list_answer:single_fact_list_answer_not_allowed` | What is the fuel source used by open-wheel cars? |
| 64300 | `search_longtail` | `search_longtail_verifier_rejected:keyword_query_1:answer_in_title` | Who is the voice actor of Bart Simpson? |
| 64300 | `search_longtail` | `search_longtail_verifier_rejected:keyword_queries:hit_rate_exceeded` | What is the city where Bart Simpson's home is located? |
| 64300 | `search_longtail` | `search_longtail_verifier_rejected:full_question:answer_in_title` | What grade is Bart Simpson attending at Springfield Elementary School? |
| 64300 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | On what month, day, and year did Bart Simpson first appear on television? |
| 64300 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What is the full name of the character Bart Simpson? |
| 246305 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=infobox;available=wikitable` | Livorno |
| 479512 | `route_generation` | `wikipedia_infobox_no_tables` | Better Business Bureau |
| 521893 | `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is present or relevant in the infobox for the subject.` | Voiced bilabial plosive |
| 521893 | `route_generation` | `wikipedia_infobox_llm_discarded:No place or geographic entity is present or relevant in the infobox for the subject.` | Voiced bilabial plosive |
| 521893 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What is the IPA number assigned to the voiced bilabial plosive? |
| 521893 | `route_generation` | `wikipedia_infobox_llm_discarded:No date or year information is present or relevant in the infobox for the subject.` | Voiced bilabial plosive |
| 521893 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What is the Unicode hexadecimal code point for the voiced bilabial plosive? |
| 171623 | `search_longtail` | `search_longtail_verifier_rejected:full_question:answer_in_title` | Who directed the 2001 film Training Day? |
| 171623 | `rewrite_surface` | `answer_too_popular:United States` | What country produced the film Training Day? |
| 171623 | `route_generation` | `wikipedia_infobox_answer_type_not_allowed:answer_type_not_allowed:Number; allowed=Number` | What is the running time in minutes of the film Training Day? |
| 171623 | `search_longtail` | `search_longtail_verifier_rejected:keyword_queries:hit_rate_exceeded` | What month, day, and year was Training Day first released at the Venice Film Festival? |
| 171623 | `rewrite_surface` | `answer_too_popular:English` | What language is spoken in the film Training Day? |
| 5489 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=infobox;available=wikitable` | Chile |
| 72760 | `route_generation` | `wikipedia_infobox_no_tables` | Square kilometre |
| 31388 | `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is provided in the infobox; only entities and locations are listed.` | Treaty of Brest-Litovsk |
| 31388 | `rewrite_surface` | `rewrite_guard_rejected:answer_leakage` | What city was the Treaty of Brest-Litovsk signed in? |
| 31388 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | How many languages were used in the Treaty of Brest-Litovsk? |
| 31388 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | On what month, day, and year was the Treaty of Brest-Litovsk signed? |
| 57708 | `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_self_containment_forbidden_phrase:infobox` | Who was the mayor of Topeka, Kansas according to the infobox? |
| 57708 | `search_longtail` | `search_longtail_verifier_rejected:full_question:answer_in_title` | In which county is the city of Topeka, Kansas located? |
| 57708 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | What was the population of Topeka, Kansas according to the 2020 census? |
| 57708 | `search_longtail` | `search_longtail_verifier_rejected:keyword_queries:hit_rate_exceeded` | In what year was Topeka, Kansas incorporated? |
| 57708 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What is the demonym for residents of Topeka, Kansas? |
| 951393 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=infobox;available=wikitable` | Filial piety |
| 17416221 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=infobox;available=wikitable` | South Africa |
| 30125638 | `route_generation` | `wikipedia_infobox_no_tables` | Cubic metre |
| 63503 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=infobox;available=wikitable` | Duluth, Minnesota |
| 10209822 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | Who was the father of Edward the Elder? |
| 10209822 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | In which city was Edward the Elder coronated? |
| 10209822 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | How many spouses did Edward the Elder have? |
| 10209822 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | What month, day, and year did Edward the Elder die? |
| 10209822 | `search_longtail` | `search_longtail_verifier_rejected:full_question:answer_in_title` | What was the name of the house to which Edward the Elder belonged? |
| 56617 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=infobox;available=wikitable` | Bangui |
| 5070109 | `route_generation` | `wikipedia_infobox_llm_discarded:No specific person names are provided in the table under commanders and leaders.` | Spanish Armada |
| 5070109 | `rewrite_surface` | `rule_based_answer_type_gate_rejected:place_question_category_whitelist` | What war was the Spanish Armada part of? |
| 5070109 | `route_generation` | `wikipedia_infobox_llm_discarded:No numeric strength value is provided in the table.` | Spanish Armada |
| 5070109 | `search_longtail` | `search_longtail_verifier_rejected:keyword_query_1:answer_in_title` | In what year did the Anglo-Spanish War involving the Spanish Armada begin? |
| 5070109 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What is the name of the war also associated with the Spanish Armada besides the Anglo-Spanish War? |
| 40176 | `route_generation` | `wikipedia_infobox_no_tables` | Joseph Priestley |
| 404204 | `route_generation` | `wikipedia_infobox_llm_discarded:No specific person names are provided in the table.` | November Uprising |
| 404204 | `route_generation` | `wikipedia_infobox_llm_discarded:No specific place names or countries are provided in the table.` | November Uprising |
| 404204 | `route_generation` | `wikipedia_infobox_llm_discarded:No numeric strength values are provided in the table.` | November Uprising |
| 404204 | `search_longtail` | `search_longtail_verifier_rejected:keyword_query_2:answer_in_title` | What year did the November Uprising take place? |
| 404204 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | What was the outcome of the November Uprising? |
| 10893 | `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is present in the infobox to form a valid single-answer question.` | Fencing |
| 10893 | `rewrite_surface` | `rewrite_guard_rejected:answer_leakage` | What country or region is fencing practiced worldwide in? |
| 10893 | `route_generation` | `wikipedia_infobox_llm_discarded:The infobox does not provide a numeric value for team members; only 'Singles or team relay' is given.` | Fencing |
| 10893 | `search_longtail` | `search_longtail_verifier_rejected:full_question:answer_in_title` | In what year did fencing become part of the Summer Olympic programme? |
| 10893 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What is the name of the venue where fencing competitions are held? |
| 534617 | `search_longtail` | `search_longtail_verifier_rejected:keyword_query_2:answer_in_title` | Who created the original artwork for the Care Bears? |
| 534617 | `search_longtail` | `search_longtail_verifier_rejected:full_question:answer_in_title` | In which city or location was the group that created the Care Bears based? |
| 534617 | `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_self_containment_forbidden_phrase:infobox` | How many theatrical Care Bears films were released according to the infobox? |
| 534617 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | What year were the Care Bears originally created for greeting cards? |
| 534617 | `search_longtail` | `search_longtail_verifier_rejected:keyword_queries:hit_rate_exceeded` | What is the name of the company that published the original Care Bears greeting cards? |
| 2924002 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=infobox;available=wikitable` | Electronic dance music |
| 313647 | `route_generation` | `wikipedia_infobox_no_tables` | Mpumalanga |
| 129295 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | Who directed the 1987 film Fatal Attraction? |
| 129295 | `rewrite_surface` | `answer_too_popular:United States` | In which country was the film Fatal Attraction produced? |
| 129295 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | What is the running time in minutes of the film Fatal Attraction? |
| 129295 | `search_longtail` | `search_longtail_verifier_rejected:keyword_queries:hit_rate_exceeded` | What month, day, and year was Fatal Attraction released in the United States? |
| 40158 | `rewrite_surface` | `rewrite_guard_rejected:cutoff_year_exceeded` | Who is the mayor of Berchtesgaden for the term 2020 to 2026? |
| 40158 | `search_longtail` | `search_longtail_verifier_rejected:full_question:answer_in_title` | In which German state is the municipality of Berchtesgaden located? |
| 40158 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What is the vehicle registration code number for Berchtesgaden? |
| 40158 | `rewrite_surface` | `rewrite_guard_rejected:forbidden_temporal_phrase` | As of what date is the population data for Berchtesgaden recorded? |
| 152333 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=infobox;available=wikitable` | Provinces of Belgium |
| 84952 | `search_longtail` | `search_longtail_verifier_rejected:keyword_queries:hit_rate_exceeded` | Who was the boxer known as Marvelous Marvin Hagler at birth? |
| 84952 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | In which city was Marvelous Marvin Hagler born? |
| 84952 | `search_longtail` | `search_longtail_verifier_rejected:full_question:answer_in_title` | How many total professional fights did Marvelous Marvin Hagler have? |
| 84952 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What month, day, and year did Marvelous Marvin Hagler die? |
| 84952 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What was Marvelous Marvin Hagler's boxing stance? |
| 2507138 | `route_generation` | `wikipedia_infobox_no_tables` | First Austrian Republic |
| 204971 | `route_generation` | `wikipedia_infobox_no_tables` | Historic counties of England |
| 187544 | `route_generation` | `wikipedia_infobox_no_tables` | Hermann Weyl |
| 415156 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | Who directed the 2002 film XXX? |
| 415156 | `rewrite_surface` | `answer_too_popular:United States` | What country produced the 2002 film XXX? |
| 415156 | `search_longtail` | `search_longtail_verifier_rejected:keyword_queries:hit_rate_exceeded` | What is the running time in minutes of the 2002 film XXX? |
| 415156 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What month, day, and year was the 2002 film XXX released? |
| 415156 | `rewrite_surface` | `answer_too_popular:English` | What is the language of the 2002 film XXX? |
| 10149834 | `rewrite_surface` | `rule_based_answer_type_gate_rejected:person_common_words_minus_common_names` | Who directed the eighth film Miyazaki directed for Studio Ghibli? |
| 10149834 | `rewrite_surface` | `answer_too_popular:Japan` | What country produced the eighth film Miyazaki directed for Studio Ghibli? |
| 10149834 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What is the running time in minutes of the eighth film Miyazaki directed for Studio Ghibli? |
| 10149834 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What month, day, and year was the eighth film Miyazaki directed for Studio Ghibli released? |
| 10149834 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | What is the Japanese name of the eighth film Miyazaki directed for Studio Ghibli? |
| 105908 | `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is present in the infobox to form a valid single-answer question.` | Ford Mustang |
| 105908 | `rewrite_surface` | `answer_too_popular:United States` | In which country is the Ford Mustang manufactured? |
| 57951 | `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is present in the infobox to form a valid question.` | Provinces of the Netherlands |
| 57951 | `search_longtail` | `search_longtail_verifier_rejected:keyword_query_1:answer_in_title` | What country are the provinces located in? |
| 57951 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | How many provinces are there in the Netherlands? |
| 57951 | `route_generation` | `wikipedia_infobox_llm_discarded:No date or year information is present in the infobox to form a valid question.` | Provinces of the Netherlands |
| 57951 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What is the name of the government body that administers the provinces of the Netherlands? |
| 176871 | `route_generation` | `wikipedia_infobox_no_tables` | Convair F-106 Delta Dart |
| 8429 | `route_generation` | `wikipedia_infobox_table_filter_rejected:infobox_remaining_rows_lt_min:remaining_non_header_rows=4;min=5` | Density |
| 60058274 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | Who directed the film Licorice Pizza? |
| 60058274 | `rewrite_surface` | `answer_too_popular:United States` | In which country was the film Licorice Pizza produced? |
| 60058274 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What is the running time in minutes of the film Licorice Pizza? |
| 60058274 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What month, day, and year was the film Licorice Pizza released? |
| 60058274 | `rewrite_surface` | `answer_too_popular:English` | What is the original language of the film Licorice Pizza? |
| 880255 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | Who won the Outland Trophy in 1957? |
| 880255 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | In which city was Alex Karras born? |
| 880255 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | What was Alex Karras's overall pick number in the 1958 NFL draft? |
| 880255 | `search_longtail` | `search_longtail_verifier_rejected:keyword_queries:hit_rate_exceeded` | What month, day, and year was Alex Karras born? |
| 880255 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | What position did Alex Karras play in football? |
| 5643 | `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is present in the infobox to form a valid question.` | Channel Islands |
| 5643 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | What is the capital city of the Bailiwick of Guernsey? |
| 5643 | `search_longtail` | `search_longtail_verifier_rejected:keyword_queries:hit_rate_exceeded` | How many inhabited islands are there in the Channel Islands archipelago? |
| 5643 | `route_generation` | `wikipedia_infobox_llm_discarded:No specific date, year, or month is provided in the infobox to form a valid question.` | Channel Islands |
| 5643 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | What is the time zone of the Channel Islands during standard time? |
| 277011 | `search_longtail` | `search_longtail_verifier_rejected:keyword_queries:hit_rate_exceeded` | Who is the maternal grandfather of Tom Felton? |
| 277011 | `search_longtail` | `search_longtail_verifier_rejected:keyword_queries:hit_rate_exceeded` | In which city was Tom Felton born? |
| 277011 | `route_generation` | `wikipedia_infobox_answer_type_not_allowed:answer_type_not_allowed:Number; allowed=Number` | How many years has Tom Felton been active in his career as of the data in the table? |
| 277011 | `search_longtail` | `search_longtail_verifier_rejected:full_question:answer_in_title` | What is the month, day, and year of Tom Felton's birth? |
| 277011 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What is the official website URL of Tom Felton? |
| 109566 | `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is provided in the infobox.` | Winter Park, Florida |
| 109566 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | In which county is the city of Winter Park located? |
| 109566 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | What was the population of Winter Park according to the 2020 census? |
| 83115 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=infobox;available=wikitable` | 1968 Summer Olympics |
| 615800 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | Who is the full name of the footballer known as Cafu? |
| 615800 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | What city was Cafu born in? |
| 82050 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | Who is the Command Master Chief Petty Officer of the Royal Norwegian Navy? |
| 82050 | `search_longtail` | `search_longtail_verifier_rejected:keyword_queries:hit_rate_exceeded` | What is the location of the headquarters of the Royal Norwegian Navy? |
| 82050 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | How many vessels did the Royal Norwegian Navy have as of 2008? |
| 82050 | `search_longtail` | `search_longtail_verifier_rejected:keyword_queries:hit_rate_exceeded` | On what month, day, and year was the Royal Norwegian Navy officially founded? |
| 41853326 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=infobox;available=wikitable` | Inter Miami CF |
| 54232 | `route_generation` | `wikipedia_infobox_table_filter_rejected:infobox_remaining_rows_lt_min:remaining_non_header_rows=3;min=5` | Reinforced concrete |
| 3351466 | `route_generation` | `wikipedia_infobox_no_tables` | Capezio |
| 901117 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=infobox;available=wikitable` | Ujjain |
| 1582694 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | Who is the founder of Wisden Cricketers' Almanack? |
| 1582694 | `rewrite_surface` | `answer_too_popular:London` | In which city is Wisden Cricketers' Almanack based? |
| 1582694 | `route_generation` | `wikipedia_infobox_answer_type_not_allowed:answer_type_not_allowed:Number; allowed=Number` | How many years ago was the first issue of Wisden Cricketers' Almanack published? |
| 1582694 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | What year was the first issue of Wisden Cricketers' Almanack published? |
| 1582694 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | What is the name of the publisher of Wisden Cricketers' Almanack? |
| 182283 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=infobox;available=wikitable` | Miles per hour |
| 199445 | `search_longtail` | `search_longtail_verifier_rejected:full_question:answer_in_title` | Who was the manager of Derby County from 2020 to 2022? |
| 199445 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | What city was Wayne Rooney born in? |
| 2310937 | `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is provided in the infobox; only team names and locations are listed.` | 2000 NFL season |
| 2310937 | `search_longtail` | `search_longtail_verifier_rejected:keyword_queries:hit_rate_exceeded` | What city hosted the Super Bowl XXXV game in the 2000 NFL season? |
| 2310937 | `route_generation` | `wikipedia_infobox_answer_type_not_allowed:answer_type_not_allowed:Number; allowed=Number` | How many days did the regular season last in the 2000 NFL season? |
| 2310937 | `search_longtail` | `search_longtail_verifier_rejected:keyword_queries:hit_rate_exceeded` | What month, day, and year was the Super Bowl XXXV played in the 2000 NFL season? |
| 2310937 | `search_longtail` | `search_longtail_verifier_rejected:keyword_queries:hit_rate_exceeded` | What stadium hosted the Pro Bowl game following the 2000 NFL season? |
| 601094 | `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is present in the infobox to form a valid single-answer question.` | Korma |
| 601094 | `rewrite_surface` | `rule_based_answer_type_gate_rejected:place_question_category_whitelist` | What empire is the place of origin of Korma? |
| 601094 | `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_self_containment_forbidden_phrase:listed` | How many main ingredients are listed for Korma in the infobox? |
| 601094 | `route_generation` | `wikipedia_infobox_llm_discarded:No date, year, or month information is present in the infobox to form a valid single-answer question.` | Korma |
| 601094 | `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_self_containment_forbidden_phrase:infobox` | What is the serving temperature of Korma according to the infobox? |
| 248339 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=infobox;available=wikitable` | Brandon, Manitoba |
| 28901997 | `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is provided in the infobox; only organizations and event names are listed.` | Critics' Choice Awards |
| 28901997 | `rewrite_surface` | `answer_too_popular:United States` | In which country are the Critics' Choice Awards presented? |
| 28901997 | `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_time_invariance_forbidden_phrase:current` | What number edition is the current Critics' Choice Awards? |
| 28901997 | `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_award_year_without_month` | In what year was the first Critics' Choice Award given? |
| 28901997 | `search_longtail` | `search_longtail_verifier_rejected:keyword_queries:hit_rate_exceeded` | What organization presents the Critics' Choice Awards? |
| 812281 | `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is provided in the infobox to form a valid single-answer question.` | EuroBasket |
| 812281 | `rewrite_surface` | `answer_too_popular:Europe` | What continent hosts the main international basketball competition for the senior men's national teams known as EuroBasket? |
| 812281 | `search_longtail` | `search_longtail_verifier_rejected:keyword_queries:hit_rate_exceeded` | How many teams participate in the EuroBasket basketball competition? |
| 812281 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | In what year was the EuroBasket basketball competition founded? |
| 812281 | `search_longtail` | `search_longtail_verifier_rejected:keyword_queries:hit_rate_exceeded` | What is the name of the organising body of the EuroBasket basketball competition? |
| 329529 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | Who is the dean of the medical school of Harvard University? |
| 329529 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | In which city is the medical school of Harvard University located? |
| 329529 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | How many MD students are enrolled at the medical school of Harvard University? |
| 329529 | `search_longtail` | `search_longtail_verifier_rejected:keyword_queries:hit_rate_exceeded` | On what month, day, and year was the medical school of Harvard University established? |
| 329529 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What type of institution is the medical school of Harvard University classified as? |
| 81572 | `route_generation` | `wikipedia_infobox_no_tables` | Bristol Blenheim |
| 134987 | `route_generation` | `wikipedia_infobox_no_allowed_table_source_types:no_allowed_table_source_types:allowed=infobox;available=wikitable` | Rapid City, South Dakota |
| 14610495 | `route_generation` | `wikipedia_infobox_no_tables` | 2 Girls 1 Cup |
| 142549 | `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is present in the infobox to form a valid question.` | Peritonitis |
| 142549 | `route_generation` | `wikipedia_infobox_llm_discarded:No place name or geographic entity is present in the infobox to form a valid question.` | Peritonitis |
| 142549 | `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_self_containment_forbidden_phrase:listed` | How many types of peritonitis are listed in the infobox? |
| 142549 | `route_generation` | `wikipedia_infobox_llm_discarded:No specific date, year, or month is present in the infobox to form a valid question.` | Peritonitis |
| 142549 | `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_self_containment_forbidden_phrase:infobox` | What is the usual onset of peritonitis according to the infobox? |
| 1048946 | `route_generation` | `wikipedia_infobox_no_tables` | Chamorro people |
| 404595 | `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is present in the infobox to form a valid single-answer question.` | NCAA Division I Football Championship |
| 404595 | `rewrite_surface` | `rewrite_guard_rejected:cutoff_year_exceeded` | What city hosts the NCAA Division I Football Championship starting in 2026? |
| 404595 | `route_generation` | `wikipedia_infobox_answer_type_not_allowed:answer_type_not_allowed:Number; allowed=Number` | How many years was the NCAA Division I Football Championship held at Toyota Stadium? |
| 404595 | `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_time_invariance_forbidden_phrase:current` | In what year did the NCAA Division I Football Championship start being operated under its current name? |
| 404595 | `rewrite_surface` | `rewrite_guard_rejected:cutoff_year_exceeded` | What is the name of the stadium hosting the NCAA Division I Football Championship from 2026 onward? |
| 8083 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | Who was Dr. Dre married to in 1996? |
| 8083 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | In which city was Dr. Dre born? |
| 610522 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | Who is one of the founders of MobyGames? |
| 610522 | `rewrite_surface` | `answer_too_popular:English` | In what language is MobyGames primarily available? |
| 610522 | `route_generation` | `wikipedia_infobox_answer_type_not_allowed:answer_type_not_allowed:Number; allowed=Number` | How many years ago was MobyGames launched? |
| 610522 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | What month, day, and year was MobyGames launched? |
| 610522 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What is the commercial status of MobyGames? |
| 33643148 | `route_generation` | `wikipedia_infobox_table_filter_rejected:infobox_remaining_rows_lt_min:remaining_non_header_rows=4;min=5` | Jam band |
| 42229472 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | Who is the producer of the Glottolog database? |
| 42229472 | `rewrite_surface` | `answer_too_popular:Germany` | In which country is the producer of Glottolog located? |
| 42229472 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | How many languages does Glottolog support? |
| 42229472 | `route_generation` | `wikipedia_infobox_llm_discarded:No date information is available in the infobox.` | Glottolog |
| 42229472 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What is the cost to access the Glottolog database? |
| 4595410 | `route_generation` | `wikipedia_infobox_no_tables` | 1970 United States census |
| 540034 | `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is present in the infobox to form a valid question.` | Amyloidosis |
| 540034 | `route_generation` | `wikipedia_infobox_llm_discarded:No place or geographic entity is present in the infobox to form a valid question.` | Amyloidosis |
| 33134 | `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is present in the infobox table to form a valid question.` | World music |
| 33134 | `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_self_containment_forbidden_phrase:listed` | What geographic regions are listed as regional scenes for world music? |
| 33134 | `route_generation` | `wikipedia_infobox_llm_discarded:No numeric value is present in the infobox table to form a valid question.` | World music |
| 33134 | `route_generation` | `wikipedia_infobox_llm_discarded:No date or year is present in the infobox table to form a valid question.` | World music |
| 33134 | `rewrite_surface` | `rewrite_guard_rejected:post_rewrite_self_containment_forbidden_phrase:listed` | What is the derivative form of world music listed in the infobox? |
| 19746798 | `route_generation` | `wikipedia_infobox_no_tables` | Here Technologies |
| 650522 | `route_generation` | `wikipedia_infobox_table_filter_rejected:infobox_remaining_rows_lt_min:remaining_non_header_rows=3;min=5` | Sickle |
| 422038 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | Who is the mayor of the municipality of Vigo? |
| 422038 | `search_longtail` | `search_longtail_verifier_rejected:keyword_query_2:answer_in_title` | In which province is the city of Vigo located? |
| 422038 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | How many parishes are there in the municipality of Vigo? |
| 422038 | `route_generation` | `wikipedia_infobox_llm_discarded:No date value is present in the infobox suitable for a fixed-date question.` | Vigo |
| 312038 | `search_longtail` | `search_longtail_verifier_rejected:full_question:hit_rate_exceeded` | Who is the bodhisattva primarily revered in East Asian Buddhism known for his vow to instruct all beings in the six worlds? |
| 312038 | `shared_validation` | `shared_validation_failed:answer_in_evidence` | What is the geographic region where Kṣitigarbha is primarily venerated? |
| 312038 | `search_longtail` | `search_longtail_verifier_rejected:keyword_queries:hit_rate_exceeded` | How many worlds does Kṣitigarbha vow to instruct all beings in? |
| 312038 | `route_generation` | `wikipedia_infobox_llm_discarded:No date information is present in the infobox or table content to form a valid question.` | Kṣitigarbha |
| 312038 | `search_longtail` | `search_longtail_verifier_rejected:full_question:answer_in_title` | What is the Sanskrit name of the bodhisattva known as Earth Store? |
| 524850 | `route_generation` | `wikipedia_infobox_llm_discarded:No person's name is present in the infobox.` | Voiced palatal approximant |
| 524850 | `route_generation` | `wikipedia_infobox_llm_discarded:No place or geographic entity is present in the infobox.` | Voiced palatal approximant |
| 524850 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What is the IPA number assigned to the voiced palatal approximant? |
| 524850 | `route_generation` | `wikipedia_infobox_llm_discarded:No date or year information is present in the infobox.` | Voiced palatal approximant |
| 524850 | `second_stage_grading` | `second_stage_grading_accuracy_threshold_exceeded:accuracy=0.5;threshold=0.1` | What is the Unicode hexadecimal code point for the voiced palatal approximant? |


